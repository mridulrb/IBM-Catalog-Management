# waiops-mustgather
WAIOps Mustgather Tool [**LATEST VERSION = 1.13.5**]
```
NOTE: 
(1) The WAIOPS MustGather Tool is a production-grade implementation of the Generic Mustgather Framework:
https://github.ibm.com/danielyeap/generic-mustgather
(2) You can download the CP4WAIOPS MustGather Tool package from:
https://www.ibm.com/support/pages/node/6458081
```

This mustgather tool is a wrapper to some 'oc' commands (not rocket science like some other more sophisticated mustgather tools).

We plan to keep it simple because:
```
(1) we enjoy the freedom, flexibility and speed to update it and fix any defect (the AGILE way? :)
(2) we want the customer to be able to download it, put it on a machine and start using it (there is no need to download an image from a repo, etc)
(3) we want it to be "open-source", so that anyone can contribute to make it better!
(4) we want to allow the customer to scrutinize the script easily, especially in sensitive environments like government agencies and financial organizations!
(5) we believe in having the smallest tool (the main script and product-function script are only about 340kB in size) doing the heaviest lifting!
```

## WAIOPS MUSTGATHER - USER GUIDE
Download [here](https://github.ibm.com/danielyeap/waiops-mustgather/blob/master/docs/)

## COMMAND HELP 
```
[ MustGather Version = 1.13.3 / GMGF Version = 0.29.7 ]

USAGE: waiops-mustgather.sh -[a|b|c|l] [-k resourcename/resourcefile] [-z modules] [-d] [-L numlines] [-C cmdexec-file:cmdexec-env] [-E cmdexec-envvar] [-T timeout-value] [-m manual-collection-param] [-n manual-collection-envvar] [-j objname] [-B execprep] [-w manual-collection-exec-timeout] [-e extra-namespaces:extra-resources] [-x product-version/path-to-config-file] [-A compliance-param] [-P plugins] [-Z plugins-envvar] [-Q plugins-timeout] [-F cpfiles-param] [-K] [-V view-only-module] [-O alias-module] [-y] [-J] [-p] [-t] [-g] [-f] [-R] [-S] [-s] [-u node-admin-username] [-i path-to-sshkey] [-o output-directory] [-G filename-regex:pattern] [-W primary-mode-var] [-N] [-I] [-X] [-Y] [-H] [-U] [-M] [-D] [-v] [-h]

WHERE
[PRIMARY modes]
<ALL mode>
-a = get all data (data volume = high)
<COMPREHENSIVE mode>
-c = get comprehensive data (data volume = slightly high)
<BASIC mode>
-b = get basic data (data volume = moderate)
<LIMITED mode>
-l = get limited data (data volume = low)
<SELECTIVE mode>
-k = get data for selective resources (data volume = vary)
     WHERE
     <resourcename> = resource names separated by commas - Eg. pod,deployment,secrets
     <resourcefile> = absolute/full path to file containing resource names (one resource per line) - Eg. /tmp/selective.cfg
     NOTE: To get cluster-wide (all-namespaces) data for namespace-scoped resource (Eg. pod), you can use special keyword 'allns' (Eg. pod/allns,ingress,cm/allns)
           'allns' data is available in the CLUSTER_DATA directory / namespaced data is available in the PROD_NAMESPACES directory
<MODULE mode>
-z = get data based on predefined modules separated by comma (clusterinfo productinfo storage networking installation csv pvcusage nodeinfo healthcheck) (data volume = vary)
     NOTE: To list all available modules, use '-z .listmodules'

[SECONDARY modes]
<CLUSTERNODES mode>
-d = get logs and data from all cluster nodes using oc debug or SSH (if -i or -u is used)
-L = number of lines of journal to collect from cluster nodes (default = 2000)
<CMDEXEC mode>
-C = [script file]##[environment file] WHERE [environment file] is optional
     Format of [environment file] is KEY=VALUE with one keyvalue pair per line (similar to variable definition format in shell script)
-E = environment variables for the cmdexec script - Eg. VAR1=VAL1##VAR2=VAL2##...
     NOTE: Please enclose the entire input string with SINGLE quotes (Eg. 'VAR1=hello##VAR2=uname -a')
-T = timeout value for cmdexec [-C] (default = 15m) - Eg. 10s where s=second; m=minute; h=hour
<MANUALCOLLECT mode>
-m = <manual-collection-param> = [TAGS]:input file for the getManualCollection() function where TAGS is optional (defaulted to ALL config lines / separate multiple tags with comma)
-n = environment variables for the 'manualcollect' EXECCMD command - Eg. TAG1~>VAR1=VAL1##VAR2=VAL2^^TAG2~>VAR3=VAL3... (Symbol ^^ to separate envvar for different tags / Symbol ~> to define envvar for a tag / Symbol ## to separate multiple envvars)
     NOTE: Please enclose the entire input string with SINGLE quotes, but there is no need to enclose the variable values (Eg. 'VAR1=hello##VAR2=uname -a')
     NOTE: Please enclose the entire input string with DOUBLE quotes only if variable value contains single quote (Eg. "VAR1=abc'def##VAR2=uname -a")
-B = <execprep> in the format of tag~><sourcefile>:<targetfile> will be used to substitute the EXECPREP keyword in the EXECPREP column - Eg. TAG1~>/tmp/source:/tmp/target (separate multiple tags with ##)
-j = provided string [tag:<objname>##tag:<objname>##...] will be used to subtitute the OBJNAME keyword in OBJNAME column based on tagname in the manual-collect input configuration file - Eg. tag1:pod-abc##tag2:pod-xyz
     NOTE: Use keyword ALL to specify OBJNAME value applicable to all selected tags/config lines (Eg. tag1:pod-abc##ALL:pod-xyz)
-w = timeout value for manualcollect [-m] (default = 15m) - Eg. 10s where s=second; m=minute; h=hour
<EXTRA namespace mode>
-e = get data for extra namespaces (oc get all,pvc,configmap,secret,serviceaccount / oc describe / oc logs) - separate namespaces with comma(,) / special keywords of NS4PROD=<prodname> and ALLNS (all namespaces) are allowed
     NOTE: The [:extra-resources] is optional and is full path to a file that contains additional resource types (Eg. catalogsources, operandconfigs, etc) - specify one resource type per line in the file
     NOTE: Set [:extra-resources] to keyword 'ALL' to collect data for all resource types associated with the namespace (Eg. -e openshift-dns:ALL or ALLNS:ALL)
<MISSINGOBJ mode>
-x = product version to use for 'getMissingObj' function (Eg. -x 3.2.0 or -x X to auto-detect) OR absolute path of an input config file (Eg. -x /tmp/myfile.cfg) for the 'getMissingObj' function to use
<COMPLIANCE mode>
-A = <compliance-param> = TAGS:[input file for the getCompliance() function] where 'input file' is defaulted to compliance/<prod-version>/compliance.cfg (use keyword ALL to select all config lines / separate multiple tags with comma)
<PLUGINS mode>
-P = product plugin [supported=aimanager]:action [supported=data fix] (default action = data) (Eg. aimanager or aimanager:data or aimanager:fix) - separate plugins with comma(,)
-Z = environment variables for the plugins script - Eg. PLUGIN1~>VAR1=VAL1##VAR2=VAL2^^PLUGIN2~>VAR3=VAL3... (Symbol ^^ to separate envvar for different plugins / Symbol ~> to define envvar for a plugin / Symbol ## to separate multiple envvars)
     NOTE: PLUGIN is optional when there is only one plugin specified through -P option (Eg. -Z 'VAR1=VAL1##VAR2=VAL2')
     NOTE: Please enclose the entire input string with SINGLE quotes (Eg. 'VAR1=hello##VAR2=uname -a')
-Q = timeout value for plugins [-P] (default = 30m) - Eg. 10s where s=second; m=minute; h=hour
<CPFILES mode>
-F = to copy files in a pod -> cpfiles-param = TAGS or NAMESPACE##PODNAME##CONTAINER##FILES##LIMITS where multiple TAGS can be delimited by @@, CONTAINER is optional and FILES can be delimited by colon
     Eg. -F aimanager = will refer to cpfiles/cpfiles-<prodname>-<version>.cfg and copy all the files configured as TAG=aimanager
         -F NS4PROD=aimanager##^iaf-system-kafka-####/tmp/mydir##head -3 = manual command to copy file the newest 3 files in the target directory (LIMITS can be 'head -X' or 'tail -X'
     NOTE(1): You can use keyword 'NS4PROD=<prodname>' to obtain namespace for those products automatically
     NOTE(2): You can use asterisk(*), square brackets([]), question mark(?) and curly brackets({}) wildcards in FILES
     NOTE(3): Since 'tar' (needed by 'oc cp') command may not be available in the target pod/container, it is advisable to only use this option for text file ('oc exec/cat' will be used as secondary option)
<SNAPSHOTS mode>
-K = to perform snapshots comparison

[VIEW mode]
-V = <view-only-module> is a script that can be created under the <mustgather-install-dir>/config/view/<PRODUCT_VERSION> (precedence) or <mustgather-install-dir>/view directory
     NOTE(1): You can use '-V .listviews' to list down all available view-only-modules and their descriptions
     NOTE(2): Options '-W' and '-Y' can be used together with '-V'

[ALIAS mode]
-O = <alias-module> is an alias name configured as ALIAS_NAME in config file <mustgather-install-dir>/alias/<PRODUCT_VERSION>/alias.cfg
     NOTE(1): The 'alias' mode is used as shortcut for longer mustgather commad (Eg. -O aimgr => -cypDf -P aimanager)
     NOTE(2): You can use '-O .listalias' to list down all available alias-modules and their descriptions
     NOTE(3): Options '-o', '-W', '-Y' and '-D' can be used together with '-O', but their usage (except '-o' which is preserved) is limited during command expansion only

[Supporting Options]
-D = to increase log level to DEBUG
-f = collect PVC usage data (df -h) - NOTE: Only available with option -a, -c, -b, -l, -z (productinfo/storage/pvcusage), -k (pvc) and -e
-g = do NOT collect pod logs (oc logs and oc logs -p)
-G = filename regex and pattern (delimited by colon) to grep for (applicable to pod logs, events, cpfiles and node-related data files)
     separate patterns with double asperands(@@) and separate FILENAME_REGEX:PATTERNS keyvalue pairs with double hashes(##)
     use keyword ALL as filename regex as instruction to grep for all detected files
     use tilde(~) to perform piping grep (i.e. grep A <file> | grep B | grep C)
     escape tilde(~) with backward slash(\) for its literal value, but there is no need to escape colon(:)
     Eg. ALL:error@@failure or ^aimanager:error~fail or ^aimanager:error##ALL:failure or ALL:error\~fail##ALL:error\/fail
-h = help
-H = get pod dependency data [EXPERIMENTAL]
-i = path to SSH key (needed for cluster on cloud (AWS, GKE, etc) [EXPERIMENTAL]
-I = enable incident reporting [EXPERIMENTAL]
-J = collect JSON output (oc get -o json)
-M = disable auto upgrade
-N = turn on data collection for problematic non-product namespaces (data collection for problematic Openshift namespaces is enabled always)
-o = full path of output directory (default = /tmp/mg)
-p = collect logs for the previous instance of the container in a pod if it exists
-R = enable report-on-screen where SUMMARY.log will be printed on display
-s = to use SSH to collect logs and data from all cluster nodes (but do not have common admin username across the cluster)
-S = allow collection of sensitive data (secrets, certs, etc) explicitly
-t = do NOT collect 'oc describe'
-u = to provide the admin username that will be used to SSH to all clusder nodes for data collection purpose (passwordless SSH is needed)
-U = check for upgrade
-v = version
-W = to set global environment variables or system.cfg variables that the mustgather functions can use for further processing - Eg. -W 'VAR1=123##VAR2=456##VAR3=789' (delimit multiple variables with ## / all variables will be suffixed with string RTVAR_ when used internally - Eg. VAR1 => RTVAR_VAR1)
     [ADD_PVC_NS] - [For '-z pvcusage' only] To add extra namespaces (on top of product namespaces) when generating PVC Utilization Report [Eg. -W 'ADD_PVC_NS=rook-ceph,openshift-dns']
     [ADDRES] - Additional resource types for the primary mode to collect [Eg. -W 'ADDRES=scc,ingresses']
     [AIMGR_NS] - To provide AI Manager namespace manually [Eg. -W 'AIMGR_NS=cp4waiops']
     [ALIAS_PRODVER] - To set PRODUCT_VERSION global environment variable manually in ALIAS mode [Eg. -W 'ALIAS_PRODVER=3.7.2']
     [CPFILES_CFGFILE] - Full path to custom configuration file for CPFILES mode [Eg. -W 'CPFILES_CFGFILE=/tmp/cpfiles.cfg']
     [DISABLE_ALLNS_DATA] - To disable data collection for non-product namespaces [Eg. -W 'DISABLE_ALLNS_DATA=true']
     [DISABLE_CRD_DATA] - To disable data collection for CRDs [Eg. -W 'DISABLE_CRD_DATA=true']
     [DISABLE_EXTRA_DATA] - [For -k only] To set DISABLE_GENERAL_DATA and DISABLE_PROD_ANALYTICS to true [Eg. -W 'DISABLE_EXTRA_DATA=true']
     [DISABLE_GENERAL_DATA] - [For -k only] To disable data collection for general info (eg. nodes, storageclass, etc) [Eg. -W 'DISABLE_GENERAL_DATA=true']
     [DISABLE_MKT_DATA] - To disable data collection for 'openshift-marketplace' namespace [Eg. -W 'DISABLE_MKT_DATA=true']
     [DISABLE_OCS_DATA] - To disable data collection for 'openshift-storage' namespace [Eg. -W 'DISABLE_OCS_DATA=true']
     [DISABLE_OLM_DATA] - To disable data collection for 'openshift-operator-lifecycle-manager' namespace [Eg. -W 'DISABLE_OLM_DATA=true']
     [DISABLE_OPER_DATA] - To disable data collection for 'openshift-operators' namespace [Eg. -W 'DISABLE_OPER_DATA=true']
     [DISABLE_PROD_ANALYTICS] - To disable generation of health check report for product namespaces [Eg. -W 'DISABLE_PROD_ANALYTICS=true']
     [DISABLE_SCC_DATA] - To disable data collection that shows users/groups permission for scc [Eg. -W 'DISABLE_SCC_DATA=true']
     [EVTMGR_HYBRID_NS] - To provide Event Manager Hybrid namespace manually [Eg. -W 'EVTMGR_HYBRID_NS=cp4waiops-hybrid']
     [EVTMGR_NS] - To provide Event Manager namespace manually [Eg. -W 'EVTMGR_NS=cp4waiops-emgr']
     [EXCL_PROD_GROUP] - Product group(s) to be excluded from data collection [Eg. -W 'EXCL_PROD_GROUP="xxx,yyy"']
     [EXCL_PROD_NS] - Product namespace(s) to be excluded from data collection [Eg. -W 'EXCL_PROD_NS="NS4PROD=aimanager,NS4PROD=ics"']
     [GETALL_SUBSET_DATA] - [For -a only] To limit data collection based on a pre-defined list of resource types in getAll() function [Eg. -W 'GETALL_SUBSET_DATA=true']
     [GETALL_SUBSET_DATA] - Set to 'true' to limit '-a' option (getAll) to collecting data for pre-defined resource types instead of all resource types [Eg. -W 'GETALL_SUBSET_DATA=true']
     [INIT_SLEEP] - To set the sleep interval in 'seconds' in the initSetup() function when executing in container [Eg. -W 'INIT_SLEEP=3']
     [PRODVER] - To set PRODUCT_VERSION global environment variable manually [Eg. -W 'PRODVER=3.7.2']
     [SELECTIVE_CUSTOM_DATA] - To enable getCustomData() function in '-k' (SELECTIVE mode) [Eg. -W 'SELECTIVE_CUSTOM_DATA=true']
     [VIEW_PRODVER] - To set PRODUCT_VERSION global environment variable manually in VIEW mode [Eg. -W 'VIEW_PRODVER=3.7.2']
     [WAIOPS_CRD] - To specify the regex used during data collection for CRDs [Eg. -W 'WAIOPS_CRD="kafka|postgresql"']
-X = turn off custom data collection
-y = collect YAML output (oc get -o yaml)
-Y = auto-answer YES to question prompted

[RULES]
(1) User can select ZERO or ONE 'primary' mode.
(2) User can select ZERO, SOME OR ALL 'secondary' modes.
(3) User can combine ONE primary mode with ZERO, SOME or ALL 'secondary' modes.
(4) 'Secondary' modes can run independently without any 'primary' mode
(5) 'Secondary' modes selected (independently or with any primary mode) will be executed in the following precedence:
    [ clusternodes -> cmdexec -> manualcollect -> extra -> missingobj -> compliance -> plugins -> cpfiles -> snapshots ]
```

## USE CASES

(1) For **installation-related problems**, we recommend you use the command:
```
waiops-mustgather.sh -DO install
```

(2) For **general problems** (unsure about the root cause), we recommend you use the command:
```
waiops-mustgather.sh -DO general

NOTE: Only the "aimanager" plugin is available currently.
```

(3) If you are troubleshooting **application-related problems** and would like to perform **on-site grep** on all gathered pod logs, we recommend the command:
```
waiops-mustgather.sh -cypDf -P aimanager -G 'ALL:error|fail'

NOTE: Feel free to replace regex "error|fail" with a more suitable regex of your choice. Grep result will be available in 0-README-FIRST/GREP_* of the output file.
```

(4) If you want to perform a **corrective action** (eg. delete a pod to restart it), we recommend you write the script and execute the command:
```
waiops-mustgather.sh -C <script> -e <namespace>

WHERE:
<script> = a script that contains the corrective action
<namespace> = namespace where the resource/object that needs to be corrected is in

NOTE: The command above will execute your script and then perform data collection to allow you to rectify your fix. You can provide more than one namespces through the "-e" option (delimited by comma).
```

(5) If you want to perform a baseline data collection, followed by a corrective action through custom script, and then check for outcome of the corrective action (Eg. status of the deleted pod), and finally copy some files from the restarted pod:
```
waiops-mustgather.sh -cypDf -C <script> -e <namespace> -F 'NS4PROD=<prodname>##<podname-regex>##<container-name>##<filename>##<limits>'
```

(6) If you have to **execute commands on a certain pod** (but do not know its full name especially the UUID portion), you can make use of the "manualcollect" mode:
```
waiops-mustgather.sh -m <configfile>

<configfile> example:
@ TAG##NAMESPACE##OBJTYPE##OBJNAME##CONTAINER##EXECPREP##EXECCMD##POSTEXEC
ALL##NS4PROD=aimanager##pod##^aimanager-postgres-keeper######hostname;ps -ef##

NOTE: Take note that the podname is a REGEX. The tool will determine the full name of the pod automatically.

[OUTPUT - found in file 4-MANUALCOLLECT/<namespace>/<podname>.bash.exec] 
cp4waiops-postgres-keeper-0
UID          PID    PPID  C STIME TTY          TIME CMD
stolon         1       0  1 Nov09 ?        02:09:11 stolon-keeper --data-dir /stolon-data
stolon        29       1  0 Nov09 ?        00:00:00 [create-template] <defunct>
stolon        54       1  0 Nov09 ?        00:15:06 postgres -D /stolon-data/postgres -c unix_socket_directories=/tmp
stolon        59      54  0 Nov09 ?        00:00:09 postgres: checkpointer
stolon        60      54  0 Nov09 ?        00:00:10 postgres: background writer
stolon        61      54  0 Nov09 ?        00:01:00 postgres: walwriter
stolon        62      54  0 Nov09 ?        00:00:19 postgres: autovacuum launcher
stolon        63      54  0 Nov09 ?        00:02:47 postgres: stats collector
stolon        64      54  0 Nov09 ?        00:00:00 postgres: logical replication launcher
stolon   2905619      54  0 05:39 ?        00:00:00 postgres: cp4waiops cp4waiops 10.254.12.46(50562) idle
stolon   2906589      54  0 05:43 ?        00:00:00 postgres: cp4waiops cp4waiops 10.254.12.46(53384) idle
stolon   2918996       0  0 06:34 ?        00:00:00 bash -c hostname;ps -ef
stolon   2919006 2918996  0 06:34 ?        00:00:00 ps -ef
```

(7) If you just need to **collect product-specific data** (Eg. AI Manager), you can execute the "plugins" secondary collection mode standalone:
```
waiops-mustgather.sh -P aimanager
```

(8) If you just want **to check whether an installation is successful**:
```
waiops-mustgather.sh -x X -DR

NOTE: The command above will scan the product namespaces for missing resource/object based on configuration file provided under <MUSTGATHER-DIR>/missingobj/config/missingobj-waiops-<prodver>.csv.
```

(9) If you need **to copy some files from pod**:
```
waiops-mustgather.sh -D -F 'NS4PROD=aimanager##aimanager-aio-log-anomaly-detector-####/opt/ai4it/*.log*##'

NOTE: The command above will copy files/directories that match filename wildcard of '/opt/ai4it/*.log*' from pods that match regex 'aimanager-aio-log-anomaly-detector-' in the auto-resolved AI Manager namespace.
```

(10) Of course, you can also opt for the super-duper complex command like this:
```
waiops-mustgather.sh -aypDf -e ibm-common-services,openshift-operators -P aimanager -G 'ALL:error|fail|exception|login' -C /tmp/test.sh -E 'TEST1=uname -a##TEST2=date' -m cqlsh:manualcollect.csv -n 'SQL="describe tables"' -F spark 
```

(11) If the cluster that you are working on is slow or throttles a lot, you can scale down the MustGather through the "selective" primary collection mode:
```
waiops-mustgather.sh -DXy -k deployments,sts,pods,jobs,pvc

NOTE: The example above will disable custom data collection (-X), enable YAML collection (-y) and run the MustGather in "selective" primary collection mode (-k) to collect data on resources "deployments", "statefulsets", "pods", "jobs" and "pvc".
```

(12) It is possible to run some modules from the Bedrock MustGather within WAIOPS MustGather through the CMDEXEC data collection mode:
```
waiops-mustgather.sh -DY -C bedrock/mustgather.sh -E 'MODULES=automationfoundation##NAMESPACE=NS4PROD=aimanager' -T 60m

NOTE: Only the "automationfoundation" and "cloudpaks" are migrated so far.
```

(13) If you want to **check and download the latest version of the tool** (provided that you have access to the Internet):
```
waiops-mustgather.sh -UD

NOTE: Available only for MustGather Tool v0.25.2 and above.
```


## ADVANCED TIPS
(a) The MANUALCOLLECT mode is capable of executing 'oc exec' on pods, so it can be configured to perform some small tasks (eg. getting all ElasticSearch indexes)

**NOTE**: The WAIOPS MustGather Tool is shipped with some task configurations (refer to manualcollect/<prodver>/config/mc.cfg file in the package).
```
[root@api.waiops32d.cp.fyre.ibm.com waiops-mustgather]# ./waiops-mustgather.sh -DR -m lifecycle-policy:mc.cfg
...
===================================================
[MANUALCOLLECT] OUTPUT OF EXECCMD (PROD_GROUP = cp4waiops@ibm-cp-watson-aiops / PROD_VER = 4.1.1)
===================================================
[CFGFILE = /root/waiops/github/waiops-mustgather/manualcollect/4.1.1/config/mc.cfg]
[CFGLINE = lifecycle-policy##cp4waiops##pod##^aiops-ir-lifecycle-policy-registry-svc-######curl -u$(cat $SYSTEMAUTH_BINDING_DIR/username):$(cat $SYSTEMAUTH_BINDING_DIR/password) http://localhost:$PORT/policyregistry.ibm-netcool-prod.aiops.io/v1alpha/system/cfd95b7e-3bc7-4006-a4a8-a73a79c71255##]
[COMMAND = /usr/bin/timeout 15m oc exec -n cp4waiops aiops-ir-lifecycle-policy-registry-svc-79d48d4987-7dgff --request-timeout=15m -- bash -c 'curl -u$(cat $SYSTEMAUTH_BINDING_DIR/username):$(cat $SYSTEMAUTH_BINDING_DIR/password) http://localhost:$PORT/policyregistry.ibm-netcool-prod.aiops.io/v1alpha/system/cfd95b7e-3bc7-4006-a4a8-a73a79c71255' > /tmp/mg/waiops-manualcollect-02082023-022302/4-MANUALCOLLECT/TAG=lifecycle-policy/cp4waiops/aiops-ir-lifecycle-policy-registry-svc-79d48d4987-7dgff.bash.exec 2> /tmp/mg/waiops-manualcollect-02082023-022302/4-MANUALCOLLECT/TAG=lifecycle-policy/cp4waiops/aiops-ir-lifecycle-policy-registry-svc-79d48d4987-7dgff.bash.err]
[OUTFILE = /tmp/mg/waiops-manualcollect-02082023-022302/4-MANUALCOLLECT/TAG=lifecycle-policy/cp4waiops/aiops-ir-lifecycle-policy-registry-svc-79d48d4987-7dgff.bash.exec]
[POD = aiops-ir-lifecycle-policy-registry-svc-79d48d4987-7dgff]

[
  {
    "tenantid": "cfd95b7e-3bc7-4006-a4a8-a73a79c71255",
    "policyid": "6f38ff90-2af3-11ee-a6bf-8f842acb6bc3",
    "configuration": "{\"executionPriority\":101,\"state\":\"enabled\",\"spec\":{\"constants\":{},\"triggers\":[{\"entityId\":\"alert\",\"triggerId\":\"aiops.ibm.com/trigger/alert-updated\",\"arguments\":{}},{\"entityId\":\"alert\",\"triggerId\":\"aiops.ibm.com/trigger/alert-pre-create\",\"arguments\":{}}],\"actions\":[{\"actionId\":\"lang/if\",\"arguments\":{\"condition\":\"{{exists prevAlert}}\",\"then\":[{\"actionId\":\"aiops/enrichments/checkUnionUpdateRequired\",\"arguments\":{\"currentInsights\":{\"$variable\":\"alert.insights\"},\"prevInsights\":{\"$variable\":\"prevAlert.insights\"},\"condition\":\"{{insight.type}} == \\\"aiops.ibm.com/insight-type/relationship/causal\\\"\"},\"output\":\"runUnionAction\"}],\"else\":[{\"actionId\":\"lang/eval\",\"arguments\":{\"input\":true},\"output\":\"runUnionAction\"}]}},{\"actionId\":\"aiops.ibm.com/action/internal/conditional\",\"arguments\":{\"name\":\"Check if union action needs to be run\",\"condition\":\"{{ runUnionAction }}\",\"then\":[{\"actionId\":\"aiops/enrichments/union\",\"arguments\":{\"insights\":{\"$variable\":\"alert.insights\"},\"durationMS\":900000,\"source\":\"\",\"condition\":\"{{insight.type}} == \\\"aiops.ibm.com/insight-type/relationship/causal\\\"\"},\"output\":\"alert.insights.[]\"}]}}]},\"hash\":\"2afac914ee8dab371fe7d29b66337d4d8ab5a2f9\",\"revision\":\"f9aa2330875ae4a0f75a9958a44e8b2aae7b58d8\",\"hotfields\":[]}",
    "entityid": "[\"alert\",\"alert\"]",
    "metadata": "{\"labels\":{\"ibm.com/is-default\":\"true\"},\"name\":\"Derive the union of all correlated groups\",\"description\":\"Enriches a causal alert relationship that represents the union of all other causal alert relationships in order to form a super-group\",\"createdBy\":{\"id\":\"system\",\"type\":\"system\"},\"lastUpdatedBy\":{\"id\":\"system\",\"type\":\"system\",\"changeDetails\":\"Created\"},\"lastUpdatedTimestamp\":\"2023-07-25T13:59:12.647Z\",\"creationTimestamp\":\"2023-07-25T13:59:12.647Z\"}",
    "triggerid": "[\"aiops.ibm.com/trigger/alert-updated\",\"aiops.ibm.com/trigger/alert-pre-create\"]"
  },
...
```

(b) You can use the CPFILES to copy files from pods. 
From the example below, the tool pulls the /conf/redis/redis.conf file from all pods that match regex '^c-example-redis-m-'. 
The 'NS4PROD=' is a special keyword that instructs the tool to auto-resolve the namespace for product 'aimanager'. 
The usage of 'keyword' and 'regex' (avoid hardcoding) allows the configuration to be used across different environments without the need to re-configure (eg. from customer A to customer B).
```
[file cpfiles/config/cpfiles-waiops-320.csv in the package]
@ TAG##NAMESPACE##PODNAME##CONTAINER##REGEXSCRIPT##FILES##LIMITS
test##NS4PROD=aimanager##^c-example-redis-m-######/conf/redis/redis.conf##

[root@api.waiops32d.cp.fyre.ibm.com waiops32]# pwd
/tmp/waiops-cpfiles-01042022-173635/8-CPFILES/waiops32
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# ls -l c-example-redis-m-0/
total 56
-rw-r--r-- 1 root root 51281 Apr  1 17:36 '^conf^redis^redis.conf'
-rw-r--r-- 1 root root    78 Apr  1 17:36 '^conf^redis^redis.conf.ls'
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# ls -l c-example-redis-m-1
total 56
-rw-r--r-- 1 root root 51306 Apr  1 17:36 '^conf^redis^redis.conf'
-rw-r--r-- 1 root root    78 Apr  1 17:36 '^conf^redis^redis.conf.ls'
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# ls -l c-example-redis-m-2
total 56
-rw-r--r-- 1 root root 51306 Apr  1 17:36 '^conf^redis^redis.conf'
-rw-r--r-- 1 root root    78 Apr  1 17:36 '^conf^redis^redis.conf.ls'
[root@api.waiops32d.cp.fyre.ibm.com waiops32]#

```

(c) You can run your own script (Eg. for corrective action) within the WAIOPS MustGather Tool and perform data collection immediately after that all with one single execution/command.
```
Eg.
[Command]
./waiops-mustgather.sh -DR -C /tmp/elite.sh##/tmp/env.in -Y

[Environment Variables File - /tmp/env.in]
POD=teams
CMD=date > /tmp/date.out

NOTE: The user can use an environment variable file to pass in variables into the script.
```
```
[Custom Script]  
# Function "getProdToNamespacesMapping" can be used in any CMDEXEC script to obtain product namespace
NS=$(getProdToNamespacesMapping aimanager $CMD_EXEC_PRODUCT_NSFILE)
echo "NAMESPACE=$NS"

# Function "getResourceInstances can be used in any CMDEXEC script to obtain resource instances based on provided regex
for MYPOD in $(getResourceInstances pod $POD $NS)
do
MYCMD="oc exec $MYPOD -n $NS -- bash -c '$CMD'"
echo $MYCMD
eval $MYCMD
done

# Imagine the above is the codes for some corrective actions

# To make sure the correction actions are successful, you can trigger MANUALCOLLECT to collect some data within the script
echo "ALL,NS4PROD=aimanager,pod,teams,," >> $CMD_EXEC_RESULT_MCCFG_FILE

# You can also trigger EXTRA mode to collect namespace data within the script
echo "openshift-insights" > $CMD_EXEC_RESULT_EXTRANS_FILE

# If you need to copy some files from some pods to make sure your script ran OK, you can also do that within the script
echo "NS4PROD=aimanager,^iaf-system-kafka,,/opt/kafka/config/log4j.properties" >> $CMD_EXEC_RESULT_CPFILES_FILE
```
```
[Output]
(i) Command 'date > /tmp/date.out' executed in the pod
[root@api.waiops32d.cp.fyre.ibm.com tmp]# oc exec -it aimanager-aio-chatops-teams-integrator-545bc7d4d-9w8fp -- bash -c 'ls -l /tmp; cat /tmp/date.out'
Defaulted container "chatops-teams-integrator" out of: chatops-teams-integrator, controller-is-ready (init)
total 12
-rw-r--r--. 1 default root  29 Apr  2 01:00 date.out
-rwx------. 1 root    root 701 Sep 14  2021 ks-script-vzv5jj6c
-rwx------. 1 root    root 291 Sep 14  2021 ks-script-y5xeen0d
Sat Apr  2 01:00:25 UTC 2022
[root@api.waiops32d.cp.fyre.ibm.com tmp]#

(ii) Data of pod that matches regex 'teams' collected through MANUALCOLLECT
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# pwd
/tmp/waiops-cmdexec-01042022-175950/4-MANUALCOLLECT/TAG=ALL/waiops32
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# ls -l
total 4
-rw-r--r-- 1 root root 180 Apr  1 18:00 oc_pod-aimanager-aio-chatops-teams-integrator-545bc7d4d-9w8fp.out
drwxr-xr-x 2 root root 164 Apr  1 18:00 pod
[root@api.waiops32d.cp.fyre.ibm.com waiops32]# ls -l pod/
total 12
-rw-r--r-- 1 root root 1551 Apr  1 18:00 aimanager-aio-chatops-teams-integrator-545bc7d4d-9w8fp~chatops-teams-integrator.log
-rw-r--r-- 1 root root 7315 Apr  1 18:00 aimanager-aio-chatops-teams-integrator-545bc7d4d-9w8fp.desc
[root@api.waiops32d.cp.fyre.ibm.com waiops32]#

(iii) Data of namespace 'openshift-insights' collected through EXTRA
[root@api.waiops32d.cp.fyre.ibm.com openshift-insights]# pwd
/tmp/waiops-cmdexec-01042022-175950/5-EXTRA/openshift-insights
[root@api.waiops32d.cp.fyre.ibm.com openshift-insights]# ls -l
total 28
drwxr-xr-x 2 root root  132 Apr  1 18:00 configmaps
drwxr-xr-x 2 root root   36 Apr  1 18:00 deployment.apps
-rw-r--r-- 1 root root 1738 Apr  1 18:00 oc_all.out
-rw-r--r-- 1 root root  194 Apr  1 18:00 oc_configmaps.out
-rw-r--r-- 1 root root  328 Apr  1 18:00 oc_pod_scc.out
-rw-r--r-- 1 root root   52 Apr  1 18:00 oc_pvc.out
-rw-r--r-- 1 root root 1427 Apr  1 18:00 oc_secrets.out
-rw-r--r-- 1 root root  155 Apr  1 18:00 oc_serviceaccounts.out
drwxr-xr-x 2 root root  117 Apr  1 18:00 pod
drwxr-xr-x 2 root root   35 Apr  1 18:00 pvc
drwxr-xr-x 2 root root   86 Apr  1 18:00 replicaset.apps
drwxr-xr-x 2 root root 4096 Apr  1 18:00 secrets
drwxr-xr-x 2 root root   26 Apr  1 18:00 service
drwxr-xr-x 2 root root  107 Apr  1 18:00 serviceaccounts
[root@api.waiops32d.cp.fyre.ibm.com openshift-insights]#

(iv) Through CPFILES, file '/opt/kafka/config/log4j.properties' is copied from pod(s) that matches regex '^iaf-system-kafka'.
[root@api.waiops32d.cp.fyre.ibm.com iaf-system-kafka-0]# pwd
/tmp/waiops-cmdexec-01042022-175950/8-CPFILES/waiops32/iaf-system-kafka-0
[root@api.waiops32d.cp.fyre.ibm.com iaf-system-kafka-0]# ls -l
total 12
-rw-r--r-- 1 root root 4674 Apr  1 18:00 '^opt^kafka^config^log4j.properties'
-rw-r--r-- 1 root root   77 Apr  1 18:00 '^opt^kafka^config^log4j.properties.ls'
[root@api.waiops32d.cp.fyre.ibm.com iaf-system-kafka-0]# head ^opt^kafka^config^log4j.properties
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
[root@api.waiops32d.cp.fyre.ibm.com iaf-system-kafka-0]#
```

## THANK YOU! 
(0) **All WAIOPS L2** - For all the support and trust you have in the tool and feedback on how to make it better!   
(1) **Taylor George, Tom Seelbach, Vijai Kalathur, Veronica Boychuk** - For ever being so supportive and the many great suggestions that helped make WAIOPS MustGather a much better tool!    
(2) **Sami Salkosuo** - For contributing the idea of 'oc debug node' for data collection from individual nodes.    
(3) **Albert Chan** - For believing in GMGF and signed up as the 1st customer!   
(4) **Spencer Hsiesh** - For trusting in the tool and tirelessly convincing the BP/customer to use it for data collection purpose!    
(5) **Kristof Stroobants** - For promoting the tools tirelessly on Slack!   
(6) **Matthew Thornhill** - For sharing product technical knowledge and precious time to make WAIOPS MustGather better in collecting lifecycle data!    
(7) **Mat Davis** - For inspiring the "read timeout" enhancement, so that the tool will not wait indefinitely for user input.    
(8) **Karline Vilme** - For raising an enhancement request for an internal QA workflow need that resulted in an improvement to the tool in the "default to latest product version" area.  
