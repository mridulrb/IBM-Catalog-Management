OPER=$1

OPER_CLUSTER=$($OC_CMD get po -n openshift-operators --no-headers | $AWK '$1 ~ /'$OPER'/ { print $1 }')

if [ ${#OPER_CLUSTER} -gt 0 ]
then
	echo "openshift-operators"
else
	NS=$(getProdToNamespacesMapping aimanager $MISSINGOBJ_PROD_GROUP_NS_REFFILE)
	
	if [ ${#NS} -eq 0 ]
	then
	        echo ""
	        exit 1
	else
	        echo $NS
	fi
fi
