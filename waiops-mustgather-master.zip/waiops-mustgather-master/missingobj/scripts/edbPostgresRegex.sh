NAMESPACE=$1

INSTALL_NAME=$($OC_CMD get install --no-headers -n $NAMESPACE | $AWK '{ print $1 }')

if [ ${#INSTALL_NAME} -gt 0 ]
then
	echo "^${INSTALL_NAME}-edb-postgres-"
else
	echo ""
	exit 1
fi
