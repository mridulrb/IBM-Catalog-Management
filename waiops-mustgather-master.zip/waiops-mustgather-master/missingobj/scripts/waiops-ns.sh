PROD=$1

NS=$($OC_CMD get $PROD -A -o=jsonpath='{.items[*].metadata.namespace}')

if [ ${#NS} -eq 0 ]
then
	echo ""
	exit 1
else
	echo $NS
fi
