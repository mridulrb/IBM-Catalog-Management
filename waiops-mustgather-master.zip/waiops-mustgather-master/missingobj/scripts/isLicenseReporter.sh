if $OC_CMD get IBMLicenseServiceReporter -n ibm-common-services --no-headers > /dev/null
then
	LIC_REP_POD=$($OC_CMD get IBMLicenseServiceReporter -n ibm-common-services --no-headers | $AWK '{ print $1 }')

	if [ ${#LIC_REP_POD} -gt 0 ]
	then
		echo 0
	else
		echo 1
	fi
else
	echo 1
fi
