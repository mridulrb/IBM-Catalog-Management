JOBNAME_REGEX=$1
NS=$2

EXIT_STATUS=1
WORKFILE_ARR=()
JOB_COUNT=$($OC_CMD get -n $NS --ignore-not-found job --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}' | egrep "$JOBNAME_REGEX" | wc -l)

if [ ${#JOB_COUNT} -gt 0 ] 
then
	if [ $JOB_COUNT -gt 1 ]
	then
		for JOB in $($OC_CMD get -n $NS --ignore-not-found job --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}' | egrep "$JOBNAME_REGEX")	
		do
			WORKFILE=/tmp/isJobComplete.$NS.$JOB.$$
			$OC_CMD describe job -n $NS $JOB > $WORKFILE 2> /dev/null
			WORKFILE_ARR[${#WORKFILE_ARR[@]}]=$WORKFILE
			# echo $WORKFILE
		done
	else
		WORKFILE=/tmp/isJobComplete.$NS.$JOBNAME_REGEX.$$
		$OC_CMD describe job -n $NS $JOBNAME_REGEX > $WORKFILE 2> /dev/null
		WORKFILE_ARR[${#WORKFILE_ARR}]=$WORKFILE
	fi
else
	# WORKFILE=/tmp/isJobComplete.$NS.$JOBNAME_REGEX.$$
	# $OC_CMD describe job -n $NS $JOBNAME_REGEX > $WORKFILE 2> /dev/null
	# WORKFILE_ARR[${#WORKFILE_ARR}]=$WORKFILE

	# If the job is not found, remove the config line
	echo $EXIT_STATUS
	exit 
fi

# echo "COUNT = ${#WORKFILE_ARR[@]}"
# ls -l /tmp/isJobComplete*

for TMPFILE in ${WORKFILE_ARR[@]}
do
	if [ -s $TMPFILE ]
	then
		JOBNAME=$(egrep '^Name:' $TMPFILE | $AWK '{ print $2 }')	
		JOB_COMPLETIONS=$(egrep '^Completions:' $TMPFILE | $AWK '{ print $2 }')
		JOB_PODSTATUS=$(egrep '^Pods Statuses:' $TMPFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//')
		# echo "JOB = $JOBNAME"
		# echo "JOB_COMPLETIONS = $JOB_COMPLETIONS"
		# echo "JOB_PODSTATUS = $JOB_PODSTATUS"
		
		if [ ${#JOB_COMPLETIONS} -gt 0 ] && [ ${#JOB_PODSTATUS} -gt 0 ]
		then
			if [ $JOB_COMPLETIONS -eq 1 ]
			then
				JOB_RUN=$(echo $JOB_PODSTATUS | $AWK -F/ '{ print $1 }' | $AWK '{ print $1 }')
				JOB_SUCC=$(echo $JOB_PODSTATUS | $AWK -F/ '{ print $2 }' | $AWK '{ print $1 }')
				JOB_FAIL=$(echo $JOB_PODSTATUS | $AWK -F/ '{ print $3 }' | $AWK '{ print $1 }')
				# echo "JOB_RUN = $JOB_RUN"
				# echo "JOB_SUCC = $JOB_SUCC"
				# echo "JOB_FAIL = $JOB_FAIL"

				if [ $JOBNAME == "evtmanager-healthcron-27868861" ]
				then
					JOB_RUN=100
			 	fi
		
				# echo "JOB_RUN = $JOB_RUN"

				if [ $JOB_RUN -gt 0 ] || [ $JOB_FAIL -gt 0 ]
				then
					EXIT_STATUS=0
					break
				else
					if [ $JOB_SUCC -gt 0 ]
					then
						# Job is successful - remove the config line
						EXIT_STATUS=1
					else
						EXIT_STATUS=0
						break
					fi
				fi
			else
				EXIT_STATUS=0
				break
			fi
		else
			# Unable to find the job/extract job info - remove the config line
			EXIT_STATUS=1
			break
		fi
	
		rm -f $TMPFILE
	else
		if [ -f $TMPFILE ]
		then
			rm -f $TMPFILE
		fi
	
		# Unable to find the job - remove the config line
		EXIT_STATUS=1
		break
	fi
done

if [ $EXIT_STATUS -eq 0 ]
then
	for TMPFILE in ${WORKFILE_ARR[@]}
	do
		if [ -f $TMPFILE ]
		then
			rm -f $TMPFILE
		fi
	done
fi

echo $EXIT_STATUS
