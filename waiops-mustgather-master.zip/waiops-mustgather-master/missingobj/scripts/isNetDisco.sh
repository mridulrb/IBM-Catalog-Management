NS=$1 

NOI_INSTANCE=$($OC_CMD get noi -n $NS --no-headers | $AWK '{ print $1 }')
# echo $NOI_INSTANCE

ISNETDISCO=$($OC_CMD get noi -n $NS $NOI_INSTANCE -o=jsonpath='{.spec.topology.netDisco}')
# echo $ISNETDISCO

if [ ${#ISNETDISCO} -gt 0 ]
then
	if [ $ISNETDISCO == "false" ]
	then
		echo 1
	else
		echo 0
	fi
else
	# Remove the config line if '{.spec.topology.netDisco}' is not available
	echo 1
fi
