EVTMGR_NAMESPACE=$1

EVTMGR_INSTALL_NAME=$($OC_CMD get noi --no-headers -n $EVTMGR_NAMESPACE | $AWK '{ print $1 }')

if [ ${#EVTMGR_INSTALL_NAME} -eq 0 ]
then
	echo "1"
else
	EVTMGR_INSTALL_SIZE=$($OC_CMD get noi $EVTMGR_INSTALL_NAME -n $EVTMGR_NAMESPACE -o=jsonpath="{.spec.deploymentType}")

	if [ ${#EVTMGR_INSTALL_SIZE} -eq 0 ]
	then
		echo "1"
	else
		if [ $EVTMGR_INSTALL_SIZE == "trial" ]
		then
			echo "0"
		else
			echo "1"
		fi
	fi
fi
