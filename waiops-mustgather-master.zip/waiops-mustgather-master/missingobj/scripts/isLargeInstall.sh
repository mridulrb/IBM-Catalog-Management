AIMGR_NAMESPACE=$1

AIMGR_INSTALL_NAME=$($OC_CMD get installations.orchestrator.aiops.ibm.com --no-headers -n $AIMGR_NAMESPACE | $AWK '{ print $1 }')

if [ ${#AIMGR_INSTALL_NAME} -eq 0 ]
then
	echo "1"
else
	AIMGR_INSTALL_SIZE=$($OC_CMD get installations.orchestrator.aiops.ibm.com $AIMGR_INSTALL_NAME -n $AIMGR_NAMESPACE -o=jsonpath="{.status.size}")

	if [ ${#AIMGR_INSTALL_SIZE} -eq 0 ]
	then
		echo "1"
	else
		if [ $AIMGR_INSTALL_SIZE == "large" ]
		then
			echo "0"
		else
			echo "1"
		fi
	fi
fi
