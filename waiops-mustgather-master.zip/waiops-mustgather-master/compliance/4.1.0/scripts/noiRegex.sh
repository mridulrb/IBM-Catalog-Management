PART_OBJNAME=$1
NAMESPACE=$2

NOI_INSTANCE=$($OC_CMD get noi -n $NAMESPACE --no-headers | $AWK '{ print $1 }')

if [ ${#NOI_INSTANCE} -gt 0 ]
then
	echo "^${NOI_INSTANCE}-${PART_OBJNAME}"
else
	echo ""
	exit 1
fi
