IN_SUBS=$1
EXIT_STATUS=0

SUB_CTR=0

for SUB in $(echo "$IN_SUBS" | sed 's/,/ /g')
do
	(( SUB_CTR=SUB_CTR+1 ))

	SUB_NS=$(echo "$SUB" | $AWK -F/ '{ print $1 }')
	SUB_NAME=$(echo "$SUB" | $AWK -F/ '{ print $3 }')
	SUB_MSG=$($OC_CMD get subscription $SUB_NAME -n $SUB_NS -o jsonpath='{.status.conditions[?(@.type=="ResolutionFailed")].message}')
	
	if [ ${#SUB_MSG} -gt 0 ]
	then
		echo "($SUB_CTR) $SUB_NAME = [$SUB_MSG]"

		if [[ "$SUB_MSG" =~ .*"clusterserviceversion ".* ]]
		then
			CSV_NAME=$(echo "$SUB_MSG" | $AWK -F'clusterserviceversion ' '{ print $2 }' | $AWK '{ print $1 }')
			echo ">>> [FIX] $OC_CMD delete csv $CSV_NAME -n $SUB_NS"
			echo "$OC_CMD delete csv $CSV_NAME -n $SUB_NS" >> $3
		fi

		EXIT_STATUS=1	
	else
		echo "($SUB_CTR) $SUB_NAME = [OK]"
	fi
done

exit $EXIT_STATUS
