while read CLINE
do
	echo "[$(date)] [$(basename "$0")] Executing command [$CLINE"..."
	eval "$CLINE"
done < $1
