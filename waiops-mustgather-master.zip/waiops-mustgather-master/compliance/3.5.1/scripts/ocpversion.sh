OC_SUPPORTED="false"
SUPPORTED_OC_VER=(4.8 4.10)

OC_VER_INPUT=$($OC_CMD version | egrep '^Server' | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//')
OC_VER=${OC_VER_INPUT%.*}
OC_PATCH_VER=$(echo "$OC_VER_INPUT" | $AWK -F. '{ print $3 }')

for VER in ${SUPPORTED_OC_VER[@]}
do
	if [ $OC_VER == "$VER" ]
	then
		if [ ${#OC_PATCH_VER} -gt 0 ]
		then	
			case $OC_VER in
				4.8)	if [ $OC_PATCH_VER -ge 43 ]
					then
						OC_SUPPORTED="true"
						echo "Openshift version [$OC_VER_INPUT] is supported!"
					fi;;
				4.10)	if [ $OC_PATCH_VER -ge 17 ]
					then
						OC_SUPPORTED="true"
						echo "Openshift version [$OC_VER_INPUT] is supported!"
					fi;;
			esac
		fi
	fi
done

if [ $OC_SUPPORTED == "true" ]
then
	exit 0
else
	echo "[WAIOPS $PRODUCT_VERSION] Supported Openshift versions = 4.8.43 or higher / 4.10.17 or higher"
	echo "Openshift version [$OC_VER_INPUT] is NOT supported!"
	exit 1
fi

