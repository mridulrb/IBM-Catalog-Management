OC_SUPPORTED="false"
SUPPORTED_OC_VER=(4.6 4.8 4.10)
echo "[WAIOPS $PRODUCT_VERSION] Supported Openshift versions = [${SUPPORTED_OC_VER[@]}]"

OC_VER_INPUT=$($OC_CMD version | egrep '^Server' | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//')
# OC_VER=$(echo "$OC_VER_INPUT" | $AWK -F. '{ $NF=""; print }')
OC_VER=${OC_VER_INPUT%.*}

for VER in ${SUPPORTED_OC_VER[@]}
do
	if [ $OC_VER == "$VER" ]
	then
		OC_SUPPORTED="true"
		echo "Openshift version [$OC_VER_INPUT] is supported!"
	fi
done

if [ $OC_SUPPORTED == "true" ]
then
	exit 0
else
	echo "Openshift version [$OC_VER_INPUT] is NOT supported!"
	exit 1
fi

