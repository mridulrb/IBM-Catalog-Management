case $1 in 
	NO_OBJNAME)
		echo "No object name!"
		;;	
	YES_OBJNAME)
		echo "Yes object name!"
		;;	
	PROC_OBJNAME)
		DATA_INFO_NS=$(echo "$INCIDENT_DATA_INFO" | $AWK -F= 'BEGIN { RS=";" } $1 ~ /^NAMESPACE$/ { print $2 }')
		GENERIC_PODNAME=$(getGenericPodName $INCIDENT_OBJECT_NAME $DATA_INFO_NS)

		echo "$INCIDENT_OBJECT_TYPE"
		echo "$GENERIC_PODNAME"
		echo "$INCIDENT_DATA_TYPE"
		echo "$INCIDENT_DATA_INFO"
		echo "$INCIDENT_DATA"
		;;
	*)	echo "Invalid preproc mode [$1]!"
		;; 
esac

