echo "OBJNAME = $INCIDENT_OBJECT_NAME"
echo "INFO = $INCIDENT_DATA_INFO"
echo "DATA = $INCIDENT_DATA"
echo

DATA_INFO_NS=$(echo "$INCIDENT_DATA_INFO" | $AWK -F= 'BEGIN { RS=";" } $1 ~ /^NAMESPACE$/ { print $2 }')
POD_STATE=$($OC_CMD get -n $DATA_INFO_NS po $INCIDENT_OBJECT_NAME --no-headers | $AWK '{ print $3 }')

case "$POD_STATE" in
	CrashLoopBackOff)
		echo "RECOMMENDATION:"
		echo "Pod [$INCIDENT_OBJECT_NAME] is in state [$POD_STATE]. Please refer to the following for solution:"
		echo "https://supportcontent.ibm.com/support/pages/node/6583563"
		;;
	*) echo "[$POD_STATE] Error getting analysis!"
		;;	
esac
