checkEventsOperator()
{
	POD_LINE_CTR=0
	IFS=$'\n'

	echo "Checking 'ibm-events-operator' pods in 'ibm-common-services' namespace..."

	for POD_LINE in $($OC_CMD get -n ibm-common-services po --no-headers | egrep '^ibm-events-operator-')	
	do
		# echo "POD_LINE = $POD_LINE"
		(( POD_LINE_CTR=POD_LINE_CTR+1 ))
		isPodLineOk $POD_LINE > /dev/null
		POD_QUERY_STATUS=$?
		
		if [ $POD_QUERY_STATUS -eq 0 ]
		then
			EVENTS_OPERATOR_POD=$(echo "$POD_LINE" | $AWK '{ print $1 }')

			if [ ${#EVENTS_OPERATOR_POD} -gt 0 ]
			then
				echo "(#$POD_LINE_CTR) EVENTS_OPERATOR_POD = [$EVENTS_OPERATOR_POD]"
				ERROR_INDICATOR=$(oc logs -n ibm-common-services $EVENTS_OPERATOR_POD | egrep 'Failed to acquire lock lock')
		
				if [ ${#ERROR_INDICATOR} -gt 0 ]
				then
					echo "LOGS:"
					echo -e "$ERROR_INDICATOR" | head -5
					echo
					echo "RECOMMENDATION:"
					echo "(1) Find the ibm-events-operator pod name by running the following command:"
					echo "oc get pod -l app.kubernetes.io/name=ibm-events-operator -n ibm-common-services"
					echo "(2) Delete the ibm-events-operator pod."
					echo "oc delete pod $EVENTS_OPERATOR_POD -n ibm-common-services"
					echo
				else
					echo "(#$POD_LINE_CTR) Error getting analysis - unable to obtain error log of Events Opreator pod [$EVENTS_OPERATOR_POD]!"
				fi
			else
				echo "(#$POD_LINE_CTR) Error getting analysis - unable to obtain name of Events Opreator pod [$EVENTS_OPERATOR_POD]!"
			fi
		else
			echo "(#$POD_LINE_CTR) Error getting analysis - unable to obtain error log of Events Opreator pod [$POD_LINE]"
		fi
	done
}

checkImageRegistry()
{
	$OC_CMD describe -n $DATA_INFO_NS po $INCIDENT_OBJECT_NAME | $AWK '/^Events:/{f=1}f'
}

echo "OBJNAME = $INCIDENT_OBJECT_NAME"
echo "INFO = $INCIDENT_DATA_INFO"
echo "DATA = $INCIDENT_DATA"
echo

DATA_INFO_NS=$(echo "$INCIDENT_DATA_INFO" | $AWK -F= 'BEGIN { RS=";" } $1 ~ /^NAMESPACE$/ { print $2 }')
POD_STATE=$($OC_CMD get -n $DATA_INFO_NS po $INCIDENT_OBJECT_NAME --no-headers | $AWK '{ print $3 }')

case "$POD_STATE" in
	CreateContainerConfigError)
		checkEventsOperator
		;;
	Init:ImagePullBackOff|ImagePullBackOff)
		checkImageRegistry
		;;
	*) echo "[$POD_STATE] Error getting analysis!"
		;;
esac

