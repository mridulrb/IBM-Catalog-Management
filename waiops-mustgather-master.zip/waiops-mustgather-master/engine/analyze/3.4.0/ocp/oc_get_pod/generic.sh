getContainerCreating()
{
	$OC_CMD describe pod -n $DATA_INFO_NS $INCIDENT_OBJECT_NAME | $AWK '/^Events:/{f=1}f'
}

getImagePullErr()
{
	$OC_CMD describe pod -n $DATA_INFO_NS $INCIDENT_OBJECT_NAME | $AWK '/^Events:/{f=1}f'
}

DATA_INFO_NS=$(echo "$INCIDENT_DATA_INFO" | $AWK -F= 'BEGIN { RS=";" } $1 ~ /^NAMESPACE$/ { print $2 }')
POD_STATE=$($OC_CMD get -n $DATA_INFO_NS po $INCIDENT_OBJECT_NAME --no-headers | $AWK '{ print $3 }')

case "$POD_STATE" in
	ContainerCreating) 
		getContainerCreating
		;;		
	ImagePullBackOff|ErrImagePull)
		getImagePullErr
		;;		
	*) echo "[$POD_STATE] Error getting analysis!"
		;;
esac

