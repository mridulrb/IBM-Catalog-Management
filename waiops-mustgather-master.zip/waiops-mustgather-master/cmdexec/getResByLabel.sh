NAMESPACE=${1:-$LBL_NS}
OBJTYPE=${2:-$LBL_OBJTYPE}
LABEL=${3:-$LBL_LABEL}

if [ $MG_DEBUG == "true" ]
then
	echo "[$(date)] [$(basename "$0")] NAMESPACE = [$NAMESPACE] / OBJTYPE = [$OBJTYPE] / LABEL = [$LABEL]"
fi

if [ ${#NAMESPACE} -eq 0 ]
then
	echo "[$(date)] [$(basename "$0")] Variable NAMESPACE is empty/null! Exiting..." >&2
	exit 1
fi

if [ ${#OBJTYPE} -eq 0 ]
then
	echo "[$(date)] [$(basename "$0")] Variable OBJTYPE is empty/null! Exiting..." >&2
	exit 1
else
	OBJTYPE=$(echo "$OBJTYPE" | sed 's/,/ /g')
fi

if [ ${#LABEL} -eq 0 ]
then
	echo "[$(date)] [$(basename "$0")] Variable LABEL is empty/null! Exiting..." >&2
	exit 1
else
	LABEL=$(echo "$LABEL" | sed 's/,/ /g')
fi

if [ $NAMESPACE == "ALLPRODNS" ]
then
	NS_LIST=$(getUniqueProdNamespaces $CMD_EXEC_PRODUCT_NSFILE)
else
	NS_LIST=$(echo "$NAMESPACE" | sed 's/,/ /g')
fi

echo "[$(date)] [$(basename "$0")] NS_LIST = [$NS_LIST]"

if [ ${#NS_LIST} -gt 0 ]
then
	for NS_LINE in $NS_LIST
	do
		case "$NS_LINE" in
			NS4PROD=*)
				PROD=$(echo "$NS_LINE" | $AWK -F= '{ print $2 }')
				NS_LIST_PROC=$(getProdToNamespacesMapping $PROD $CMD_EXEC_PRODUCT_NSFILE)
				;;
			*=*)
				NS_LIST_PROC=$(echo "$NS_LINE" | sed 's/.*=//' | sed 's/,/ /g')
				;;
			*)	NS_LIST_PROC="$NS_LINE"
				;;
		esac	

		echo "[$(date)] [$(basename "$0")] NS_LIST_PROC = [$NS_LIST_PROC]"

		for NS in $NS_LIST_PROC 
		do
			echo "[$(date)] [$(basename "$0")] NS = [$NS]"

			for OBJ in $OBJTYPE
			do
				echo "[$(date)] [$(basename "$0")] OBJ = [$OBJ]"

				for LBL_LINE in $LABEL
				do
					echo "[$(date)] [$(basename "$0")] LBL_LINE = [$LBL_LINE]"
	
					if [ $OBJ == "all" ]
					then
						CMD="$OC_CMD get $OBJ -n $NS -l $LBL_LINE --template '{{range .items}}{{.kind}}{{\"/\"}}{{.metadata.name}}{{\" \"}}{{end}}'"
					else
						CMD="$OC_CMD get $OBJ -n $NS -l $LBL_LINE --template '{{range .items}}{{.metadata.name}}{{\" \"}}{{end}}'"
					fi
	
					echo "[$(date)] [$(basename "$0")] CMD = [$CMD]"
	
					for RESOURCE in $(eval "$CMD")
					do
						echo "[$(date)] [$(basename "$0")] RESOURCE = [$RESOURCE]"
						
						if [ $OBJ == "all" ]
						then
							KIND=$(echo "$RESOURCE" | $AWK -F/ '{ print tolower($1) }')
							NAME=$(echo "$RESOURCE" | $AWK -F/ '{ print $2 }')
	
							OUTPUT="ALL${MANUAL_COLL_CFGFILE_DELIMITER}${NS}${MANUAL_COLL_CFGFILE_DELIMITER}${KIND}${MANUAL_COLL_CFGFILE_DELIMITER}^${NAME}\$${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}"
						else
							OUTPUT="ALL${MANUAL_COLL_CFGFILE_DELIMITER}${NS}${MANUAL_COLL_CFGFILE_DELIMITER}${OBJ}${MANUAL_COLL_CFGFILE_DELIMITER}^${RESOURCE}\$${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}${MANUAL_COLL_CFGFILE_DELIMITER}"
						fi
	
						echo "[$(date)] [$(basename "$0")] OUTPUT = [$OUTPUT]"
						echo "$OUTPUT" >> $CMD_EXEC_RESULT_MCCFG_FILE
					done
				done
			done
		done
	done
else
	echo "[$(date)] [$(basename "$0")] Variable NS_LIST is empty/null! Exiting..." >&2
	exit 1
fi
