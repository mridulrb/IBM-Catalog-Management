PATH=$PATH:$MUSTGATHER_DIRNAME/cmdexec/bedrock

if [ -z "${NAMESPACE}" ]
then
	NAMESPACE=$(getProdToNamespacesMapping aimanager $CMD_EXEC_PRODUCT_NSFILE)
else
	FINAL_NAMESPACE=""
	
	echo "NAMESPACE = $NAMESPACE"

	for NS in $(echo "${NAMESPACE}" | sed 's/,/ /g')
	do
		echo "NS = $NS"

		if [[ $NS =~ ^NS4PROD= ]]
		then
			PROD=$(echo "$NS" | $AWK -F= '{ print $2 }')
			MYNS=$(getProdToNamespacesMapping $PROD $CMD_EXEC_PRODUCT_NSFILE)
		else
			MYNS=$NS
		fi

		if [ -z "${FINAL_NAMESPACE}" ]
		then
			FINAL_NAMESPACE="$MYNS"
		else
			FINAL_NAMESPACE="$FINAL_NAMESPACE,$MYNS"
		fi
	done

	NAMESPACE="$FINAL_NAMESPACE"
fi

CMD="gather -m $MODULES -n $NAMESPACE"
echo "COMMAND = $CMD"
eval "$CMD"
