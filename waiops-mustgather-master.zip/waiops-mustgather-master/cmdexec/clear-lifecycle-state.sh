AIMGR_NAMESPACE=$(getProdToNamespacesMapping aimanager $CMD_EXEC_PRODUCT_NSFILE)

# Scale down lifecycle
$OC_CMD scale deployment/ir-lifecycle-operator-controller-manager -n $AIMGR_NAMESPACE --replicas=0

# Patch lifecycle
$OC_CMD patch lifecycletrigger aiops -n $AIMGR_NAMESPACE --type=json -p='[{"op": "remove", "path": "/metadata/annotations"}]' 

# sleep 3

CARTRIDGE_REQ_NAME="cp4waiops-cartridge"
KAFKA_POD="iaf-system-kafka-0"

KAFKA_BROKER="$($OC_CMD get svc -n $AIMGR_NAMESPACE iaf-system-kafka-bootstrap --no-headers | $AWK '{ print $1 }'):9093"
KAFKA_USERNAME=$($OC_CMD get cartridgerequirements "${CARTRIDGE_REQ_NAME}" -n $AIMGR_NAMESPACE -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].authentication.secret.secretName}')
KAFKA_SASL_PASSWORD=$($OC_CMD get secret "${KAFKA_USERNAME}" -n $AIMGR_NAMESPACE -o jsonpath='{.data.password}' | base64 --decode)
KAFKA_CA_SECRET_NAME=$($OC_CMD get cartridgerequirements -n $AIMGR_NAMESPACE ${CARTRIDGE_REQ_NAME} -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].caSecret.secretName}')
KAFKA_CA_CERT=$CMD_EXEC_OUTPUT_DIR/mg_ca.crt

$OC_CMD extract secret/$KAFKA_CA_SECRET_NAME -n $AIMGR_NAMESPACE --keys=ca.crt --to=-> $KAFKA_CA_CERT

if [ $MG_DEBUG == "true" ]
then
	echo "[$(date)] [${FUNCNAME[0]}] KAFKA_BROKER = $KAFKA_BROKER"
	echo "[$(date)] [${FUNCNAME[0]}] KAFKA_SASL_PASSWORD = ${#KAFKA_SASL_PASSWORD} (length)"
	echo "[$(date)] [${FUNCNAME[0]}] KAFKA_CA_CERT = $(ls -l $KAFKA_CA_CERT)"
fi

if [ ${#KAFKA_BROKER} -gt 0 ] && [ ${#KAFKA_SASL_PASSWORD} -gt 0 ] && [ -s $KAFKA_CA_CERT ]
then
	# Create configuration files needed for kafka-console-consumer.sh
	KAFKA_CONSUMER_CFGFILE=$CMD_EXEC_OUTPUT_DIR/mg_consumer.cfg
	KEYSTORE_DIR="/tmp"
	KEYSTORE_NAME="$KEYSTORE_DIR/mg_truststore.pfx"
	KEYSTORE_PASSWORD="changeme"
	KEYSTORE_CONSUMER_CFGFILE=$KEYSTORE_DIR/$(basename $KAFKA_CONSUMER_CFGFILE)
	KEYSTORE_CERT=$KEYSTORE_DIR/$(basename $KAFKA_CA_CERT)

	echo "bootstrap.servers=${KAFKA_BROKER}" > $KAFKA_CONSUMER_CFGFILE
	echo "security.protocol=SASL_SSL" >> $KAFKA_CONSUMER_CFGFILE
	echo "ssl.protocol=TLSv1.2" >> $KAFKA_CONSUMER_CFGFILE
	echo "ssl.enabled.protocols=TLSv1.2" >> $KAFKA_CONSUMER_CFGFILE
	echo "ssl.truststore.location=$KEYSTORE_NAME" >> $KAFKA_CONSUMER_CFGFILE
	echo "ssl.truststore.password=$KEYSTORE_PASSWORD" >> $KAFKA_CONSUMER_CFGFILE
	echo "sasl.mechanism=SCRAM-SHA-512" >> $KAFKA_CONSUMER_CFGFILE
	echo "sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username=\"${KAFKA_USERNAME}\" password=\"${KAFKA_SASL_PASSWORD}\";" >> $KAFKA_CONSUMER_CFGFILE

	# Copy config file to Kafka pod
	$OC_CMD cp $KAFKA_CONSUMER_CFGFILE -n $AIMGR_NAMESPACE ${KAFKA_POD}:${KEYSTORE_DIR}

	# Create certificate in Kafka pod
	$OC_CMD cp $KAFKA_CA_CERT -n $AIMGR_NAMESPACE ${KAFKA_POD}:${KEYSTORE_DIR}
	
	# Import certificate
	# echo -n "changeme" > "${KEYSTORE_DIR}/truststore_pw.txt"
	CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c 'keytool -import -keystore ${KEYSTORE_NAME} -storetype PKCS12 -alias CARoot -file ${KEYSTORE_CERT} -noprompt -storepass $KEYSTORE_PASSWORD'"
	echo "$CMD"
	eval "$CMD"

	# Do Kafka stuff!!
	CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c '/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server $KAFKA_BROKER --command-config ${KEYSTORE_CONSUMER_CFGFILE} --list'"
	# CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c '/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server $KAFKA_BROKER --command-config ${KEYSTORE_CONSUMER_CFGFILE} --list'"
	echo "$CMD"
	eval "$CMD" > $CMD_EXEC_OUTPUT_DIR/consumer_groups.lst

	IFS=$'\n'
	for CONSUMER_GROUP in $(grep 'cp4waiops-cartridge\.aiops-ir-lifecycle\.' $CMD_EXEC_OUTPUT_DIR/consumer_groups.lst | sed 's/^/--group /')
	do
		# Delete consumer group
		CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c '/opt/kafka/bin/kafka-consumer-groups.sh --bootstrap-server $KAFKA_BROKER --command-config ${KEYSTORE_CONSUMER_CFGFILE} -delete ${CONSUMER_GROUP}'"
		echo "$CMD"
		eval "$CMD"
	done

	# Clean up 
	echo "[$(date)] [${FUNCNAME[0]}] Deleting certificate from keystore..."
	CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c 'keytool -delete -keystore ${KEYSTORE_NAME} -storetype PKCS12 -alias CARoot -noprompt -storepass $KEYSTORE_PASSWORD'"
	echo "$CMD"
	eval "$CMD"

	echo "[$(date)] [${FUNCNAME[0]}] Deleting certificate [$KEYSTORE_CERT]..."
	CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c 'rm -f $KEYSTORE_CERT'"
	echo "$CMD"
	eval "$CMD"

	echo "[$(date)] [${FUNCNAME[0]}] Deleting consumer configuration file [$KEYSTORE_CONSUMER_CFGFILE]..."
	CMD="$OC_CMD exec -n $AIMGR_NAMESPACE $KAFKA_POD -- bash -c 'rm -f $KEYSTORE_CONSUMER_CFGFILE'"
	echo "$CMD"
	eval "$CMD"
	
	rm -f $KAFKA_CA_CERT
else
	echo "[$(date)] [${FUNCNAME[0]}] Unable to create Kafka connection..."
fi

# Restart lifecycle
$OC_CMD delete po -n $AIMGR_NAMESPACE aiops-ir-lifecycle-eventprocessor-ep-taskmanager-0
$OC_CMD delete po -n $AIMGR_NAMESPACE aiops-ir-lifecycle-eventprocessor-ep-jobmanager-0

# Scale lifecycle back up
$OC_CMD scale -n $AIMGR_NAMESPACE deployment/ir-lifecycle-operator-controller-manager --replicas=1


