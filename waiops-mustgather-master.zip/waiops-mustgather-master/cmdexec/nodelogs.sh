if [[ $# -eq 1 ]] && [[ $1 =~ ^AUDIT: ]]
then
	USER_INPUT=$(echo "$1" | sed 's/^AUDIT://')

	for INPUT in $(echo "$USER_INPUT" | sed 's/,/ /g')
	do
		LOG_PATH=$(echo "$INPUT" | $AWK -F'@' '{ print $1 }')
		NODE_ROLE=$(echo "$INPUT" | $AWK -F'@' '{ print $2 }')

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [$(basename "$0")] LOG_PATH = [$LOG_PATH] / NODE_ROLE = [$NODE_ROLE]"
		fi

		if [ ${#NODE_ROLE} -gt 0 ]
		then
			CMD="$OC_CMD adm node-logs --role $NODE_ROLE --path=$LOG_PATH"
		else
			echo "[$(date)] [$(basename "$0")] [WARNING] Setting role to default [master]!"
			CMD="$OC_CMD adm node-logs --role master --path=$LOG_PATH"
		fi

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [$(basename "$0")] CMD = [$CMD]"
		fi

		IFS=$'\n'
		for LINE in $(eval "$CMD")
		do
			NODE=$(echo "$LINE" | $AWK '{ print $1 }')
			FILE=$(echo "$LINE" | $AWK '{ print $2 }')

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [$(basename "$0")] NODE = [$NODE] / FILE = [$FILE]"
			fi

			OUTPUT_DIR=$CMD_EXEC_OUTPUT_DIR/$NODE/$LOG_PATH

			if [ ! -d $OUTPUT_DIR ]
			then
				echo "[$(date)] [$(basename "$0")] Making directory [$OUTPUT_DIR]..."
				mkdir -p $OUTPUT_DIR
			fi

			CMD="$OC_CMD adm node-logs $NODE --path=$LOG_PATH/$FILE"
			echo "[$(date)] [$(basename "$0")] Executing command [$CMD]..."
			eval "$CMD" > $OUTPUT_DIR/$FILE 2>&1
		done
	done
else
	$OC_CMD adm node-logs "$@"
fi
