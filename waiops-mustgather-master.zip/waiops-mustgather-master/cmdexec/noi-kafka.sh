NS=$(getProdToNamespacesMapping noi)
NOI_INSTANCE=$($OC_CMD get noi -n $NS --no-headers | $AWK '{ print $1 }')

if [ ${#NS} -eq 0 ] || [ "$NS" == "$PROD_NAMESPACES_INVALID_STR" ]
then
	echo "Unable to determine namespace for NOI! Exiting..." >&2
	exit 1
fi

if [ ${#NOI_INSTANCE} -eq 0 ]
then
	echo "Unable to determine NOI instance! Exiting..." >&2
	exit 1
fi

for GROUP in $($OC_CMD exec $NOI_INSTANCE-kafka-0 -n $NS -- bash -c '/opt/kafka/bin/kafka-consumer-groups.sh -list -bootstrap-server '$NOI_INSTANCE'-kafka-0:9092')
do
	CMD="$OC_CMD exec $NOI_INSTANCE-kafka-1 -n $NS -- bash -c '/opt/kafka/bin/kafka-consumer-groups.sh -group $GROUP -describe -bootstrap-server $NOI_INSTANCE-kafka-1:9092'"
	eval "$CMD"
done
