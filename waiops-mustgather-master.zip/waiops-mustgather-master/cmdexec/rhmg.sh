$OC_CMD adm must-gather --dest-dir="$CMD_EXEC_OUTPUT_DIR"
