Since **v0.9.0**, a new "search for missing objects" feature was introduced. To make use of the feature, you will need to download the "waiops310.csv" file (or any input file of newer CP4WAIOPS version) to the directory where the mustgather tool is saved and executed from. Analysis report is outputted to the README-FIRST.log.

**NOTE**: Please see notes for v0.13.4 where support for AWK regex in OBJNAME is supported.

You can also customize your own input CSV for the "search for missing objects" function by following the procedure:
```
# NAMESPACE = Namespace/Project where the object lives. Leave it blank if the object lives in WAIOPS namespace/project.
#             Eg. ,pod,mypod,1   => The tool will look for a POD named "mypod" in the WAIOPS namespace (blank) and make sure there is at least one instance of the pod
# OBJECT = Openshift/Kubernetes object (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'
# OBJNAME = Name given to the object (Leave out the UUID append to the object by Openshift/Kubernetes)
# !!IMPORTANT!! => While this "getMissingObjects" function does not check for the status (running or not) and number of instances (1/1, 2/2, etc) of the object, the mustgather tool has other functions that handle that!
# NOTE: AWK regex is permitted in OBJNAME
# Eg.
# (1) OBJNAME = zen-.*
# MATCHES = zen-audit-54b4675f56-bsdtb zen-core-5889cf8c75-8dzfp zen-core-5889cf8c75-wxngw zen-core-api-79946c8d5f-xpgm8 zen-core-api-79946c8d5f-zvtld zen-metastoredb-0 zen-metastoredb-1 zen-metastoredb-2 zen-post-requisite-job-5hhvh zen-post-requisite-job-ws2tz zen-pre-requisite-job-lgdqs zen-pre-requisite-job-t4tsl zen-watcher-c8fd9549f-gxqs8
# (2) OBJNAME = scm-connection-0000[0-9]-deployment
# MATCHES = scm-connection-00001-deployment-5db676f556-7dw89
# NAMESPACE,OBJECT,OBJNAME
```

Since **v0.9.5**, a new "manual collection" feature was introduced. To make use of the feature, you will need to download the "manualcollcet.csv" file to the directory where the mustgather tool is saved and executed from. You can also create your own input file and provide its path through the -m option. Its output is available under the "manualcollect" subdirectory of the output file. 

**NOTE**: Please see notes for v0.11.7 where an optional new column EXECCMD was introduced.
**NOTE**: Please see notes for v0.13.4 where support for AWK regex in OBJNAME is supported.

The format of the input file for the "manual collection":
```
# NAMESPACE = Namespace/Project where the object lives. Set the namespace to "all" for all namespaces. IMPORTANT: The namespace is MANDATORY and cannot be left blank!
# OBJTYPE = Openshift/Kubernetes object type (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = Name given to the object (Leave out the UUID append to the object by Openshift/Kubernetes). If left blank, it will be assumed to be ALL objects.
# NOTE: If the detected OBJECT is a pod, command 'oc logs' will be executed too.
# Eg.
# rook-ceph,,    	=> This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: This is equivalent to the new '-e rook-ceph' option!
# rook-ceph,pod,   	=> This setting will translate to 'oc get -n rook-ceph pod'. After that, 'oc describe -n rook-ceph pod <OBJNAME>'
# rook-ceph,,podX  	=> This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: Setting 'podX' will be ignored!
# all,secret,	  	=> This setting will translate to 'oc get --all-namespaces secret'. After that, 'oc describe -n <NAMESPACE> secret <OBJNAME>' 
# NAMESPACE,OBJTYPE,OBJNAME
```

Since **v0.9.8**, a new "collect YAML output" feature was introduced. To make use of the feature, you have to execute the mustgather tool with the new -y option. The tool will gather the output of "oc get -o yaml" of all the resources it touches.

Since **v0.10.4**, a new data collection mode named "limited" (-l option) is introduced to support specific data collection needs where only limited data of the CP4WAIOPS namespace is needed. The option is best used together with the -m option (manual collection) where specific data outside of the CP4WAIOPS namespace is the focus. Such options combo will save a lot of data collection time.

Since **v0.10.7**, a new data collection option (-e) was introduced. The option takes in a list of namespaces (comma-separated) and performs "oc get all", "oc describe" and "oc log" (for pods only) on the resources found. Its output is available under the "extra" subdirectory of the output file. Just imagine the "-e" option as a complement to the "-m" option, because the "-e ibm-common-services" is equivalent to "ibm-common-services,," setting of the "-m" option. Hence, you can limit the use of "-m" to really specific needs like "ibm-common-services,secret," (just to collect data on "secrets" of the "ibm-common-services" namespace).

Since **v0.11.5**, a new data collection mode named "manual" was introduced. It still uses the "-m" option, but the tool now allows full manual data collection. There is no need to provide a CP4WAIOPS namespace through the "-n" option. The "-e" (extra namespace) and "-y" (collect YAML) options are still supported when full manual mode is selected. 

Since **v0.11.6**, a new data collection mode named "extra" was introduced. It still uses the "-e" option, but the tool now supports targeted namespace data collection. There is no need to provide a CP4WAIOPS namespace through the "-n" option. The "-m" (manual collection) and "-y" (collect YAML) options are still supported when the "extra" data collection mode is chosen. The targeted namespace data collection is useful for situations where CP4WAIOPS namespace has yet to be created especially during the pre-requisite steps. 

Since **v0.11.7**, a new feature was introduced to the manual collection mode (-m). It is now possible to execute command on a particular pod.
Use EXECCMD to specify the command.
Use CONTAINER to specify a specific container (within the pod) that the EXECCMD should be executed in.
The output file is available in subdirectory "manualcollect/<namespace>/*.exec".
  
```
# NAMESPACE = Namespace/Project where the object lives. Set the namespace to "all" for all namespaces. IMPORTANT: The namespace is MANDATORY and cannot be left blank!
# OBJTYPE = Openshift/Kubernetes object type (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = Name given to the object (Leave out the UUID append to the object by Openshift/Kubernetes). If left blank, it will be assumed to be ALL objects.
# CONTAINER = [OPTIONAL] This setting is to be used together with EXECCMD to specify a specific container which the EXECCMD should be executed in.
# EXECCMD = [OPTIONAL] Command to be executed on a pod. It is mandatory to provide NAMESPACE, OBJTYPE=pod/po, and OBJNAME=podname. NOTE: You can provide "podname" without the random string/UUID behind.
# Eg. zen-metastoredb will automatically match zen-metastoredb-0, zen-metastoredb-1 and zen-metastoredb-2. The EXECCMD will be executed on all 3 pods.
# NOTE: If the detected OBJECT is a pod, command 'oc logs' will be executed too.
# Eg.
# rook-ceph,,,,                                 => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: This is equivalent to the new '-e rook-ceph' option!
# rook-ceph,pod,,,                              => This setting will translate to 'oc get -n rook-ceph pod'. After that, 'oc describe -n rook-ceph pod <OBJNAME>', followed by 'oc log -n rook-ceph pod <OBJNAME>'.
# rook-ceph,,podX,,                             => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: Setting 'podX' will be ignored!
# all,secret,,,                                 => This setting will translate to 'oc get --all-namespaces secret'. After that, 'oc describe -n <NAMESPACE> secret <OBJNAME>'
# rook-ceph,pod,csi-rbdplugin,,date             => This setting will translate to 'oc exec -n rook-ceph <podname> -- date' WHERE <podname> = all pods that starts with string value 'csi-rbdplugin'
# openshift-dns,pod,dns-default,dns,date        => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that starts with string value 'dns-default'
# NAMESPACE,OBJTYPE,OBJNAME,CONTAINER,EXECCMD
```

Since **v0.12.1**, a new feature was introduced. The new "-g" option will disable collection of pod logs (oc logs).

Since **v0.12.5**, a new DEBUG mode was introduced. The new "-D" option can be used to instruct the tool to output more debugging messages and copy temporary working files into the final output file for debugging purposes. Its output directory is named "debug" in the output file.

Since **v0.12.9**, a new feature (-p) was introduced. The new "-p" option can be used to instruct the tool to collect logs for the previous instance of the container in a pod if it exists (oc logs --previous). The "-p" option does not take effect if "-g" option is also provided.

Since **v0.13.4**, both "getMissingObjects()" (input file is provided) and "getManualCollection()" (-m option) functions support AWK regex in OBJNAME.

Example of input file for "getMissingObjects()" function:
```
# NAMESPACE = Namespace/Project where the object lives. Leave it blank if the object lives in WAIOPS namespace/project.
#             Eg. ,pod,mypod,1   => The tool will look for a POD named "mypod" in the WAIOPS namespace (blank) and make sure there is at least one instance of the pod
# OBJECT = Openshift/Kubernetes object (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'
# OBJNAME = AWK regex is permitted in OBJNAME
# NAMESPACE,OBJECT,OBJNAME
```

Example of input file for "getManualCollection()" function: 
```
# NAMESPACE = Namespace/Project where the object lives. Set the namespace to "all" for all namespaces. IMPORTANT: The namespace is MANDATORY and cannot be left blank!
# OBJTYPE = Openshift/Kubernetes object type (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = AWK regex is permitted in OBJNAME. If left blank, it will be assumed to be ALL objects.
# CONTAINER = [OPTIONAL] This setting is to be used together with EXECCMD to specify a specific container which the EXECCMD should be executed in.
# EXECCMD = [OPTIONAL] Command to be executed on a pod. It is mandatory to provide NAMESPACE, OBJTYPE=pod/po, and OBJNAME=podname. NOTE: You can provide "podname" without the random string/UUID behind.
# Eg. zen-metastoredb will automatically match zen-metastoredb-0, zen-metastoredb-1 and zen-metastoredb-2. The EXECCMD will be executed on all 3 pods.
# NOTE: If the detected OBJECT is a pod, command 'oc logs' will be executed too.
# Eg.
# rook-ceph,,,,                                 => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: This is equivalent to the new '-e rook-ceph' option!
# rook-ceph,pod,,,                              => This setting will translate to 'oc get -n rook-ceph pod'. After that, 'oc describe -n rook-ceph pod <OBJNAME>', followed by 'oc log -n rook-ceph pod <OBJNAME>'.
# rook-ceph,,podX,,                             => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: Setting 'podX' will be ignored!
# rook-ceph,pod,^rook-ceph-mon,,                => This setting will translate to 'oc get pod --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}' -n rook-ceph | awk '/^rook-ceph-mon/ { print }'
# all,secret,,,                                 => This setting will translate to 'oc get --all-namespaces secret'. After that, 'oc describe -n <NAMESPACE> secret <OBJNAME>'
# rook-ceph,pod,csi-rbdplugin,,date             => This setting will translate to 'oc exec -n rook-ceph <podname> -- date' WHERE <podname> = all pods that starts with string value 'csi-rbdplugin'
# openshift-dns,pod,dns-default,dns,date        => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that match AWK regex 'dns-default'
# NAMESPACE,OBJTYPE,OBJNAME,CONTAINER,EXECCMD
```

Since **v0.13.6**, the "-m" (manual) and "-e" (extra namespaces) options can be executed together with "getMissingObjects()" function through the existing "-x" option. You can choose to either set the CP4WAIOPS version manually (for example, 3.1.1) or use "-x X" to force the tool to detect the installed CP4WAIOPS version. Since the "getMissingObjects()" function needs the CP4WAIOPS namespace to work, please provide the namespace through the "-n" option.
```
waiops-mustgather.sh -m /tmp/manualcollect.csv -x X -n waiops31
```

Since **v0.14.3**, a new feature (-t) was introduced. The new "-t" option can be used to disable collection of 'oc describe' output.

Since **v0.14.9**, a new feature (-L) was introduced. The new "-L" option can be used to specify the number of lines of journal log that you want to collect from the individual cluster nodes. This option is only available to data collection modes "-a" (all) and "-d" (nodes-only). 

Since **v0.15.7**, a new feature (-C) was introduced. The new "-C" option allows the user to provide a script file to be executed. The script file and output file will be available under the "cmdexec" sub-directory in the MustGather output file. 
**NOTE**: User will be prompt (10 seconds timeout) to accept the responsibility of running the script. 

Since **v0.15.8**, a new option (-T) was introduced to allow user to set a timeout value for the "cmdexec" mode. The default timeout value is 15m (minutes). The value is in the format of <numeric-value>x where "x" can be s=second or m=minute or h=hour.

Since **v0.17.0**, the "extra" data collection mode will collect data for 'secrets' (oc get and oc describe only - YAML output is disabled), 'configmaps', 'pvc' and 'serviceaccount'.

Since **v0.17.1**, a new option (-S) was introduced. The new "-S" option allows YAML output of 'secret' objects to be collected in the primary data collection mode (-a, -c, -b, -d) and in 'extra' data collection mode explicitly. This option will have to be used together with the "-y" (collect YAML) flag.
In the 'manualcollect' data collection mode, the user will still be prompted to agree to data collection of 'secret' objects if such configuration is detected in the configuration file. 

Since **v0.17.3**, the "clusternodes" (-d) mode (previously known as "nodes-only" mode) is demoted to secondary data collection mode. The "-x" option (now called the "missingobj" mode) is promoted as a new secondary data collection mode. The input file used by the "missingobj" mode is now copied into the "missingobj" subdirectory of the MustGather output file.

Since **v0.19.0**, the output file has a slight re-arrangement. There are 2 new sub-directories that were introduced - 0-README-FIRST and 1-RUNTIME-DATA. 

Sub-directory "0-README-FIRST" will contain the "SUMMARY.log" file (previously known as "README-FIRST.log" and "oc describe", YAML output and 'oc logs' (whichever applicable) of all problematic objects.

Sub-directory "1-RUNTIME-DATA" will contain "runtime.log", "userinput.log", "userenv.log" and "userscriptdir.log" (listing of the directory where the MustGather tool was executed).

Besides that, the SUMMARY.log (previously known as "README-FIRST.log") will now show CPU_COUNT and MEM_SIZE of all the cluster nodes.

Since **v0.19.4**, the "getMissingObjects()" function now support checking of desired object count. The user can specify the desired object count through the OBJCOUNT column.
```
# NAMESPACE = Namespace/Project where the object lives. Leave it blank if the object lives in WAIOPS namespace/project.
#             Eg. ,pod,mypod,1   => The tool will look for a POD named "mypod" in the WAIOPS namespace (blank) and make sure there is at least one instance of the pod
# OBJECT = Openshift/Kubernetes object (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'
# OBJNAME = AWK regex is permitted in OBJNAME
# OBJCOUNT = Conditional expresion (==, >=, <=, >, <) to check against object count (Eg. ==1 or >2 or <=3)
# NAMESPACE,OBJECT,OBJNAME,OBJCOUNT
,deployment,^aimanager-aio-ai-platform-api-server,==1
,deployment,^aimanager-aio-aiops-api,==1
,deployment,^aimanager-aio-alert-localization,==1
,deployment,^aimanager-aio-change-risk,==1
```

Since **v0.21.0**, a new secondary data collection mode named "plugins" (-P) was introduced. If "-P aimanager" is provided, the MustGather tool will gather information about data training (indices and docs) through the "aimanager-aio-ai-platform-api-server" pod.
Details available through "0-README-FIRST/SUMMARY.log" and "7-PLUGINS/aimanager/es-indices" directory.

Since **v0.23.0**, the mustgather tool was upgraded to support automatic WAIOPS (AIMgr and EvtMgr) namespace detection. The "-n" option was deprecated. 
This was done in preparation to support CP4WAIOPS v3.2 that requires AIMgr and EvtMgr to be installed in 2 different namespaces. 
Support for CP4WAIOPS 3.1.0 was removed.

Since **v0.23.5**, the "cmdexec" function gained 3 variables that can be used in the script (WAIOPS_VERSION, AIMGR_NAMESPACES and EVTMGR_NAMESPACES). AIMGR_NAMESPACES and EVTMGR_NAMESPACES are AI Manager and Event Manager namespaces respectively in STRING format delimited by space).

Since **v0.23.7**, data collection for NOIHybrid is supported.

Since **v0.23.10**, a new option (-G) was introduced. You can use the "-G" option to provide filename:regex for the tool to grep in all pod logs that matches. Supported by all primary data collection modes (-a, -c, -b, -l) and some secondary modes (-m and -e).
```
Eg. 
> -G 'ALL:error' => grep for regex "error" in ALL pod logs
> -G "ALL:error,fail' => grep for regex "error" and "fail" in ALL pod logs
> -G "ALL:error|fail' => grep for regex "error" or "fail" in ALL pod logs
> -G "^aimanager-:error" => grep for regex "error" in pod logs with name matching regerx "^aimanager-"
> -G "ALL:error/^aimanager-:fail" => grep for regex "error" in ALL pod logs and grep for regex "fail" in pod logs with name matching regerx "^aimanager-"

Output file is available under 0-README-FIRST/GREP_PATTERN.log
```

Since **v0.24.2**, the "-G" option now supports "piping egrep". With the release, all special delimiter symbols (forward slash, common and tilde) can be escaped with backslash for its literal value. There is no need to backslash escape special delimiter symbol "colon", because it is handled differently in the codes.
```
Eg.
> -G "ALL:error~fail" => grep for regex "error" and then pipe the output to grep for regex "fail" (i.e. egrep -ni 'error' <pod-log> | egrep -i 'fail')
> -G "ALL:error\,fail~exception" => grep for "error,fail" and then pipe the output to grep for regex "exception". (i.e. egrep -ni 'error,fail' <pod-log> | egrep -i 'exception')
> -G "ALL:error\/fail/ALL:exception" => grep for "error/fail" and grep for regex "exception" (2 separate iterations)
```

Since **v0.24.5**, the "-G" option now supports grepping for regex in the "Events" section of the "oc describe" output files.

Since **v0.24.6**, the MustGather tool will check for newer version online. The user will be prompted to download.

Since **v0.24.8**, a new "-U" option was introduced to make update checking optional.

Since **v0.25.2**, the "-G" option now supports grepping for regex in files under the 2-CLUSTERNODES directory (collected through "-a" option or "-d" option). Those are data (journal, systemctl, iptables, dmesg, ps -ef, etc) collected from individual cluster nodes.

Since **v0.25.3**, the "-G" option now supports grepping for regex in the "Events" section of the "oc describe" output files for IBM-related CRDs under the CUSTOM_DATA/ibm_crd directory.

Since **v0.25.10**, a new "-X" option was introduced to turn off custom data collection (limited to -a and -c data collection mode). 
Currently, only the "getODLMLogs", "getOLMLogs", and "getIbmCrd" functions are considered custom.

Since **v0.26.4**, the MustGather tool will now gather output of command "nginx -T" from ibm-nginx pods in the AI Manager namespace.

Since **v0.27.5**, the plugin option (-P) supports 2 actions (data and fix). "Data" action is used to collect data and "fix" action is used to perform corrective actions.
It is possible to run the "fix" plugin and then follow by the "data" plugin (Eg. -P aimanager:fix,aimanager:data).

Since **v0.27.8**, the "getMissingObjects()" function now support a new column (EXCLSCRIPT) in its configuration files under the "missingobj" subdirectory of the MustGather package. You can point the "EXCLSCRIPT" column to a script that returns either 0 (to include the configuration line) or 1 (to exclude the configuration line). The script must be saved under the "missingobj" subdirectory.
```
# NAMESPACE = Namespace/Project where the object lives. Leave it blank if the object lives in WAIOPS namespace/project. Set it to '?' if you wish to search all namespaces (-A).
#             Eg. ,pod,mypod,>=1   => The tool will look for a POD named "mypod" in the WAIOPS namespace (blank) and make sure there is more than or at least one instance of the pod
#             Eg. ?,deployment,mydeploy,==1   => The tool will look for a DEPLOYMENT named "mydeploy" in all namespaces (?) and make sure there is exactly one instance of the deployment
# OBJECT = Openshift/Kubernetes object (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'
# OBJNAME = AWK regex is permitted in OBJNAME
# OBJCOUNT = Conditional expresion (==, >=, <=, >, <) to check against object count (Eg. ==1 or >2 or <=3)
# NSSCRIPT = [OPTIONAL] Script to determine object namespace (when NAMESPACE column is left empty)
# EXCLSCRIPT = [OPTIONAL] Script to determine whether the config line should be excluded (return 0 to keep or return 1 to exclude)
# NAMESPACE,OBJECT,OBJNAME,OBJCOUNT,NSSCRIPT,EXCLSCRIPT
```
Since **v0.28.0**, a new "-F" option (named "cpfiles" secondary data collection mode) was introduced to allow user to copy files from pod/container into the MustGather output file under the 8-CPFILES directory.
The "cpfiles" mode can be executed in 2 modes:
~ configuration file 
~ manual/dynamic mode
In "configuration file" mode, the tool will refer to the file cpfiles/cpfiles-waiops<version>.csv file. The execution is through -F <PRODUCT> where <PRODUCT> is a column in the configuration file. All lines that match the PRODUCT value will be processed.
```
# PRODUCT = Any name (used to group all files needed in a single run together)
# NAMESPACE = Namespace where the pod resides (use values AIMGR, EVTMGR and EVTMGR-HYBRID to force the tool to auto-determine the namespace of those products/components)
# PODNAME = AWK regex is allowed when specifying PODNAME
# CONTAINER = [OPTIONAL] If left out, the tool will go for the default container
# FILES = File(s) that need to be copied (separate files with colon ":")
# PRODUCT,NAMESPACE,PODNAME,CONTAINER,FILES
# noi,EVTMGR,evtmanager-webgui-,webgui,/home/netcool/impact.crt:/home/netcool/ldap.py
```
In "manual/dynamic" mode, the tool will pickup the configuration/setting from the command line. 
```
Eg.
waiops-mustgather.sh -F noi,evtmanager-webgui,webgui,/home/netcool/impact.crt:/home/netcool/ldap.py
```

Since **v0.28.1**, the PRODUCT column of the "cpfiles" configuration file was renamed to TAG.

Since **v0.28.2**, the "getManualCollection()" function gained a new TAG column that allows it to only execute certian config lines during a single execution based on a TAG.
```
Eg. waiops-mustgather.sh -m test:/tmp/manualcollect.csv -D   => This command will only execute the config lines that are tagged with "test" and "ALL" in the following file (line 1 and 5)

# TAG = Any name (used to select all configuration lines to be run together in a single execution - use the special "ALL" tag for to-execute-always config line) [MANDATORY]
# NAMESPACE = Namespace/Project where the object lives. Set the namespace to "all" for all namespaces. IMPORTANT: The namespace is MANDATORY and cannot be left blank!
# OBJTYPE = Openshift/Kubernetes object type (Eg. pod, deployment, secret, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = AWK regex is permitted in OBJNAME. If left blank, it will be assumed to be ALL objects.
# CONTAINER = [OPTIONAL] This setting is to be used together with EXECCMD to specify a specific container which the EXECCMD should be executed in.
# EXECCMD = [OPTIONAL] Command to be executed on a pod. It is mandatory to provide NAMESPACE, OBJTYPE=pod/po, and OBJNAME=podname. NOTE: You can provide "podname" without the random string/UUID behind.
# TAG,NAMESPACE,OBJTYPE,OBJNAME,CONTAINER,EXECCMD
test,waiops32,pod,^cp4waiops-postgres-keeper,,hostname;ps -ef
testx,openshift-dns,sEcrEt,,,
testx,openshift-image-registry,SECRETS,^default-token,,
testx,openshift-dns,po,,,
ALL,waiops32,po,^ibm-vault,,
```

Since **v0.29.0**, the "getManualCollection()" function now supports executing a script to determine namespace of the config line.
```
# TAG = [MANDATORY] Any name (used to select all configuration lines to be run together in a single execution - use the special "ALL" tag for to-execute-always config line)
# NAMESPACE = [MANDOTRY] Namespace/Project where the object lives. Set the namespace to "all" for all namespaces or set it to a script that will return a valid namespace (must prefix with string 'bash' - Eg. bash /tmp/namespace.sh)
# OBJTYPE = [OPTIONAL] Openshift/Kubernetes object type (Eg. pod, deployment, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = [OPTIONAL] AWK regex is permitted in OBJNAME. If left blank, it will be assumed to be ALL objects.
# CONTAINER = [OPTIONAL] This setting is to be used together with EXECCMD to specify a specific container which the EXECCMD should be executed in.
# EXECCMD = [OPTIONAL] Command to be executed on a pod. It is mandatory to provide NAMESPACE, OBJTYPE=pod/po, and OBJNAME=podname. NOTE: You can provide "podname" without the random string/UUID behind.
# Eg. zen-metastoredb will automatically match zen-metastoredb-0, zen-metastoredb-1 and zen-metastoredb-2. The EXECCMD will be executed on all 3 pods.
# NOTE: If the detected OBJECT is a pod, command 'oc logs' will be executed too.
# Eg.
# ALL,rook-ceph,,,,                                             => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: This is equivalent to the new '-e rook-ceph' option!
# ALL,rook-ceph,pod,,,                                          => This setting will translate to 'oc get -n rook-ceph pod'. After that, 'oc describe -n rook-ceph pod <OBJNAME>', followed by 'oc log -n rook-ceph pod <OBJNAME>'.
# ALL,rook-ceph,,podX,,                                                 => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: Setting 'podX' will be ignored!
# ceph,rook-ceph,pod,^rook-ceph-mon,,                   => This setting will translate to 'oc get pod --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}' -n rook-ceph | awk '/^rook-ceph-mon/ { print }'
# ALL,all,secret,,,                                                     => This setting will translate to 'oc get --all-namespaces secret'. After that, 'oc describe -n <NAMESPACE> secret <OBJNAME>'
# ceph,rook-ceph,pod,csi-rbdplugin,,date                => This setting will translate to 'oc exec -n rook-ceph <podname> -- date' WHERE <podname> = all pods that starts with string value 'csi-rbdplugin'
# dns,openshift-dns,pod,dns-default,dns,date            => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that match AWK regex 'dns-default'
# dns,openshift-dns,pod,dns-default,dns,date            => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that match AWK regex 'dns-default'
# waiops,bash /tmp/namespace.sh,pod,^aimanager,,        => This setting will execute script '/tmp/namespace.sh' to obtain the namespace for this config line.
# TAG,NAMESPACE,OBJTYPE,OBJNAME,CONTAINER,EXECCMD
```

Since **v0.29.1**, the "getManualCollection()" function can now use special keywords (AIMGR, EVTMGR and EVTMGR-HYBRID) to auto-retrieve corresponding namespaces.
```
# TAG = [MANDATORY] Any name (used to select all configuration lines to be run together in a single execution - use the special "ALL" tag for to-execute-always config line)
# NAMESPACE = [MANDOTRY] Namespace/Project where the object lives. Set the namespace to "all" for all namespaces or set it to a script that will return a valid namespace (must prefix with string 'bash' - Eg. bash /tmp/namespace.sh)
#             or set it to AIMGR (to auto retrieve all AI Manager namespaces), EVTMGR or EVTMGR-HYBRID.
# OBJTYPE = [OPTIONAL] Openshift/Kubernetes object type (Eg. pod, deployment, etc) ** Refer to 'oc api-resources'. If left blank, the mustgather tool will execute 'oc describe' on all objects found through 'oc get all -n $NAMESPACE'.
# OBJNAME = [OPTIONAL] AWK regex is permitted in OBJNAME. If left blank, it will be assumed to be ALL objects.
# CONTAINER = [OPTIONAL] This setting is to be used together with EXECCMD to specify a specific container which the EXECCMD should be executed in.
# EXECCMD = [OPTIONAL] Command to be executed on a pod. It is mandatory to provide NAMESPACE, OBJTYPE=pod/po, and OBJNAME=podname. NOTE: You can provide "podname" without the random string/UUID behind.
# Eg. zen-metastoredb will automatically match zen-metastoredb-0, zen-metastoredb-1 and zen-metastoredb-2. The EXECCMD will be executed on all 3 pods.
# NOTE: If the detected OBJECT is a pod, command 'oc logs' will be executed too.
# Eg.
# ALL,rook-ceph,,,,                                             => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: This is equivalent to the new '-e rook-ceph' option!
# ALL,rook-ceph,pod,,,                                          => This setting will translate to 'oc get -n rook-ceph pod'. After that, 'oc describe -n rook-ceph pod <OBJNAME>', followed by 'oc log -n rook-ceph pod <OBJNAME>'.
# ALL,rook-ceph,,podX,,                                                 => This setting will translate to 'oc get -n rook-ceph all'. After that, 'oc describe -n rook-ceph <OBJTYPE> <OBJNAME>' NOTE: Setting 'podX' will be ignored!
# ceph,rook-ceph,pod,^rook-ceph-mon,,                   => This setting will translate to 'oc get pod --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}' -n rook-ceph | awk '/^rook-ceph-mon/ { print }'
# ALL,all,secret,,,                                                     => This setting will translate to 'oc get --all-namespaces secret'. After that, 'oc describe -n <NAMESPACE> secret <OBJNAME>'
# ceph,rook-ceph,pod,csi-rbdplugin,,date                => This setting will translate to 'oc exec -n rook-ceph <podname> -- date' WHERE <podname> = all pods that starts with string value 'csi-rbdplugin'
# dns,openshift-dns,pod,dns-default,dns,date            => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that match AWK regex 'dns-default'
# dns,openshift-dns,pod,dns-default,dns,date            => This setting will translate to 'oc exec -n openshift-dns <podname> -c dns -- date' WHERE <podname> = all pods that match AWK regex 'dns-default'
# waiops,bash /tmp/namespace.sh,pod,^aimanager,,        => This setting will execute script '/tmp/namespace.sh' to obtain the namespace for this config line.
# TAG,NAMESPACE,OBJTYPE,OBJNAME,CONTAINER,EXECCMD
```

Since **v0.29.4**, a new "-R" option was introduced. You can use the "-R" option to print the SUMMARY.log on screen after the data collection is completed.

Since **v0.30.0**, a new "-z" option was introduced as another PRIMARY data collection mode. It is named as "modules" data collection mode. For now, the available modules are clusterinfo,productinfo,storage,networking,custom. You can specify multiple modules by using comma as delimiter.
```
Eg.
waiops-mustgather.sh -z productinfo,storage -ypD
```

Since **v0.31.0**, 3 new options were introduced (-R, -V and -E).
The new "-R" option provides the function to display SUMMARY.log at the end of data collection.
The new "-V" option (VIEW-ONLY mode) will disable OC_DESC_ON, COLLECT_YAML (-y), GET_POD_LOGS and COLL_PREV_LOGS (-p). It will enable REPORT_ON_SCREEN (-R).
The new "-E" option provides the function to pass environment variables to the "cmdexec" function (-C).
If REPORT_ON_SCREEN is enabled, the "cmdexec" fucntion will now write to SUMMARY.log, so that the script output will be displayed on screen.
Besides that, the "execcmd" of the "manualcollect" function will also write to SUMMARY.log, so that the output of command(s) executed on a pod is displayed.
Pod network connectivity test and "missingobj" function are disabled from the "limited" data collection mode.

Since **v0.31.1**, a new option "-Z" was introduced. The new "-Z" option provides the function to pass environment variables to the "plugins" function (-P).

Since **v0.31.3**, the optional EXCLSCRIPT defined in missingobj/waiops<version>.csv file will be passed the auto-detected product namespace as the LAST parameter (Eg. EXCLSCRIPT = "/tmp/script.sh a b c" will become "/tmp/script.sh a b c prod-namespace".
  
Since **v0.31.6**, a new option "-n" was introduced. The new "-n" option provides the function to pass environment variables to the "manualcollect" collection mode (-m).

Since **v0.32.3**, a new option "-f" was introduced. The new "-f" option can be used to collect PVC usage/utilization (through 'df -h' executed on the pod).

Since **v0.32.9**, besides the original 4 variables (WAIOPS_VERSION, AIMGR_NAMESPACES, EVTMGR_NAMESPACES and EVTMGR_HYBRID_NAMESPACES), the "cmdexec" function gained another new variable (CMD_EXEC_OUTPUT_DIR) that can be used by the script to copy files to the CMDEXEC output directory.

Since **v0.34.0**, the WAIOPS MustGather has moved to support the 'generic-mustgather framework' (GMGF). You can find out more about the 'generic-mustgather framework' [here](https://github.ibm.com/danielyeap/qotd-mustgather).

Since **v0.39.7**, support for multiple tags was introduced in the MANUALCOLLECT mode.

Since **v0.39.8**, a helper function (getResourceInstances()) was introduced. User can use the function in script executed by CMDEXEC to obtain a list of resource instances by passing in OBJTYPE, OBJNAME_REGEX and OBJNS (namespace).

Since **v0.40.3**, the WAIOPS MustGather gained a new "-x" feature from GMGF. The user can now provide a custom config file through the "-x" option (instead of using the shipped config file that will be chosen based on detected product version).

Since **v0.41.0**, a new option "-K" was introduced. It can be used to perform snapshots (configurable) comparison to determine what has changed since the previous snapshot.

Since **v0.42.0**, a new primary data collection mode called "selective" (-k) was introduced. It can be used to collect data for selective resources specified by user during runtime.

Since **v0.43.0**, support for WAIOPS 3.3.1 and embedded Bedrock MustGather and now WAIOPS MustGather can run the "automationfoundation" and "cloudpaks" modules.

Since **v0.43.6**, a new option "-I" was introdued. It can be used to perform further analysis on "incidents" that was reported by various functions (core or product) through the new "setIncident" function. 

Since **v0.46.0**, a new option "-J" was introdued. It can be used to collect JSON data (oc get -o json).

Since **v0.47.0**, the "view-only" mode (-V) gained a "-V .listviews" function to display all available view-only modules (scripts) and their description.

Since **v0.51.2**, a new option "-H" was introduced. The new "-H" option provides the function to collect pod dependency data.

Since **v0.51.3**, getMissingObjects() function will provide missing resource data to getPodDependencyData() function.

Since **v0.51.5**, user can create a "addres.cfg" file in directory $MUSTGATHER_DIRNAME/config to introduce data collection for additional resource (one resource type per line). The file will be read and processed with the "-W ADDRES=addres.cfg" option. 
A new CMDEXEC script "rhmg.sh" was introduced to allow execution of Red Hat MustGather (oc adm must-gather) within WAIOPS MustGather.

Since **v0.51.7**, the WAIOPS MustGather will process $MUSTGATHER_DIRNAME/config/addres.cfg for additional resource data collection as long as it exists. There is no longer a need to execute "-W ADDRES=addres.cfg". Users can still make use of "-W ADDRESS=xxx,yyy" for additional resource data collection.

Since **v0.51.8**, the analytics engine (-I) will only execute "generic.sh" when object-specific script directory is not found.

Since **v0.52.1**, function checkEnvVarFormat() is renamed to checkEnvVar() to include checking of user-input variables against global variables GMGF_ENV_ARR. 

Since **v0.52.2**, more improvements to function checkEnvVar() on checking user-input variables.

Since **v0.52.3**, "selective" mode (-k) was upgraded to support reading from a file (absolute/full path) - Eg. '-k /tmp/selective.cfg'

Since **v0.52.6**, a new option "-B" was introduced. It can be used to disable data collection for specified product namespaces. The "analyzeOcPvc()" function will also now provide warning over 95% pvc utlization. Lastly, a new "system.cfg" file was introduced to allow user to configure system-related properties (Eg. CPU_WARNING, MEM_WARNING and PVC_WARNING).

Since **v0.53.0**, the "-B" option was retired in preference of [Eg. -W 'EXCL_PROD_NS="NS4PROD=aimanager NS4PROD=noi"'].

Since **v0.54.0**, the format of MISSINGOBJ, MANUALCOLLECT and CPFILES configuration files were changed to address a bug. The mentioned modes will fail when comma is used in the regular expression in OBJNAME column (Eg. abc{2,4}). Comma was the delimiter of the columns, causing AWK to extract the columns wrongly. To address that issue, a few changes were made:
(a) New delimiter = ## (from ,)
(b) New comment symbol = @ (from #)
(c) New filename suffix = .cfg (from .csv)

Since **v1.0.0**, support for WAIOPS 3.5.0 was introduced. TIMEOUT and DELIMITER related variables are moved to system.cfg for ease of maintenance.  

Since **v1.1.4**, WAIOPS MustGather can be updated without needing to perform manual unpacking.

Since **v1.1.7**, WAIOPS MustGather will check for update automatically if the AUTO_CHECK_UPDATE flag is set to "true" in config/product.cfg.

Since **v1.2.9**, MANUALCOLLECT mode supports a new column EXECPREP that can be used to copy file/directory to the target pod for further processing. Besides, MANUALCOLLECT is now product version aware.

Since **v1.4.0**, the "-a" option was upgraded to collect data for ALL resource types associated with product namespaces (no longer pre-defined list). If the old behavior (pre-defined list) is prefered, it is achievable with '-W "GETALL_SUBSET_DATA=true"'. 

Since **v1.4.1**, the "-e" option was upgraded to support data collection of ALL resource types with the keyword ALL (Eg. -e 'openshift-dns:ALL')

Since **v1.5.0**, a new "-M" option was introduced to allow user to disable auto upgrade. A few new view-only modules were added too.

Since **v1.5.11**, the "-Z" option will support environment variables for multiple plugins. Data dump for all datasources (Kafka, ElasticSearch and Postgres) are turned off and to be turn back on with '-Z DATA_DUMP=1'. When data dump is enabled, the user will be prompted to accept/decline.

Since **v1.6.1**, a new flag SHOW_MANAGED_FIELDS was introduced in config/product.cfg. The flag can be set to "true" to include '--show-managed-fields' in the YAML or JSON output.

Since **v1.6.2**, the COMPLIANCE mode was upgraded to support a new field (ACTIONSCRIPT). The ACTIONSCRIPT is executed when a compliance rule failed.

Since **v1.7.0**, a new "-O" option (ALIAS mode) was introduced to allow user to define shortcut for long command.

Since **v1.7.3**, logs of "init-containers" will be collected.

Since **v1.7.5**, there was a performance improvement by replacing "oc get -o yaml", "oc get -o json" and "oc logs" with API calls.

Since **v1.8.0**, another new performance improvement for "oc describe" was delivered. Functions descAll, descSecrets, ocDesc and getCrdData were updated to perform bulk "oc describe" (instead of one "oc" command per instance). The bulk result would be processed by SED and AWK to produce individual output files.
 
Since **v1.8.1**, MANUALCOLLECT was upgraded to support the new performance improvement mechanism used by descAll, descSecrets, ocDesc and getCrdData functions. The MANUALCOLLECT will also support data collection from ALL namespaces for ALL resource types with a filter (setting OBJNAME column). 

Since **v1.8.2**, getOcProdNamespaces() function supports user provided parameter for product namespaces (Eg. -W 'AIMGR_NS=cp4waiops##EVTMGR_NS=cp4waiops-emgr'). Added support to dump certificate for routes if openssl is available and with -S. 

Since **V1.8.5**, the EXTRA mode (-e) was upgraded to support special keyword "NS4PROD". 

Since **v1.8.7**, the EXTRA mode (-e) was upgraded to include health analytics (to check for problematic resources through analyzeOcAll() function).

Since **v1.8.10**, added data collection for Cassandra into PLUGINS.

Since **v1.8.12**, amended the diffSnapshots() function to refer to defined DELIMITER and COMMENT symbols from system.cfg.

Since **v1.9.0**, simplified getOcProdNamespaces() to limit function to returning product namespaces. The function of getting status of various product CRDs was separated to getOcProdStatus(). There will no longer be 2 calls to getOcProdNamespaces() and getProdVersion(). In ALIAS mode, important files are copied to the new output directory created in the second setupDataDir() call. 3 new optional functiosn (initSetup, preDataCollect and postDataCollect) can now be defined to perform custom tasks during specific moments in the lifecycle.

Since **v1.9.4**, a periodic check was added into checkUserPriv() to see whether there is a change in cluster/config (oc login) in the midst of data collection. If there is, exit (data collected no longer relevant). With POD_LOG_TAILLINES variable in config/product.cfg, it is now possible to collect the last n lines of pod logs (instead of all lines). The prefix for -W was changed from PRIMODE_ to RTVAR_ (runtime variables). A new column REGEXSCRIPT was added to MISSINGOBJ configuration file. It can be used to construct OBJNAME dynamically.

Since **v1.9.9**, added analyzeOcCert() function to check the READY column of 'oc get cert' output.

Since **v1.9.11**, bug fixes for checkForUpdate() function.

Since **v1.10.0**, added fallback to 'oc' for unsuccessful pod logs API call. Function getProdVersion() was renamed getProdVersions() and getOcProdNamespaces() was renamed getProdNamespaces().
All secondary modes were updated to support "product groups" (multiple product versions on the same cluster).
The download package is now wrapped in a directory "waiops-mustgather" (instead of individual files/directories - depending on user to create the containing directory).

Since **v1.10.6**, added POSTEXEC feature/column to MANUALCOLLECT mode that allows post processing of the EXECCMD locally on the client machine. 

Since **v1.10.8**, added 'getResByLabel.sh' script to CMDEXEC to allow data collection based on labels/selectors.

Since **v1.10.9**, cache for non-BASH_V4 clients are upgraded in performance by using AWK matching instead of readline.

Since **v1.10.12**, the report for MISSINGOBJ in SUMMARY.log will contain input file processing details.

Since **v1.10.13**, the -W option can be used to update variables in system.cfg.

Since **v1.10.14**, the CMDEXEC mode can now trigger MISSINGOBJ, COMPLIANCE, PLUGINS, AND SNAPSHOTS modes in the custom script.

Since **v1.10.15**, user can now pass in parameters to CMDEXEC enabled PLUGINS through the CMD_EXEC_RESULT_PLUGINS_PARAM_FILE with format of 'PLUGIN_NAME${CMD_EXEC_PLUGINS_PARAM_COLUMN_DELIMITER}PLUGIN_ACTION${CMD_EXEC_PLUGINS_PARAM_COLUMN_DELIMITER}PLUGIN_PARAM_1=PLUGIN_VALUE_1${CMD_EXEC_PLUGINS_PARAM_FIELD_DELIMITER}...'

Since **v1.11.2**, the COMPLIANCE mode gained a new feature SOURCEREGEX and TARGETREGEX which can be used to populate SOURCEOBJNAME and TARGETOBJNAME during runtime.

Since **v1.11.3**, the CPFILES mode gained a new feature REGEXSCRIPT which can be used to populate PODNAME during runtime.

Since **v1.11.6**, a new view "analyzeres" was added to display problematic deployments, statefulsets, daemonsets, pods and jobs for all product namespaces, user-specified namespaces or all namespaces (ALLNS keyword).

Since **v1.11.7**, user must system MISSINGOBJ_FOR_GETXXX (eg. MISSINGOBJ_FOR_GETALL or MISSINGOBJ_FOR_GETCOMPREHENSIVE) in config/product.cfg to enable MISSINGOBJ in various primary modes. Default behavior (set in system.ccfg) is to disable MISSINGOBJ mode. Besides, "selective" (-k) primary mode was updated to only collect data resource types specified by user. Additional data will need to be turned on through RTVAR_ENABLE_GENERAL_DATA or RTVAR_ENABLE_PROD_ANALYTICS or RTVAR_ENABLE_EXTRA_DATA (both). CUSTOM_DATA_ENABLED is set to false unless RTVAR_SELECTIVE_CUSTOM_DATA is set to true.

Since **v1.11.8**, the CPFILES mode was upgraded to support a new LIMITS column that can be used to filter the target files/directories based on 'head -X' or 'tail -X' setting. Target files/directories will be first sorted in newest file first order (ls -t).

Since **v1.12.5**, user can pass in variables with GMGFVAR_ prefix to make it available to scripts of all secondary modes.

Since **v1.13.0**, GMGF supports execution in non-cloud mode (no oc or kubectl), but only initSetup() will be executed. Added CNI data collection (/etc/cni and /etc/kubernetes/cni) to CLUSTERNODES mode.

Since **v1.13.3**, the EXTRA mode supports data collection for all namespaces through the special keyword ALLNS.

