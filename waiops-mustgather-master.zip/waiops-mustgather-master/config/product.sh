#!/bin/bash

# Product instance parameters
WAIOPS_PROD_NAMESPACES=()
WAIOPS_AIMGR_KIND="aimanager"
WAIOPS_AIMGR_INSTALLED="false"
WAIOPS_AIMGR_NAMESPACE_ARR=()
WAIOPS_AIMGR_NS_USERINPUT="false"
WAIOPS_EVTMGR_KIND="noi"
WAIOPS_EVTMGR_INSTALLED="false"
WAIOPS_EVTMGR_NAMESPACE_ARR=()
WAIOPS_EVTMGR_NS_USERINPUT="false"
WAIOPS_EVTMGR_HYBRID_KIND="noihybrid"
WAIOPS_EVTMGR_HYBRID_INSTALLED="false"
WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR=()
WAIOPS_EVTMGR_HYBRID_NS_USERINPUT="false"
WAIOPS_ICS_KIND="ics"
WAIOPS_ICS_INSTALLED="false"
WAIOPS_ICS_NAMESPACE_ARR=()

WAIOPS_MANUAL_DETECT="false"
WAIOPS_MG_LATEST_VER_CODE="88"


# [MANDATORY] Functions
getProdVersions()
{
	local OUTFILE=$1

	if [ $MG_DEBUG == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Size of WAIOPS_AIMGR_NAMESPACE_ARR array = [${#WAIOPS_AIMGR_NAMESPACE_ARR[@]}]" >&2
	fi

	# If more than one product groups/versions are detected
	if [ ${#WAIOPS_AIMGR_NAMESPACE_ARR[@]} -gt 1 ]
	then
		local NEWEST_VER_IDX=
		local WAIOPS_PRODGROUP_CTR=0

		for AIMGR_NS in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}	
		do
			local CUR_PROD_CSV=$($OC_CMD get csv -n ${AIMGR_NS} 2> /dev/null | grep '^ibm-aiops-orchestrator' | $AWK '{ print $1 }')
			local CUR_PRODUCT_VERSION=$($OC_CMD get csv $CUR_PROD_CSV -n ${AIMGR_NS} -o=jsonpath="{.spec.version}" 2> /dev/null | $AWK -F'-' '{ print $1 }')
			local CUR_AIMGR_INSTALL_NAME=$($OC_CMD get install.orchestrator.aiops.ibm.com -n ${AIMGR_NS} --no-headers | $AWK '{ print $1 }')

			if [ ${#CUR_AIMGR_INSTALL_NAME} -eq 0 ]
			then
				local CUR_AIMGR_INSTALL_NAME="waiops"
			fi

			local PROD_GROUP_NAME="${AIMGR_NS}@${CUR_AIMGR_INSTALL_NAME}"

			local CUR_VER_IDX=0
			local VALID_VER_FOUND="false"

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] [NS=$AIMGR_NS] CUR_PROD_CSV = [$CUR_PROD_CSV] / CUR_PRODUCT_VERSION = [$CUR_PRODUCT_VERSION]" >&2				
			fi
			
			if [ ${#CUR_PRODUCT_VERSION} -eq 0 ]
			then
				continue
			fi
	
			for VALID_PROD_VER in ${PRODUCT_SUPPORTED_VERSION[@]}
			do
				if [ $VALID_PROD_VER == $CUR_PRODUCT_VERSION ]
				then
					local VALID_VER_FOUND="true"

					if [ ${#NEWEST_VER_IDX} -eq 0 ]
					then
						local NEWEST_VER_IDX=$CUR_VER_IDX

						if [ $MG_DEBUG == "true" ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] [1] Current latest version = [${PRODUCT_SUPPORTED_VERSION[$NEWEST_VER_IDX]}][$NEWEST_VER_IDX]" >&2
						fi
					else
						if [ $CUR_VER_IDX -gt $NEWEST_VER_IDX ]
						then
							local NEWEST_VER_IDX=$CUR_VER_IDX

							if [ $MG_DEBUG == "true" ]
							then
								echo "[$(date)] [${FUNCNAME[0]}] [2] Current latest version = [${PRODUCT_SUPPORTED_VERSION[$NEWEST_VER_IDX]}][$NEWEST_VER_IDX]" >&2
							fi
						fi
					fi

					break
				fi

				(( CUR_VER_IDX=CUR_VER_IDX+1 ))
			done

			if [ $VALID_VER_FOUND == "false" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] CUR_PRODUCT_VERSION [$CUR_PRODUCT_VERSION] is not a valid product version!" >&2
			fi

			# Creating the product group reference file
			local NS_REF_LINE="$WAIOPS_AIMGR_KIND=$AIMGR_NS"
			
			# TODO: Lazy way to associate EvtMgr/Hybrid/ICS namespaces to AIMgr
			if [ $WAIOPS_EVTMGR_INSTALLED == "true" ]
			then
				if [ ${#NS_REF_LINE} -eq 0 ]
				then
					local NS_REF_LINE="${WAIOPS_EVTMGR_KIND}=$(echo "${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				else
					local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_EVTMGR_KIND}=$(echo "${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				fi
			fi
			
			if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
			then
				if [ ${#NS_REF_LINE} -eq 0 ]
				then
					local NS_REF_LINE="${WAIOPS_EVTMGR_HYBRID_KIND}=$(echo "${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				else
					local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_EVTMGR_HYBRID_KIND}=$(echo "${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				fi
			fi
			
			if [ $WAIOPS_ICS_INSTALLED == "true" ]
			then
				if [ ${#NS_REF_LINE} -eq 0 ]
				then
					local NS_REF_LINE="${WAIOPS_ICS_KIND}=$(echo "${WAIOPS_ICS_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				else
					local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_ICS_KIND}=$(echo "${WAIOPS_ICS_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
				fi
			fi
			
			echo "${PROD_GROUP_NAME}${PROD_REFFILE_DELIMITER}${CUR_PRODUCT_VERSION}${PROD_REFFILE_DELIMITER}${NS_REF_LINE}" >> $OUTFILE
			
			(( WAIOPS_PRODGROUP_CTR=WAIOPS_PRODGROUP_CTR+1 ))
		done

		if [ ${#NEWEST_VER_IDX} -eq 0 ]
		then
			local DEFAULT_PRODUCT_VERSION=""
		else
			local DEFAULT_PRODUCT_VERSION=${PRODUCT_SUPPORTED_VERSION[$NEWEST_VER_IDX]}
		fi
	else
		if [ ${#WAIOPS_AIMGR_NAMESPACE_ARR[@]} -eq 1 ]
		then
			local PROD_CSV=$($OC_CMD get csv -n ${WAIOPS_AIMGR_NAMESPACE_ARR[0]} 2> /dev/null | grep '^ibm-aiops-orchestrator' | $AWK '{ print $1 }')
			local DEFAULT_PRODUCT_VERSION=$($OC_CMD get csv $PROD_CSV -n ${WAIOPS_AIMGR_NAMESPACE_ARR[0]} -o=jsonpath="{.spec.version}" 2> /dev/null | $AWK -F'-' '{ print $1 }')
			local AIMGR_INSTALL_NAME=$($OC_CMD get install.orchestrator.aiops.ibm.com -n ${WAIOPS_AIMGR_NAMESPACE_ARR[0]} --no-headers | $AWK '{ print $1 }')

			if [ ${#AIMGR_INSTALL_NAME} -eq 0 ]
			then
				local AIMGR_INSTALL_NAME="waiops"
			fi
			
			local PROD_GROUP_NAME="${WAIOPS_AIMGR_NAMESPACE_ARR[0]}@${AIMGR_INSTALL_NAME}"
			local NS_REF_LINE="$WAIOPS_AIMGR_KIND=${WAIOPS_AIMGR_NAMESPACE_ARR[0]}"
		else
			local PROD_GROUP_NAME="waiops@waiops"
		fi

		if [ $WAIOPS_EVTMGR_INSTALLED == "true" ]
		then
			if [ ${#NS_REF_LINE} -eq 0 ]
			then
				local NS_REF_LINE="${WAIOPS_EVTMGR_KIND}=$(echo "${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			else
				local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_EVTMGR_KIND}=$(echo "${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			fi
		fi
			
		if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
		then
			if [ ${#NS_REF_LINE} -eq 0 ]
			then
				local NS_REF_LINE="${WAIOPS_EVTMGR_HYBRID_KIND}=$(echo "${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			else
				local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_EVTMGR_HYBRID_KIND}=$(echo "${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			fi
		fi
			
		if [ $WAIOPS_ICS_INSTALLED == "true" ]
		then
			if [ ${#NS_REF_LINE} -eq 0 ]
			then
				local NS_REF_LINE="${WAIOPS_ICS_KIND}=$(echo "${WAIOPS_ICS_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			else
				local NS_REF_LINE="${NS_REF_LINE}${PROD_REFFILE_NS_DELIMITER}${WAIOPS_ICS_KIND}=$(echo "${WAIOPS_ICS_NAMESPACE_ARR[@]}" | sed 's/[ ]/,/g')"
			fi
		fi

		echo "${PROD_GROUP_NAME}${PROD_REFFILE_DELIMITER}${DEFAULT_PRODUCT_VERSION}${PROD_REFFILE_DELIMITER}${NS_REF_LINE}" >> $OUTFILE
	fi

	if [ ${#RTVAR_PRODVER} -gt 0 ] 
	then
		echo "$RTVAR_PRODVER"
	else
		echo "$DEFAULT_PRODUCT_VERSION"
	fi
}

getProdNamespaces()
{
	local OUTFILE=$1

	WAIOPS_PROD_NAMESPACES=()
	WAIOPS_AIMGR_NAMESPACE_ARR=()
	WAIOPS_EVTMGR_NAMESPACE_ARR=()
	WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR=()

	local TMP_PROD_NS_FILE=$OUTDIR/prod_ns.tmp
	local PRODSTATUS_OUTFILE=$OUTDIR/prod_status.tmp

	if [ ${#RTVAR_AIMGR_NS} -gt 0 ] || [ ${#RTVAR_EVTMGR_NS} -gt 0 ] || [ ${#RTVAR_EVTMGR_HYBRID_NS} -gt 0 ]
	then
		# Manual user-input product namespaces
		for AIMGR_NS in $(echo "$RTVAR_AIMGR_NS" | sed 's/,/ /g')
		do
			echo "[$(date)] [${FUNCNAME[0]}] Adding [$AIMGR_NS] into WAIOPS_AIMGR_NAMESPACE_ARR array..." 
			WAIOPS_AIMGR_NAMESPACE_ARR[${#WAIOPS_AIMGR_NAMESPACE_ARR[@]}]=$AIMGR_NS
			WAIOPS_AIMGR_NS_USERINPUT="true"
		done

		for EVTMGR_NS in $(echo "$RTVAR_EVTMGR_NS" | sed 's/,/ /g')
		do
			echo "[$(date)] [${FUNCNAME[0]}] Adding [$EVTMGR_NS] into WAIOPS_EVTMGR_NAMESPACE_ARR array..." 
			WAIOPS_EVTMGR_NAMESPACE_ARR[${#WAIOPS_EVTMGR_NAMESPACE_ARR[@]}]=$EVTMGR_NS
			WAIOPS_EVTMGR_NS_USERINPUT="true"
		done

		for EVTMGR_HYBRID_NS in $(echo "$RTVAR_EVTMGR_HYBRID_NS" | sed 's/,/ /g')
		do
			echo "[$(date)] [${FUNCNAME[0]}] Adding [$EVTMGR_HYBRID_NS] into WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR array..." 
			WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[${#WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}]=$EVTMGR_HYBRID_NS
			WAIOPS_EVTMGR_HYBRID_NS_USERINPUT="true"
		done

		local AIMGR_PROD_LIST="installations.orchestrator.aiops.ibm.com aimanager"
		local EVTMGR_PROD_LIST="noi noihybrid"

		if [ ${#WAIOPS_AIMGR_NAMESPACE_ARR[@]} -gt 0 ]
		then
			for AIMGR_NS in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $AIMGR_NS" "$AIMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi

		if [ ${#WAIOPS_EVTMGR_NAMESPACE_ARR[@]} -gt 0 ] 
		then
			for EVTMGR_NS in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $EVTMGR_NS" "$EVTMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi

		if [ ${#WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]} -gt 0 ] 
		then
			for EVTMGR_HYBRID_NS in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $EVTMGR_HYBRID_NS" "$EVTMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi
	else
		local PROD_LIST="installations.orchestrator.aiops.ibm.com aimanager noi noihybrid"
		getProdNamespacesHelper "-A" "$PROD_LIST" "$PRODSTATUS_OUTFILE"	
	fi

	# To cater for user without cluster-admin privileges
	if [ $MG_TTY == "true" ]
	then
		if [ $WAIOPS_AIMGR_INSTALLED == "false" ] && [ $WAIOPS_EVTMGR_INSTALLED == "false" ] && [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "false" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Failed to detect product namespaces! Please provide the namespace details manually..." 
			echo "[$(date)] [${FUNCNAME[0]}] NOTE(1): If there is more than 1 namespace for a product, please separate the namespaces with comma(,)"
			echo "[$(date)] [${FUNCNAME[0]}] NOTE(2): If product is not installed, just press ENTER." 
	
			# Assume current namespace is AI Manager namespace
			local CUR_NAMESPACE=$($OC_CMD config current-context | $AWK -F'/' '{ print $1 }')
			local TO_ASK_AIMGR_NS="false"
	
			if [ ${#CUR_NAMESPACE} -gt 0 ] && $OC_CMD get ns $CUR_NAMESPACE > /dev/null 2>&1
			then
				local INVALID_USERINPUT=1
	
				while [ $INVALID_USERINPUT -eq 1 ]
				do
					echo "[$(date)] [${FUNCNAME[0]}] Is product '$WAIOPS_AIMGR_KIND' installed in current namespace [$CUR_NAMESPACE]? (y/n) "
					echo -n ">> "
					read -t $DEFAULT_USERINPUT_TIMEOUT WAIOPS_AIMGR_MANUAL_PRODNS
					local EXIT_STATUS=$?
	
					if [ $MG_DEBUG == "true" ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]" 
					fi
	
					if [ $EXIT_STATUS -gt 128 ]
					then
						echo 
						echo "[$(date)] [${FUNCNAME[0]}] [WARNING] Timeout waiting for user input. Auto answer [Y]..." 
						local WAIOPS_AIMGR_MANUAL_PRODNS=$CUR_NAMESPACE
						local INVALID_USERINPUT=0
					else
						if [ ${#WAIOPS_AIMGR_MANUAL_PRODNS} -eq 0 ]
						then
							echo "User input [$WAIOPS_AIMGR_MANUAL_PRODNS] is blank! Please enter [y/n]..."
							continue
						fi
		
						if [ ${WAIOPS_AIMGR_MANUAL_PRODNS} == "n" ] || [ ${WAIOPS_AIMGR_MANUAL_PRODNS} == "N" ]
						then
							echo "User input [$WAIOPS_AIMGR_MANUAL_PRODNS]!" 
							local INVALID_USERINPUT=0
							local TO_ASK_AIMGR_NS="true"
						else
							if [ ${WAIOPS_AIMGR_MANUAL_PRODNS} == "y" ] || [ ${WAIOPS_AIMGR_MANUAL_PRODNS} == "Y" ]
							then
								echo "User input [$WAIOPS_AIMGR_MANUAL_PRODNS]. To proceed..." 
								local WAIOPS_AIMGR_MANUAL_PRODNS=$CUR_NAMESPACE
								local INVALID_USERINPUT=0
							else
								echo "Invalid user input [$WAIOPS_AIMGR_MANUAL_PRODNS]! Please retry..." 
							fi
						fi
					fi
				done
			else
				local TO_ASK_AIMGR_NS="true"
			fi
	
			if [ $TO_ASK_AIMGR_NS == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Do you know in which namespace is product '$WAIOPS_AIMGR_KIND' installed? " 
				echo -n ">> "
				read -t $DEFAULT_USERINPUT_TIMEOUT WAIOPS_AIMGR_MANUAL_PRODNS
				local EXIT_STATUS=$?
	
				if [ $MG_DEBUG == "true" ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]" 
				fi
	
				if [ $EXIT_STATUS -gt 128 ]
				then
					echo 
					echo "[$(date)] [${FUNCNAME[0]}] [WARNING] Timeout waiting for user input. Auto answer [ENTER]..." 
				else
					echo "$WAIOPS_AIMGR_MANUAL_PRODNS" 
				fi
			fi
		
			echo "[$(date)] [${FUNCNAME[0]}] Do you know in which namespace is product '$WAIOPS_EVTMGR_KIND' installed? "
			echo -n ">> " 
			read -t $DEFAULT_USERINPUT_TIMEOUT WAIOPS_EVTMGR_MANUAL_PRODNS
			local EXIT_STATUS=$?
	
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]" 
			fi
	
			if [ $EXIT_STATUS -gt 128 ]
			then
				echo
				echo "[$(date)] [${FUNCNAME[0]}] [WARNING] Timeout waiting for user input. Auto answer [ENTER]..." 
			else
				echo "$WAIOPS_EVTMGR_MANUAL_PRODNS" 
			fi
	
			echo "[$(date)] [${FUNCNAME[0]}] Do you know in which namespace is product '$WAIOPS_EVTMGR_HYBRID_KIND' installed? "
			echo -n ">> " 
			read -t $DEFAULT_USERINPUT_TIMEOUT WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS
			local EXIT_STATUS=$?
	
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]" 
			fi
	
			if [ $EXIT_STATUS -gt 128 ]
			then
				echo 
				echo "[$(date)] [${FUNCNAME[0]}] [WARNING] Timeout waiting for user input. Auto answer [ENTER]..." 
			else
				echo "$WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS" 
			fi
	
			if [ ${#WAIOPS_AIMGR_MANUAL_PRODNS} -gt 0 ]
			then
				WAIOPS_MANUAL_DETECT="true"
	
				echo "[$(date)] [${FUNCNAME[0]}] Product [$WAIOPS_AIMGR_KIND] is installed in namespace [$WAIOPS_AIMGR_MANUAL_PRODNS]!"
	
				WAIOPS_AIMGR_INSTALLED="true"
				echo "$WAIOPS_AIMGR_KIND=$WAIOPS_AIMGR_MANUAL_PRODNS" >> $OUTFILE
	
				for NS in $(echo "$WAIOPS_AIMGR_MANUAL_PRODNS" | sed 's/,/ /g')
				do
					echo "$NS" >> $TMP_PROD_NS_FILE
					WAIOPS_AIMGR_NAMESPACE_ARR[${#WAIOPS_AIMGR_NAMESPACE_ARR[@]}]=$NS
				done
			fi
	
			if [ ${#WAIOPS_EVTMGR_MANUAL_PRODNS} -gt 0 ]
			then
				WAIOPS_MANUAL_DETECT="true"
	
				echo "[$(date)] [${FUNCNAME[0]}] Product [$WAIOPS_EVTMGR_KIND] is installed in namespace [$WAIOPS_EVTMGR_MANUAL_PRODNS]!"
	
				WAIOPS_EVTMGR_INSTALLED="true"
				echo "$WAIOPS_EVTMGR_KIND=$WAIOPS_EVTMGR_MANUAL_PRODNS" >> $OUTFILE
	
				for NS in $(echo "$WAIOPS_EVTMGR_MANUAL_PRODNS" | sed 's/,/ /g')
				do
					echo "$NS" >> $TMP_PROD_NS_FILE
					WAIOPS_EVTMGR_NAMESPACE_ARR[${#WAIOPS_EVTMGR_NAMESPACE_ARR[@]}]=$NS
				done
			fi
	
			if [ ${#WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS} -gt 0 ]
			then
				WAIOPS_MANUAL_DETECT="true"
	
				echo "[$(date)] [${FUNCNAME[0]}] Product [$WAIOPS_EVTMGR_HYBRID_KIND] is installed in namespace [$WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS]!"
	
				WAIOPS_EVTMGR_HYBRID_INSTALLED="true"
				echo "$WAIOPS_EVTMGR_HYBRID_KIND=$WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS" >> $OUTFILE
	
				for NS in $(echo "$WAIOPS_EVTMGR_HYBRID_MANUAL_PRODNS" | sed 's/,/ /g')
				do
					echo "$NS" >> $TMP_PROD_NS_FILE
					WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[${#WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}]=$NS
				done
			fi
		fi
	fi

	if [ -s $TMP_PROD_NS_FILE ]
	then
		for NS in $(sort $TMP_PROD_NS_FILE | uniq)
		do
			WAIOPS_PROD_NAMESPACES[${#WAIOPS_PROD_NAMESPACES[@]}]=$NS
		done

		rm -f $TMP_PROD_NS_FILE
	fi

	if [ $WAIOPS_AIMGR_INSTALLED == "true" ] && [ -s $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_AIMGR_KIND ]
	then
		local ALL_NS=

		while read INSTANCE
		do
			local AIMGR_INSTANCE_NAME=$(echo "$INSTANCE" | $AWK -F~ '{ print $1 }')	
			local AIMGR_NAMESPACE=$(echo "$INSTANCE" | $AWK -F~ '{ print $2 }')	

			# There is no need to populate this array if provided through -W AIMGR_NS
			if [ ! $WAIOPS_AIMGR_NS_USERINPUT == "true" ]
			then
				WAIOPS_AIMGR_NAMESPACE_ARR[${#WAIOPS_AIMGR_NAMESPACE_ARR[@]}]=$AIMGR_NAMESPACE
			fi

			if [ ${#ALL_NS} -eq 0 ]
			then
				local ALL_NS=$AIMGR_NAMESPACE
			else
				local ALL_NS="$ALL_NS,$AIMGR_NAMESPACE"
			fi
		done < $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_AIMGR_KIND

		echo "$WAIOPS_AIMGR_KIND=$ALL_NS" >> $OUTFILE

		rm -f $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_AIMGR_KIND
	fi

	if [ $WAIOPS_EVTMGR_INSTALLED == "true" ] && [ -s $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_KIND ]
	then
		local ALL_NS=

		while read INSTANCE
		do
			local EVTMGR_INSTANCE_NAME=$(echo "$INSTANCE" | $AWK -F~ '{ print $1 }')	
			local EVTMGR_NAMESPACE=$(echo "$INSTANCE" | $AWK -F~ '{ print $2 }')	

			# There is no need to populate this array if provided through -W EVTMGR_NS
			if [ ! $WAIOPS_EVTMGR_NS_USERINPUT == "true" ]
			then
				WAIOPS_EVTMGR_NAMESPACE_ARR[${#WAIOPS_EVTMGR_NAMESPACE_ARR[@]}]=$EVTMGR_NAMESPACE
			fi

			if [ ${#ALL_NS} -eq 0 ]
			then
				local ALL_NS=$EVTMGR_NAMESPACE
			else
				local ALL_NS="$ALL_NS,$EVTMGR_NAMESPACE"
			fi
		done < $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_KIND

		echo "$WAIOPS_EVTMGR_KIND=$ALL_NS" >> $OUTFILE

		rm -f $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_KIND
	fi

	if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ] && [ -s $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_HYBRID_KIND ]
	then
		local ALL_NS=

		while read INSTANCE
		do
			local EVTMGR_HYBRID_INSTANCE_NAME=$(echo "$INSTANCE" | $AWK -F~ '{ print $1 }')	
			local EVTMGR_HYBRID_NAMESPACE=$(echo "$INSTANCE" | $AWK -F~ '{ print $2 }')	

			# There is no need to populate this array if provided through -W EVTMGR_HYBRID_NS
			if [ ! $WAIOPS_EVTMGR_HYBRID_NS_USERINPUT == "true" ]
			then
				WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[${#WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}]=$EVTMGR_HYBRID_NAMESPACE
			fi

			if [ ${#ALL_NS} -eq 0 ]
			then
				ALL_NS=$EVTMGR_HYBRID_NAMESPACE
			else
				ALL_NS="$ALL_NS,$EVTMGR_HYBRID_NAMESPACE"
			fi
		done < $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_HYBRID_KIND

		echo "$WAIOPS_EVTMGR_HYBRID_KIND=$ALL_NS" >> $OUTFILE

		rm -f $PRODUCT_DATA_OUTDIR/.KIND_$WAIOPS_EVTMGR_HYBRID_KIND
	fi

	# Add ibm-common-services as a WAIOPS product/component
	if ! checkUserPriv get namespace all 
	then
		if [ $WAIOPS_AIMGR_INSTALLED == "true" ] || [ $WAIOPS_EVTMGR_INSTALLED == "true" ] || [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] User [$OC_WHOAMI] does not have privilege to perform verb [get] on resource 'namespace'. Assuming namespace [ibm-common-services] exists and is valid!"
		
			WAIOPS_PROD_NAMESPACES[${#WAIOPS_PROD_NAMESPACES[@]}]=ibm-common-services
			echo "ics=ibm-common-services" >> $OUTFILE
		
			WAIOPS_ICS_INSTALLED="true"
			WAIOPS_ICS_NAMESPACE_ARR[${#WAIOPS_ICS_NAMESPACE_ARR[@]}]="ibm-common-services"
		else
			echo "[$(date)] [${FUNCNAME[0]}] Main products (AI Manager, Event Manager and Event Manager Hybrid) are not installed. Skipping namespace [ibm-common-services]..."
		fi
	else
		if $OC_CMD get namespace ibm-common-services > /dev/null
		then
			if [ $WAIOPS_AIMGR_INSTALLED == "true" ] || [ $WAIOPS_EVTMGR_INSTALLED == "true" ] || [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
			then
				WAIOPS_PROD_NAMESPACES[${#WAIOPS_PROD_NAMESPACES[@]}]=ibm-common-services
				echo "ics=ibm-common-services" >> $OUTFILE
		
				WAIOPS_ICS_INSTALLED="true"
				WAIOPS_ICS_NAMESPACE_ARR[${#WAIOPS_ICS_NAMESPACE_ARR[@]}]="ibm-common-services"
			else
				echo "[$(date)] [${FUNCNAME[0]}] Main products (AI Manager, Event Manager and Event Manager Hybrid) are not installed. Skipping namespace [ibm-common-services]..."
			fi
		else
			# TODO: Check kube-public
			echo "[$(date)] [${FUNCNAME[0]}] Namespace [ibm-common-services] is invalid. Skipping..."
		fi
	fi

	rm -f $PRODSTATUS_OUTFILE
}

getProdNamespacesHelper()
{
	local NS_CMD=$1
	local PROD_LIST=$2
	local PRODSTATUS_OUTFILE=$3

	IFS=$OLDIFS
	for PROD in $(eval echo "$PROD_LIST")
	do
		if [ $PROD == "baseui" ] || [ $PROD == "ircore" ] || [ $PROD == "aiopsanalyticsorchestrator" ] || [ $PROD == "automationuiconfig" ] || [ $PROD == "automationbase" ] || [ $PROD == "cartridge" ] || [ $PROD == "cartridgerequirements" ] || [ $PROD == "eventprocessor" ] || [ $PROD == "aiopsui" ] 
		then
			local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.versions.reconciled,PHASE:status.conditions[?(@.type==\"Ready\")].reason'"
		else
			if [ $PROD == "asmformation" ] || [ $PROD == "noiformation" ] || [ $PROD == "cemformation" ]
			then
				local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:spec.version,PHASE:status.phase'"
			else
				if [ $PROD == "lifecycleservice" ]
				then
					local LC_STATUS=$($OC_CMD get $PROD $NS_CMD -o custom-columns='PHASE:status.conditions[?(@.type=="Lifecycle Service Ready")].reason' --no-headers)

					if [ ${#LC_STATUS} -gt 0 ]
					then
						if [[ $LC_STATUS =~ none ]]
						then
							local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.versions.reconciled,PHASE:status.conditions[?(@.type==\"LifecycleServiceReady\")].reason'"
						else
							local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.versions.reconciled,PHASE:status.conditions[?(@.type==\"Lifecycle Service Ready\")].reason'"
						fi
					else
						local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.versions.reconciled,PHASE:status.conditions[?(@.type==\"LifecycleServiceReady\")].reason'"
					fi
				else
					if [ $PROD == "zenservices" ]
					then
						local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.currentVersion,PHASE:status.zenStatus'"
					else
						local CMD="$OC_CMD get $PROD $NS_CMD -o custom-columns='KIND:kind,NAME:metadata.name,NAMESPACE:metadata.namespace,VERSION:status.versions.reconciled,PHASE:status.phase'"
					fi
				fi
			fi
		fi

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing command '$CMD'" 
		fi

		# if eval $CMD > $OUTDIR/$PROD.$$.tmp 2> >(tee -a $RUNTIME_LOGFILE >&2)
		if eval $CMD > $OUTDIR/$PROD.$$.tmp 
		then
			if [ -s $OUTDIR/$PROD.$$.tmp ]
			then
				if [ $(wc -l $OUTDIR/$PROD.$$.tmp | $AWK '{ print $1 }') -eq 1 ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Custom resource [$PROD] has no instance on the cluster! Skipping..."
					echo "$PROD N/A N/A N/A N/A" >> $PRODSTATUS_OUTFILE	
				fi

				while read PROD_LINE
				do
					if [[ $PROD_LINE =~ ^KIND ]]
					then
						continue
					else
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] PROD_LINE = [$PROD_LINE]"
						fi
					fi
					
					# To check output
					if [ $(echo "$PROD_LINE" | $AWK '{ print NF }') -lt 5 ]
					then
						# ASSUMPTION: k8s/OCP will never go wrong with the first 3 columns
						local KIND=$(echo "$PROD_LINE" | $AWK '{ print $1 }')	
						local NAME=$(echo "$PROD_LINE" | $AWK '{ print $2 }')
						local NAMESPACE=$(echo "$PROD_LINE" | $AWK '{ print $3 }')

						if [ $PROD == "baseui" ] || [ $PROD == "ircore" ] || [ $PROD == "aiopsanalyticsorchestrator" ]
						then
							local VERSION=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.versions.reconciled}')
							local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.conditions[?(@.type=="Ready")].reason}')
						else
							if [ $PROD == "asmformation" ] || [ $PROD == "noiformation" ] || [ $PROD == "cemformation" ]
							then
								local VERSION=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.spec.version}')
								local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.phase}')
							else
								if [ $PROD == "lifecycleservice" ]
								then
									local VERSION=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.versions.reconciled}')
									local LC_STATUS=$($OC_CMD get $PROD $NS_CMD -o custom-columns='PHASE:status.conditions[?(@.type=="Lifecycle Service Ready")].reason' --no-headers)

									if [ ${#LC_STATUS} -gt 0 ]
									then
										if [[ $LC_STATUS =~ none ]]
										then
											local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.conditions[?(@.type=="LifecycleServiceReady")].reason}')
										else
											local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.conditions[?(@.type=="Lifecycle Service Ready")].reason}')
										fi
									else
										local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.conditions[?(@.type=="LifecycleServiceReady")].reason}')
									fi
								else
									local VERSION=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.versions.reconciled}')
									local PHASE=$($OC_CMD get $KIND $NAME -n $NAMESPACE -o=jsonpath='{.status.conditions[?(@.type=="Ready")].reason}')
								fi
							fi
						fi

						if [ ${#VERSION} -eq 0 ]
						then
							local VERSION="N/A"
						fi

						if [ ${#PHASE} -eq 0 ]
						then
							local PHASE="N/A"
						fi
					else
						local KIND=$(echo "$PROD_LINE" | $AWK '{ print $1 }')
						local NAME=$(echo "$PROD_LINE" | $AWK '{ print $2 }')
						local NAMESPACE=$(echo "$PROD_LINE" | $AWK '{ print $3 }')
						local VERSION=$(echo "$PROD_LINE" | $AWK '{ print $4 }')
						local PHASE=$(echo "$PROD_LINE" | $AWK 'BEGIN {STR=""}{ for (i=5; i<=NF; i++) { if (i==5) {STR=$i} else {STR=STR "-" $i} } } END {print STR}')
					fi

					echo -e "$KIND\t$NAME\t$NAMESPACE\t$VERSION\t$PHASE" >> $PRODSTATUS_OUTFILE
	
					if [ $(echo "$KIND" | $AWK '{ print tolower($0) }') == $WAIOPS_AIMGR_KIND ]
					then
						WAIOPS_AIMGR_INSTALLED="true"
						echo "[$(date)] [${FUNCNAME[0]}] Product [$KIND] is installed in namespace [$NAMESPACE]!"

						echo "$NAMESPACE" >> $TMP_PROD_NS_FILE
						echo "$NAME~$NAMESPACE" >> $PRODUCT_DATA_OUTDIR/.KIND_$(echo "$KIND" | $AWK '{ print tolower($0) }')
					fi
	
					if [ $(echo "$KIND" | $AWK '{ print tolower($0) }') == $WAIOPS_EVTMGR_KIND ]
					then
						WAIOPS_EVTMGR_INSTALLED="true"
						echo "[$(date)] [${FUNCNAME[0]}] Product [$KIND] is installed in namespace [$NAMESPACE]!"

						echo "$NAMESPACE" >> $TMP_PROD_NS_FILE
						echo "$NAME~$NAMESPACE" >> $PRODUCT_DATA_OUTDIR/.KIND_$(echo "$KIND" | $AWK '{ print tolower($0) }')
					fi

					if [ $(echo "$KIND" | $AWK '{ print tolower($0) }') == $WAIOPS_EVTMGR_HYBRID_KIND ]
					then
						WAIOPS_EVTMGR_HYBRID_INSTALLED="true"
						echo "[$(date)] [${FUNCNAME[0]}] Product [$KIND] is installed in namespace [$NAMESPACE]!"

						echo "$NAMESPACE" >> $TMP_PROD_NS_FILE
						echo "$NAME~$NAMESPACE" >> $PRODUCT_DATA_OUTDIR/.KIND_$(echo "$KIND" | $AWK '{ print tolower($0) }')
					fi
				done < $OUTDIR/$PROD.$$.tmp

				rm -f $OUTDIR/$PROD.$$.tmp
			else
				echo "[$(date)] [${FUNCNAME[0]}] Output file [$OUTDIR/$PROD.$$.tmp] does not exist or is zero-sized!"
				echo "$PROD N/A N/A N/A N/A" >> $PRODSTATUS_OUTFILE	
				rm -f $OUTDIR/$PROD.$$.tmp
			fi	
		else
			echo "$PROD N/A N/A N/A N/A" >> $PRODSTATUS_OUTFILE	
			rm -f $OUTDIR/$PROD.$$.tmp
		fi
	done
}

checkForUpdate()
{
	local MUSTGATHER_URL=https://www.ibm.com/support/pages/node/6458081
	local UPDATE_CHECK_DATETIME=$(date +%s)
	local TMPDIR=$ROOT_OUTDIR/$UPDATE_CHECK_DATETIME
	local TMPFILE=$TMPDIR/6458081
	local UPDATE_TIMEOUT=5

	# Various formatting elements
	local newline='\n'
	local red=$(tput setaf 1)
	local green=$(tput setaf 2)
	local blue=$(tput setaf 4)
	local white=$(tput setaf 7)
	local bold=$(tput bold)
	local normal=$(tput sgr0) #reset color/bolding

	if [ -f $TMPFILE ]
	then
		rm -f $TMPFILE
	fi

	# Check early whether the user can create backup directory
	if [ $MG_DEBUG == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Trying to create test backup directory [${MUSTGATHER_DIRNAME}-$$]..."
	fi

	if ! mkdir -p ${MUSTGATHER_DIRNAME}-$$
	then
		echo "[$(date)] [${FUNCNAME[0]}] User does not have write permission to create backup directory in [$(dirname ${MUSTGATHER_DIRNAME})]! Skipping update..."
		return 1
	else
		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] User has write permission to create backup directory in [$(dirname ${MUSTGATHER_DIRNAME})]! Proceeding..."
		fi

		rmdir ${MUSTGATHER_DIRNAME}-$$
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Checking for update..."
	wget -nv $MUSTGATHER_URL --timeout $UPDATE_TIMEOUT -P $TMPDIR &
	local WGET_PID=$!
	local MAX_WAIT=8
	local SLEEP_INTERVAL=1
	local WAIT_CTR=0
	local CONT_TO_WAIT="true"

	if [ ! -s $TMPFILE ]
	then
		while [ $CONT_TO_WAIT == "true" ]
		do	
			local WGET_PS=$(ps -ef | $AWK '$2 ~ /^'$WGET_PID'$/ { print $0 }')
	
			if [ ${#WGET_PS} -gt 0 ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Waiting for 'wget' command to complete..."
				(( WAIT_CTR=WAIT_CTR+$SLEEP_INTERVAL ))
				sleep $SLEEP_INTERVAL
			else
				CONT_TO_WAIT="false"
				break
			fi
	
			if [ $WAIT_CTR -gt $MAX_WAIT ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Timed out waiting for 'wget' command to complete..."
				printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Failed to upgrade ${PRODUCT_NAME} MustGather Tool!${normal}${newline}"
				CONT_TO_WAIT="false"
				kill -9 "$WGET_PID" 	
				wait $! 2> /dev/null
				rm -r $TMPDIR
				return 1
			fi
		done
	fi

	if [ -s $TMPFILE ]
	then
		if [[ ! "$TMPFILE" =~ $TMPDIR ]]
		then
			echo "[$(date)] [${FUNCNAME[0]}] TMPFILE [$TMPFILE] does not seem to reside under working directory [$TMPDIR]! Skipping update..."
			return 1
		fi

		local ATTACHMENT_PATH=$(egrep 'attachment.*waiops-mustgather.*tar.gz' $TMPFILE | $AWK -F'href="' '{ print $2 }' | sed 's#">.*##')
		local DOWNLOAD_FILE="https://www.ibm.com"$ATTACHMENT_PATH
		local ONLINE_VERSION=$(echo "$ATTACHMENT_PATH" | $AWK -Fv '{ print $2 }' | sed 's#.tar.gz##')
		local UPDATE_MSG=$(egrep 'checkForUpdateMsg' $TMPFILE | $AWK -F'>' '{ print $2 }' | $AWK -F'<' '{ print $1 }' | sed 's/^[ \t]*//' | sed 's/[ \t]*//')

		if [[ ! $ONLINE_VERSION =~ ^[0-9]{1,}\.[0-9]{1,}\.[0-9]{1,}$ ]]
		then
			printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to determine the latest version of ${PRODUCT_NAME} MustGather Tool!${normal}${newline}"

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] ONLINE_VERSION = [$ONLINE_VERSION] / CURRENT_VERSION = [$MG_VERSION]"
			fi

			rm -r $TMPDIR
			return 1
		fi

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] ONLINE_VERSION = [$ONLINE_VERSION] / CURRENT_VERSION = [$MG_VERSION]"
		fi

		rm -f $TMPFILE
	else
		printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to determine the latest version of ${PRODUCT_NAME} MustGather Tool!${normal}${newline}"
		rm -r $TMPDIR
		return 1
	fi
	
	local TO_UPGRADE="false"

	if [ $(echo "$MG_VERSION" | $AWK -F'.' '{ print NF }') -eq 3 ] && [ $(echo "$ONLINE_VERSION" | $AWK -F'.' '{ print NF }') -eq 3 ]
	then
		local MG_MAJOR_VER=$(echo "$MG_VERSION" | $AWK -F'.' '{ print $1 }')
		local MG_MINOR_VER=$(echo "$MG_VERSION" | $AWK -F'.' '{ print $2 }')
		local MG_REV_VER=$(echo "$MG_VERSION" | $AWK -F'.' '{ print $3 }')
		local ONLINE_MAJOR_VER=$(echo "$ONLINE_VERSION" | $AWK -F'.' '{ print $1 }')
		local ONLINE_MINOR_VER=$(echo "$ONLINE_VERSION" | $AWK -F'.' '{ print $2 }')
		local ONLINE_REV_VER=$(echo "$ONLINE_VERSION" | $AWK -F'.' '{ print $3 }')
	
		if [ $ONLINE_MAJOR_VER -gt $MG_MAJOR_VER ]
		then
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] ONLINE_MAJOR_VER [$ONLINE_MAJOR_VER] / MG_MAJOR_VER [$MG_MAJOR_VER]"
			fi

			local TO_UPGRADE="true"
		else
			if [ $ONLINE_MAJOR_VER -eq $MG_MAJOR_VER ]
			then
				if [ $ONLINE_MINOR_VER -gt $MG_MINOR_VER ]
				then
					if [ $MG_DEBUG == "true" ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] ONLINE_MINOR_VER [$ONLINE_MINOR_VER] / MG_MINOR_VER [$MG_MINOR_VER]"
					fi
	
					local TO_UPGRADE="true"
				else
					if [ $ONLINE_MINOR_VER -eq $MG_MINOR_VER ]
					then
						if [ $ONLINE_REV_VER -gt $MG_REV_VER ]
						then
							if [ $MG_DEBUG == "true" ]
							then
								echo "[$(date)] [${FUNCNAME[0]}] ONLINE_REV_VER [$ONLINE_REV_VER] / MG_REV_VER [$MG_REV_VER]"
							fi
	
							local TO_UPGRADE="true"
						fi
					fi
				fi
			fi
		fi
	
		if [ $TO_UPGRADE == "true" ]
		then
			if [ ${#UPDATE_MSG} -gt 0 ]
			then
				printf "[$(date)] [${FUNCNAME[0]}] ${bold}${green}[MESSAGE] ${UPDATE_MSG}${normal}${newline}"
			fi

			local PROMPT_TO_DOWNLOAD=1
	
			while [ $PROMPT_TO_DOWNLOAD -eq 1 ]
			do
				if [ $AUTO_YES == "true" ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Option [-Y] is set! Auto answering [y]..."
					DOWNLOAD_AGREEMENT="Y"
				else
					if [ $MG_TTY == "false" ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] In non-TTY mode, auto answering [n]..."
						DOWNLOAD_AGREEMENT="N"
					else
						printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}There is a newer version of ${PRODUCT_NAME} MustGather Tool [$ONLINE_VERSION]. Do you want to download (y/n)? ${normal}"
						read -t $DEFAULT_USERINPUT_TIMEOUT DOWNLOAD_AGREEMENT
						local EXIT_STATUS=$?
	
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]"
						fi
	
						if [ $EXIT_STATUS -gt 128 ]
						then
							echo
							echo "[$(date)] [${FUNCNAME[0]}] Timeout waiting for user input. Auto answer [N]..."
							DOWNLOAD_AGREEMENT="N"
						fi
					fi
				fi
	
				if [ ${DOWNLOAD_AGREEMENT} == "n" ] || [ ${DOWNLOAD_AGREEMENT} == "N" ]
				then
					echo "User input [$DOWNLOAD_AGREEMENT]. Not downloading the latest version of ${PRODUCT_NAME} MustGather Tool [$ONLINE_VERSION]!" 
					rm -r $TMPDIR
					return $WAIOPS_MG_LATEST_VER_CODE
				else
					if [ ${DOWNLOAD_AGREEMENT} == "y" ] || [ ${DOWNLOAD_AGREEMENT} == "Y" ]
					then
						echo "User input [$DOWNLOAD_AGREEMENT]. To proceed to download..." 
						local DOWNLOAD_CMD="wget -nv $DOWNLOAD_FILE --timeout $UPDATE_TIMEOUT -P $TMPDIR"
					
						if [ -f $TMPDIR/$(basename $DOWNLOAD_FILE) ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] Download file [$TMPDIR/$(basename $DOWNLOAD_FILE)] exists locally. To rename existing file to [$TMPDIR/$(basename $DOWNLOAD_FILE)-${UPDATE_CHECK_DATETIME}]..."
							mv $TMPDIR/$(basename $DOWNLOAD_FILE) $TMPDIR/$(basename $DOWNLOAD_FILE)-${UPDATE_CHECK_DATETIME}
						fi
	
						echo "[$(date)] [${FUNCNAME[0]}] Executing download command [$DOWNLOAD_CMD]..."
						eval "$DOWNLOAD_CMD &" 

						local WGET_PID=$!
						local MAX_WAIT=8
						local SLEEP_INTERVAL=2
						local WAIT_CTR=0
						local CONT_TO_WAIT="true"
					
						if [ ! -s $TMPDIR/$(basename $DOWNLOAD_FILE) ]
						then
							while [ $CONT_TO_WAIT == "true" ]
							do	
								local WGET_PS=$(ps -ef | $AWK '$2 ~ /^'$WGET_PID'$/ { print $0 }')
						
								if [ ${#WGET_PS} -gt 0 ]
								then
									echo "[$(date)] [${FUNCNAME[0]}] Waiting for download command to complete..."
									(( WAIT_CTR=WAIT_CTR+$SLEEP_INTERVAL ))
									sleep $SLEEP_INTERVAL
								else
									CONT_TO_WAIT="false"
									break
								fi
						
								if [ $WAIT_CTR -gt $MAX_WAIT ]
								then
									echo "[$(date)] [${FUNCNAME[0]}] Timed out waiting for download command to complete..."
									printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Failed to download package for ${PRODUCT_NAME} MustGather Tool!${normal}${newline}"
									CONT_TO_WAIT="false"
									kill -9 "$WGET_PID" 	
									wait $! 2> /dev/null
									rm -r $TMPDIR
									return 1
								fi
							done
						fi
	
						if [ -s $TMPDIR/$(basename $DOWNLOAD_FILE) ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] Latest ${PRODUCT_NAME} MustGather Tool [$TMPDIR/$(basename $DOWNLOAD_FILE)] version [$ONLINE_VERSION] is downloaded successfully!"			

							local LOCAL_TAR=$(which tar)
	
							if [ ${#LOCAL_TAR} -eq 0 ]
							then
								printf "[$(date)] [${FUNCNAME[0]}] Please uncompress the downloaded file [${bold}${green}tar zxvf $TMPDIR/$(basename $DOWNLOAD_FILE)${normal}] and execute the mustgather again!${newline}"
								printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}IMPORTANT: Please backup all custom configuration files in the current MustGather directory before uncompressing the downloaded file!${normal}${newline}"
							else
								local UPDATE_CUR_DATETIME=$(date +%d%B%y-%H%M%S)
								echo "[$(date)] [${FUNCNAME[0]}] Backing up current WAIOPS MustGather directory [$MUSTGATHER_DIRNAME] to [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME]..."
								mkdir -p ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME
								# cp -rp $MUSTGATHER_DIRNAME/* ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME
								cp -Rap $MUSTGATHER_DIRNAME/. ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME

								if [ ! -d ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME ]
								then
									echo "[$(date)] [${FUNCNAME[0]}] Backup directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME] does not exist! Skipping update..."
									rm -r $TMPDIR
									return 1
								else
									local TARGET_DIR_SIZE=$(du -s ${MUSTGATHER_DIRNAME} | $AWK '{ print $1 }')
									local BACKUP_DIR_SIZE=$(du -s ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME | $AWK '{ print $1 }')
									echo "[$(date)] [${FUNCNAME[0]}] TARGET_DIR_SIZE = [$TARGET_DIR_SIZE] / BACKUP_DIR_SIZE = [$BACKUP_DIR_SIZE]"	

									local TARGET_DIR_FILECOUNT=$(find $MUSTGATHER_DIRNAME | wc -l)
									local BACKUP_DIR_FILECOUNT=$(find ${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME | wc -l)
									echo "[$(date)] [${FUNCNAME[0]}] TARGET_DIR_FILECOUNT = [$TARGET_DIR_FILECOUNT] / BACKUP_DIR_FILECOUNT = [$BACKUP_DIR_FILECOUNT]"	
									
									if [ ${#BACKUP_DIR_SIZE} -gt 0 ]
									then
										if [ $BACKUP_DIR_SIZE == 0 ]
										then
											echo "[$(date)] [${FUNCNAME[0]}] Backup to directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME] did not seem to be successful! Skipping update..."
											rm -r $TMPDIR
											return 1
										else
											if [ ${#TARGET_DIR_SIZE} -gt 0 ]
											then
												if [ "$TARGET_DIR_SIZE" != "$BACKUP_DIR_SIZE" ]
												then
													echo "[$(date)] [${FUNCNAME[0]}] Size of backup directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME] is different from size of target directory [$MUSTGATHER_DIRNAME]! Skipping update..."
													rm -r $TMPDIR
													return 1
												fi

												if [ ${#BACKUP_DIR_FILECOUNT} -gt 0 ]
												then
													if [ ${#TARGET_DIR_FILECOUNT} -gt 0 ]
													then
														if [ "$TARGET_DIR_FILECOUNT" != "$BACKUP_DIR_FILECOUNT" ]
														then
															echo "[$(date)] [${FUNCNAME[0]}] File count of backup directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME] is different from file count of target directory [$MUSTGATHER_DIRNAME]! Skipping update..."
															rm -r $TMPDIR
															return 1
														fi
													else
														echo "[$(date)] [${FUNCNAME[0]}] Unable to determine file count of target directory [${MUSTGATHER_DIRNAME}]! Skipping update..."
														rm -r $TMPDIR
														return 1
													fi
												else
													echo "[$(date)] [${FUNCNAME[0]}] Unable to determine file count of backup directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME]! Skipping update..."
													rm -r $TMPDIR
													return 1
												fi
											else
												echo "[$(date)] [${FUNCNAME[0]}] Unable to determine size of target directory [${MUSTGATHER_DIRNAME}]! Skipping update..."
												rm -r $TMPDIR
												return 1
											fi
										fi
									else
										echo "[$(date)] [${FUNCNAME[0]}] Unable to determine size of backup directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME]! Skipping update..."
										rm -r $TMPDIR
										return 1
									fi
								fi
						
								local INVALID_USERINPUT=1
					
								while [ $INVALID_USERINPUT -eq 1 ]
								do
									printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Can we proceed to remove content of directory [$MUSTGATHER_DIRNAME]? (y/n) ${normal}"

									if [ $AUTO_YES == "true" ]
									then
										echo "y"
										echo "[$(date)] [${FUNCNAME[0]}] Option [-Y] is set! Auto answering [y]..."
										local INVALID_USERINPUT=0
									else
										read -t $DEFAULT_USERINPUT_TIMEOUT WAIOPS_UPGRADE_CLEANUP_AGREEMENT
										local EXIT_STATUS=$?
						
										if [ $MG_DEBUG == "true" ]
										then
											echo "[$(date)] [${FUNCNAME[0]}] EXIT_STATUS = [$EXIT_STATUS]" 
										fi
						
										if [ $EXIT_STATUS -gt 128 ]
										then
											echo 
											echo "[$(date)] [${FUNCNAME[0]}] [WARNING] Timeout waiting for user input. Auto answer [n]..." 
											echo "[$(date)] [${FUNCNAME[0]}] Unable to obtain user agreement to remove content of directory [$MUSTGATHER_DIRNAME]! Skipping update..."
											rm -r $TMPDIR
											return 1
										else
											if [ ${#WAIOPS_UPGRADE_CLEANUP_AGREEMENT} -eq 0 ]
											then
												echo "User input [$WAIOPS_AIMGR_MANUAL_PRODNS] is blank! Please enter [y/n]..."
												continue
											fi
							
											if [ ${WAIOPS_UPGRADE_CLEANUP_AGREEMENT} == "n" ] || [ ${WAIOPS_UPGRADE_CLEANUP_AGREEMENT} == "N" ]
											then
												echo "[$(date)] [${FUNCNAME[0]}] User input [$WAIOPS_UPGRADE_CLEANUP_AGREEMENT]! Skipping update..." 
												rm -r $TMPDIR
												return 1	
											else
												if [ ${WAIOPS_UPGRADE_CLEANUP_AGREEMENT} == "y" ] || [ ${WAIOPS_UPGRADE_CLEANUP_AGREEMENT} == "Y" ]
												then
													echo "User input [$WAIOPS_UPGRADE_CLEANUP_AGREEMENT]. To proceed..." 
													local INVALID_USERINPUT=0
												else
													echo "Invalid user input [$WAIOPS_AIMGR_MANUAL_PRODNS]! Please retry..." 
												fi
											fi
										fi
									fi
								done

								echo "[$(date)] [${FUNCNAME[0]}] Deleting content from directory [$MUSTGATHER_DIRNAME]..."
								rm -r $MUSTGATHER_DIRNAME/*
								echo "[$(date)] [${FUNCNAME[0]}] Unpacking downloaded package [$TMPDIR/$(basename $DOWNLOAD_FILE)] to directory [$MUSTGATHER_DIRNAME]..."
								# tar zxf $TMPDIR/$(basename $DOWNLOAD_FILE) -C $MUSTGATHER_DIRNAME
								tar zxf $TMPDIR/$(basename $DOWNLOAD_FILE) -C $MUSTGATHER_DIRNAME --strip-components=1
		
								local UPDATE_SNAPSHOTS_DIR=

								for UPDATE_SNAPSHOTS_DIR in $(find ${MUSTGATHER_DIRNAME}-${UPDATE_CUR_DATETIME}/snapshots -type d | egrep -v "^${MUSTGATHER_DIRNAME}-${UPDATE_CUR_DATETIME}/snapshots\$")
								do
									echo "[$(date)] [${FUNCNAME[0]}] Restoring snapshots directory [$UPDATE_SNAPSHOTS_DIR] to directory [${MUSTGATHER_DIRNAME}/snapshots]..."
									cp -rp ${UPDATE_SNAPSHOTS_DIR} ${MUSTGATHER_DIRNAME}/snapshots
								done

								if ls -l $MUSTGATHER_DIRNAME
								then
									if [ -s $MUSTGATHER_DIRNAME/config/product.cfg ]
									then	
										local NEW_MG_VERSION=$(grep '^MG_VERSION=' $MUSTGATHER_DIRNAME/config/product.cfg)

										if [ ${#NEW_MG_VERSION} -gt 0 ]
										then
											local NEW_MG_VERSION_VAL=$(echo "$NEW_MG_VERSION" | $AWK -F= '{ print $2 }')		

											if [ ${#NEW_MG_VERSION_VAL} -gt 0 ]
											then
												if [ "$NEW_MG_VERSION_VAL" == "$ONLINE_VERSION" ]
												then	
													printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}WAIOPS MustGather was updated successfully to version [${green}$ONLINE_VERSION${red}]!${normal}${newline}"
													printf "[$(date)] [${FUNCNAME[0]}] ${bold}IMPORTANT:${normal} Please restore all ${bold}CUSTOM${normal} configuration files/settings in directory [${MUSTGATHER_DIRNAME}-$UPDATE_CUR_DATETIME] to directory [$MUSTGATHER_DIRNAME]!${newline}"
												else	
													printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Version of the downloaded WAIOPS MustGather [$NEW_MG_VERSION_VAL] is not the same as the latest online version [$ONLINE_VERSION]!${normal}${newline}"
													printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}FATAL: WAIOPS MustGather upgrade to version [$ONLINE_VERSION] has failed!${normal}${newline}"
													rm -r $TMPDIR
													return 1
												fi
											else
												printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to determine version of the new WAIOPS MustGather!${normal}${newline}"
												printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}FATAL: WAIOPS MustGather upgrade to version [$ONLINE_VERSION] has failed!${normal}${newline}"
												rm -r $TMPDIR
												return 1
											fi
										else
											printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to extract version of the new WAIOPS MustGather!${normal}${newline}"
											printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}FATAL: WAIOPS MustGather upgrade to version [$ONLINE_VERSION] has failed!${normal}${newline}"
											rm -r $TMPDIR
											return 1
										fi
									else	
										printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to locate product configuration file of the new WAIOPS MustGather!${normal}${newline}"
										printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}FATAL: WAIOPS MustGather upgrade to version [$ONLINE_VERSION] has failed!${normal}${newline}"	
										rm -r $TMPDIR
										return 1
									fi
								else
									printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Unable to perform file listing of the WAIOPS MustGather directory!${normal}${newline}"
									printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}FATAL: WAIOPS MustGather upgrade to version [$ONLINE_VERSION] has failed!${normal}${newline}"
									rm -r $TMPDIR
									return 1
								fi
							fi
						else
							printf "[$(date)] [${FUNCNAME[0]}] ${bold}${red}Failed to download the latest version of ${PRODUCT_NAME} MustGather Tool [$ONLINE_VERSION]!${normal}${newline}"
							rm -r $TMPDIR
							return 1
						fi

						local PROMPT_TO_DOWNLOAD=0
					else
						echo "Invalid user input [$DOWNLOAD_AGREEMENT]! Please retry..." 
					fi
				fi
			done
		else
			printf "[$(date)] [${FUNCNAME[0]}] ${bold}${green}${PRODUCT_NAME} MustGather Tool [$MG_VERSION] is the latest!${normal}${newline}"
			rm -r $TMPDIR
			return $WAIOPS_MG_LATEST_VER_CODE
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] Invalid format of MG_VERSION [$MG_VERSION] or ONLINE_VERSION [$ONLINE_VERSION]!"
		rm -r $TMPDIR
		return 1
	fi

	rm -r $TMPDIR
}

getAll()
{
	getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
	getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
	getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
	getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out
	descNode $CLUSTER_DATA_OUTDIR/nodes
	analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
	ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
	ocDesc storageclass $CLUSTER_DATA_OUTDIR/storageclass
	echoStorageClass
	getEtcd $CLUSTER_DATA_OUTDIR/etcd
	getOcProdStatus
	echoOcProdStatus
	getOcInstallation
	getOcNoi

	local NS=

	for NS in ${WAIOPS_PROD_NAMESPACES[@]}
	do
		echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

		if toExcludeProdNamespace $NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
			continue
		fi

		local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"

		if [ ! -d $NS_OUTDIR ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
			mkdir -p $NS_OUTDIR
		fi

		getOcAdmTopCpuPod $NS $NS_OUTDIR/oc_top_cpu_pod.out
		getOcAdmTopMemPod $NS $NS_OUTDIR/oc_top_mem_pod.out
		echoCsv $NS
		echoSubscription $NS
		getOcAll $NS $NS_OUTDIR/oc_all.out
	
		local EXCL_OBJ_LIST=(subscription.messaging.knative.dev)
		descAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR $EXCL_OBJ_LIST

		if [ ${#RTVAR_DISABLE_PROD_ANALYTICS} -gt 0 ] && [ $RTVAR_DISABLE_PROD_ANALYTICS == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data analytics for product namespaces is turned off [RTVAR_DISABLE_PROD_ANALYTICS = $RTVAR_DISABLE_PROD_ANALYTICS]!"
		else
			analyzeOcAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR 
		fi

		if [ ${#RTVAR_GETALL_SUBSET_DATA} -gt 0 ] && [ ${RTVAR_GETALL_SUBSET_DATA} == "true" ]
		then
			ocGet csv $NS_OUTDIR/oc_csv.out $NS
			ocDesc csv $NS_OUTDIR/csv $NS
			ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
			ocDesc pvc $NS_OUTDIR/pvc $NS
			analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
			ocGet cert $NS_OUTDIR/oc_cert.out $NS
			ocDesc cert $NS_OUTDIR/cert $NS
			analyzeOcCert $NS $NS_OUTDIR/oc_cert.out $NS_OUTDIR/cert
			getOcSecrets $NS $NS_OUTDIR/oc_secrets.out
			descSecrets $NS $NS_OUTDIR/secrets
			ocGet configmap $NS_OUTDIR/oc_configmaps.out $NS
			ocDesc configmap $NS_OUTDIR/configmap $NS
			ocGet serviceaccount $NS_OUTDIR/oc_serviceaccounts.out $NS
			ocDesc serviceaccount $NS_OUTDIR/serviceaccounts $NS
			ocGet operandrequest $NS_OUTDIR/oc_operandrequests.out $NS
			ocDesc operandrequest $NS_OUTDIR/operandrequests $NS
			ocGet operandregistry $NS_OUTDIR/oc_operandregistrys.out $NS
			ocDesc operandregistry $NS_OUTDIR/operandregistrys $NS
			ocGet operandconfig $NS_OUTDIR/oc_operandconfigs.out $NS
			ocDesc operandconfig $NS_OUTDIR/operandconfigs $NS
			ocGet endpoints $NS_OUTDIR/oc_endpoints.out $NS
			ocDesc endpoints $NS_OUTDIR/endpoints $NS
			ocGet ingress $NS_OUTDIR/oc_ingress.out $NS
			ocDesc ingress $NS_OUTDIR/ingress $NS
			ocGet networkpolicy $NS_OUTDIR/oc_networkpolicy.out $NS
			ocDesc networkpolicy $NS_OUTDIR/networkpolicy $NS
			ocGet roles $NS_OUTDIR/oc_roles.out $NS
			ocDesc roles $NS_OUTDIR/roles $NS
			ocGet rolebindings $NS_OUTDIR/oc_rolebindings.out $NS
			ocDesc rolebindings $NS_OUTDIR/rolebindings $NS
			ocGet subscriptions $NS_OUTDIR/oc_subscriptions.out $NS
			ocDesc subscriptions $NS_OUTDIR/subscriptions $NS
			ocGet poddisruptionbudgets $NS_OUTDIR/oc_poddisruptionbudgets.out $NS
			ocDesc poddisruptionbudgets $NS_OUTDIR/poddisruptionbudgets $NS
			ocGet certificaterequests $NS_OUTDIR/oc_certificaterequests.out $NS
			ocDesc certificaterequests $NS_OUTDIR/certificaterequests $NS
			ocGet installplans $NS_OUTDIR/oc_installplans.out $NS
			ocDesc installplans $NS_OUTDIR/installplans $NS
		else
			echo "[$(date)] [${FUNCNAME[0]}] Retrieving all resource types covered by 'oc get all' in namespace [$NS]..."
			local OC_ALL_RESTYPE_LIST=$(getAllResTypeFromOcAll $NS_OUTDIR/oc_all.out)

			echo "[$(date)] [${FUNCNAME[0]}] Retrieving all resource types associated with namespace [$NS]..."
			local NS_ALL_RESTYPE=$(getAllResTypeForNS $NS)
	
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] [$NS] OC_ALL_RESTYPE_LIST = [$OC_ALL_RESTYPE_LIST][TOTAL=$(echo "$OC_ALL_RESTYPE_LIST" | $AWK '{ print NF }')]"
				echo "[$(date)] [${FUNCNAME[0]}] [$NS] NS_ALL_RESTYPE = [$NS_ALL_RESTYPE][TOTAL=$(echo "$NS_ALL_RESTYPE" | $AWK '{ print NF }')]"
			fi
	
			IFS=$OLDIFS
			local RES_LONGNAME=
	
			for RES_LONGNAME in $NS_ALL_RESTYPE
			do
				local RESTYPE=$(getApiResName "$RES_LONGNAME")
				local RESTYPE_FOUND="false"
				IFS=$OLDIFS

				for OC_ALL_RESTYPE in $OC_ALL_RESTYPE_LIST
				do
					# echo "RESTYPE = [$RESTYPE] / OC_ALL_RESTYPE = [$OC_ALL_RESTYPE]"
					if [ $RES_LONGNAME == $OC_ALL_RESTYPE ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Resource type [$RES_LONGNAME] was handled by 'getOcAll()'! Skipping..."
						local RESTYPE_FOUND="true"
						break	
					fi
				done

				if [ $RESTYPE_FOUND == "false" ]
				then
					if [ $MG_DEBUG == "true" ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Resource type long name [$RES_LONGNAME] => [$RESTYPE]"
					fi

					ocGet $RESTYPE $NS_OUTDIR/oc_$RESTYPE.out $NS
					ocDesc $RESTYPE $NS_OUTDIR/$RESTYPE $NS
				fi
			done

			analyzeOcPvc $NS $NS_OUTDIR/oc_persistentvolumeclaim.out $NS_OUTDIR/persistentvolumeclaim
		fi

		if [ ${#OPENSSL} -gt 0 ] && [ $IS_SENSITIVE_DATA_ALLOWED == "true" ]
		then
			get_cert_from_routes $NS $NS_OUTDIR
		fi
	done

	if [ $WAIOPS_AIMGR_INSTALLED == "true" ]
	then
		getMetricsData

		for AIMGR_NAMESPACE in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $AIMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$AIMGR_NAMESPACE]. Skipping..."
				continue
			fi

			echoTestPodNw $AIMGR_NAMESPACE
			local CONNECTIVITY_POD_ARRAY=(aimanager-aio-controller strimzi-cluster-zookeeper aimanager-aio-chatops-slack-integrator modeltrain-ibm-modeltrain-ratelimiter)
			local SUCC_CTR=0
			local SUCC_LIMIT=4
		
			for POD in ${CONNECTIVITY_POD_ARRAY[@]}
			do
				if testPodNw $AIMGR_NAMESPACE $POD cp.icr.io ping
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if testPodNw $AIMGR_NAMESPACE $POD image-registry.openshift-image-registry.svc nslookup
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if [ $SUCC_CTR -eq $SUCC_LIMIT ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Network connectivity test limit [$SUCC_LIMIT successful attempts] is reached. Exiting..."
					break
				fi
			done

			if [ $SUCC_CTR -eq 0 ]
			then
				echoTestPodNwFail ${CONNECTIVITY_POD_ARRAY[@]}
			fi

			if [ ${#RTVAR_GETALL_SUBSET_DATA} -gt 0 ] && [ ${RTVAR_GETALL_SUBSET_DATA} == "true" ]
			then

				ocGet installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_installation.out $AIMGR_NAMESPACE
				ocDesc installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/installation $AIMGR_NAMESPACE
				ocGet aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_aimanager.out $AIMGR_NAMESPACE
				ocDesc aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/aimanager $AIMGR_NAMESPACE	
				ocGet asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_asmformation.out $AIMGR_NAMESPACE
				ocDesc asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/asmformation $AIMGR_NAMESPACE
				ocGet postgreservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_postgreservices.out $AIMGR_NAMESPACE
				ocDesc postgreservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/postgreservices $AIMGR_NAMESPACE	
				ocGet zenservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_zenservices.out $AIMGR_NAMESPACE
				ocDesc zenservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/zenservices $AIMGR_NAMESPACE	
			fi

			getCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_camel.out
			descCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/camel
			getNginxDump $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/ibm-nginx
		done
	fi

	if [ $WAIOPS_EVTMGR_INSTALLED == "true" ] && [ ${#RTVAR_GETALL_SUBSET_DATA} -gt 0 ] && [ ${RTVAR_GETALL_SUBSET_DATA} == "true" ]
	then
		for EVTMGR_NAMESPACE in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_NAMESPACE]. Skipping..."
				continue
			fi

			ocGet noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noi.out $EVTMGR_NAMESPACE
			ocDesc noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noi $EVTMGR_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noiformation.out $EVTMGR_NAMESPACE
			ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noiformation $EVTMGR_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_cemformation.out $EVTMGR_NAMESPACE
			ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/cemformation $EVTMGR_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_asmformation.out $EVTMGR_NAMESPACE
			ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/asmformation $EVTMGR_NAMESPACE
		done
	fi

	if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ] && [ ${#RTVAR_GETALL_SUBSET_DATA} -gt 0 ] && [ ${RTVAR_GETALL_SUBSET_DATA} == "true" ]
	then
		for EVTMGR_HYBRID_NAMESPACE in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_HYBRID_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_HYBRID_NAMESPACE]. Skipping..."
				continue
			fi

			ocGet noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noihybrid.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noihybrid $EVTMGR_HYBRID_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noiformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noiformation $EVTMGR_HYBRID_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_cemformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/cemformation $EVTMGR_HYBRID_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_asmformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/asmformation $EVTMGR_HYBRID_NAMESPACE
		done
	fi

	if [ $WAIOPS_ICS_INSTALLED == "true" ] && [ ${#RTVAR_GETALL_SUBSET_DATA} -gt 0 ] && [ ${RTVAR_GETALL_SUBSET_DATA} == "true" ]
	then
		if toExcludeProdNamespace $EVTMGR_NAMESPACE
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$AIMGR_NAMESPACE]. Skipping..."
		else
			ocGet ip $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_ip.out ALLNS
			ocDesc ip $PRODUCT_DATA_OUTDIR/ibm-common-services/ip ALLNS
			ocGet commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_commonservice.out ibm-common-services
			ocDesc commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/commonservice ibm-common-services
			ocGet operator $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_operator.out ibm-common-services
			ocDesc operator $PRODUCT_DATA_OUTDIR/ibm-common-services/operator ibm-common-services
		fi

	fi

	if [ ${#RTVAR_DISABLE_ALLNS_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_ALLNS_DATA} == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for non-product namespaces is turned off [RTVAR_DISABLE_ALLNS_DATA = $RTVAR_DISABLE_ALLNS_DATA]!"
	else
		getOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
		analyzeOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out 
	fi

	ocGet pv $CLUSTER_DATA_OUTDIR/oc_pv.out
	ocDesc pv $CLUSTER_DATA_OUTDIR/pv	
	ocGet clusterroles $CLUSTER_DATA_OUTDIR/oc_clusterroles.out
	ocGet clusterrolebindings $CLUSTER_DATA_OUTDIR/oc_clusterrolebindings.out
	ocGet csr $CLUSTER_DATA_OUTDIR/oc_csr.out
	ocDesc csr $CLUSTER_DATA_OUTDIR/csr
	ocGet catalogsource $CLUSTER_DATA_OUTDIR/oc_catalogsource.out ALLNS
	ocDesc catalogsource $CLUSTER_DATA_OUTDIR/catalogsource ALLNS
	ocGet operatorgroup $CLUSTER_DATA_OUTDIR/oc_operatorgroup.out ALLNS
	ocDesc operatorgroup $CLUSTER_DATA_OUTDIR/operatorgroup ALLNS
	ocGet scc $CLUSTER_DATA_OUTDIR/oc_securitycontextconstraints.out
	ocDesc scc $CLUSTER_DATA_OUTDIR/securitycontextconstraints
	ocGet crd $CLUSTER_DATA_OUTDIR/oc_customresourcedefinition.out
	ocDesc crd $CLUSTER_DATA_OUTDIR/customresourcedefinition 
	ocGet priorityclass $CLUSTER_DATA_OUTDIR/oc_priorityclass.out
	ocDesc priorityclass $CLUSTER_DATA_OUTDIR/priorityclass
	ocGet clusteroperators $CLUSTER_DATA_OUTDIR/oc_clusteroperators.out
	ocDesc clusteroperators $CLUSTER_DATA_OUTDIR/clusteroperators
	ocGet namespaces $CLUSTER_DATA_OUTDIR/oc_namespaces.out
	ocDesc namespaces $CLUSTER_DATA_OUTDIR/namespaces
	ocGet ingresscontroller $CLUSTER_DATA_OUTDIR/oc_ingresscontroller.out ALLNS
	ocDesc ingresscontroller $CLUSTER_DATA_OUTDIR/ingresscontroller ALLNS
	ocGet nginxingresses $CLUSTER_DATA_OUTDIR/oc_nginxingresses.out ALLNS
	ocDesc nginxingresses $CLUSTER_DATA_OUTDIR/nginxingresses ALLNS
	ocGet networks.config.openshift.io $CLUSTER_DATA_OUTDIR/oc_networks.out 
	ocDesc networks.config.openshift.io $CLUSTER_DATA_OUTDIR/networks.config.openshift.io
	ocGet machineconfigpools $CLUSTER_DATA_OUTDIR/oc_machineconfigpools.out
	ocDesc machineconfigpools $CLUSTER_DATA_OUTDIR/machineconfigpools
	ocGet apiservices $CLUSTER_DATA_OUTDIR/oc_apiservices.out 
	ocDesc apiservices $CLUSTER_DATA_OUTDIR/apiservices 
	ocGet mutatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/oc_mutatingwebhookconfigurations.out
	ocDesc mutatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/mutatingwebhookconfigurations 
	ocGet validatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/oc_validatingwebhookconfigurations.out
	ocDesc validatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/validatingwebhookconfigurations
	getOcEvent $CLUSTER_DATA_OUTDIR/oc_event.log
	getApiResources $CLUSTER_DATA_OUTDIR/oc_apiresources.out
	getApiVersions $CLUSTER_DATA_OUTDIR/oc_apiversions.out
}

getComprehensive()
{
	getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
	getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
	getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
	getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out
	descNode $CLUSTER_DATA_OUTDIR/nodes
	analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
	ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
	ocDesc storageclass $CLUSTER_DATA_OUTDIR/storageclass
	echoStorageClass
	getEtcd $CLUSTER_DATA_OUTDIR/etcd
	getOcProdStatus
	echoOcProdStatus
	getOcInstallation
	getOcNoi

	local NS=

	for NS in ${WAIOPS_PROD_NAMESPACES[@]}
	do
		echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

		if toExcludeProdNamespace $NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
			continue
		fi

		local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"

		if [ ! -d $NS_OUTDIR ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
			mkdir -p $NS_OUTDIR
		fi

		getOcAdmTopCpuPod $NS $NS_OUTDIR/oc_top_cpu_pod.out
		getOcAdmTopMemPod $NS $NS_OUTDIR/oc_top_mem_pod.out
		ocGet csv $NS_OUTDIR/oc_csv.out $NS
		ocDesc csv $NS_OUTDIR/csv $NS
		echoCsv $NS
		echoSubscription $NS
		getOcAll $NS $NS_OUTDIR/oc_all.out
	
		local EXCL_OBJ_LIST=(subscription.messaging.knative.dev)
		descAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR $EXCL_OBJ_LIST

		if [ ${#RTVAR_DISABLE_PROD_ANALYTICS} -gt 0 ] && [ $RTVAR_DISABLE_PROD_ANALYTICS == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data analytics for product namespaces is turned off [RTVAR_DISABLE_PROD_ANALYTICS = $RTVAR_DISABLE_PROD_ANALYTICS]!"
		else
			analyzeOcAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR 
		fi

		ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
		ocDesc pvc $NS_OUTDIR/pvc $NS
		analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
		ocGet cert $NS_OUTDIR/oc_cert.out $NS
		ocDesc cert $NS_OUTDIR/cert $NS
		analyzeOcCert $NS $NS_OUTDIR/oc_cert.out $NS_OUTDIR/cert
		getOcSecrets $NS $NS_OUTDIR/oc_secrets.out
		descSecrets $NS $NS_OUTDIR/secrets
		ocGet configmap $NS_OUTDIR/oc_configmaps.out $NS
		ocDesc configmap $NS_OUTDIR/configmap $NS
		ocGet serviceaccount $NS_OUTDIR/oc_serviceaccounts.out $NS
		ocDesc serviceaccount $NS_OUTDIR/serviceaccounts $NS
		ocGet operandrequest $NS_OUTDIR/oc_operandrequests.out $NS
		ocDesc operandrequest $NS_OUTDIR/operandrequest $NS
		ocGet operandregistry $NS_OUTDIR/oc_operandregistrys.out $NS
		ocDesc operandregistry $NS_OUTDIR/operandregistry $NS
		ocGet operandconfig $NS_OUTDIR/oc_operandconfigs.out $NS
		ocDesc operandconfig $NS_OUTDIR/operandconfig $NS
		ocGet ingress $NS_OUTDIR/oc_ingress.out $NS
		ocGet endpoints $NS_OUTDIR/oc_endpoints.out $NS
		ocGet networkpolicy $NS_OUTDIR/oc_networkpolicy.out $NS
		ocGet roles $NS_OUTDIR/oc_roles.out $NS
		ocGet rolebindings $NS_OUTDIR/oc_rolebindings.out $NS
		ocGet subscriptions $NS_OUTDIR/oc_subscriptions.out $NS
		ocDesc subscriptions $NS_OUTDIR/subscriptions $NS
		ocGet poddisruptionbudgets $NS_OUTDIR/oc_poddisruptionbudgets.out $NS
		ocGet certificaterequests $NS_OUTDIR/oc_certificaterequests.out $NS
		ocDesc certificaterequests $NS_OUTDIR/certificaterequests $NS
		ocGet installplans $NS_OUTDIR/oc_installplans.out $NS
		ocDesc installplans $NS_OUTDIR/installplans $NS

		if [ ${#OPENSSL} -gt 0 ] && [ $IS_SENSITIVE_DATA_ALLOWED == "true" ]
		then
			get_cert_from_routes $NS $NS_OUTDIR
		fi
	done

	if [ $WAIOPS_AIMGR_INSTALLED == "true" ]
	then
		getMetricsData

		for AIMGR_NAMESPACE in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $AIMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$AIMGR_NAMESPACE]. Skipping..."
				continue
			fi

			echo "[$(date)] [${FUNCNAME[0]}] Collecting data for AI Manager namespace [$AIMGR_NAMESPACE]..."

			echoTestPodNw $AIMGR_NAMESPACE
			local CONNECTIVITY_POD_ARRAY=(aimanager-aio-controller strimzi-cluster-zookeeper aimanager-aio-chatops-slack-integrator modeltrain-ibm-modeltrain-ratelimiter)
			local SUCC_CTR=0
			local SUCC_LIMIT=4
		
			for POD in ${CONNECTIVITY_POD_ARRAY[@]}
			do
				if testPodNw $AIMGR_NAMESPACE $POD cp.icr.io ping
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if testPodNw $AIMGR_NAMESPACE $POD image-registry.openshift-image-registry.svc nslookup
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if [ $SUCC_CTR -eq $SUCC_LIMIT ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Network connectivity test limit [$SUCC_LIMIT successful attempts] is reached. Exiting..."
					break
				fi
			done

			if [ $SUCC_CTR -eq 0 ]
			then
				echoTestPodNwFail ${CONNECTIVITY_POD_ARRAY[@]}
			fi

			ocGet installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_installation.out $AIMGR_NAMESPACE
			ocDesc installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/installation $AIMGR_NAMESPACE
			ocGet aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_aimanager.out $AIMGR_NAMESPACE
			ocDesc aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/aimanager $AIMGR_NAMESPACE	
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_asmformation.out $AIMGR_NAMESPACE
			ocDesc asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/asmformation $AIMGR_NAMESPACE
			ocGet zenservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_zenservices.out $AIMGR_NAMESPACE
			ocDesc zenservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/zenservices $AIMGR_NAMESPACE	
			getCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_camel.out
			descCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/camel
			getNginxDump $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/ibm-nginx
		done
	fi

	if [ $WAIOPS_EVTMGR_INSTALLED == "true" ]
	then
		for EVTMGR_NAMESPACE in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_NAMESPACE]. Skipping..."
				continue
			fi

			echo "[$(date)] [${FUNCNAME[0]}] Collecting data for Event Manager namespace [$EVTMGR_NAMESPACE]..."

			ocGet noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noi.out $EVTMGR_NAMESPACE
			ocDesc noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noi $EVTMGR_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noiformation.out $EVTMGR_NAMESPACE
			ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noiformation $EVTMGR_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_cemformation.out $EVTMGR_NAMESPACE
			ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/cemformation $EVTMGR_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_asmformation.out $EVTMGR_NAMESPACE
			ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/asmformation $EVTMGR_NAMESPACE
		done
	fi
	
	if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
	then
		for EVTMGR_HYBRID_NAMESPACE in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_HYBRID_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_HYBRID_NAMESPACE]. Skipping..."
				continue
			fi

			echo "[$(date)] [${FUNCNAME[0]}] Collecting data for Event Manager Hybrid namespace [$EVTMGR_HYBRID_NAMESPACE]..."

			echo "[$(date)] [${FUNCNAME[0]}] Collecting data for Event Manager namespace [$EVTMGR_NAMESPACE]..."
			ocGet noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noihybrid.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noihybrid $EVTMGR_HYBRID_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noiformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noiformation $EVTMGR_HYBRID_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_cemformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/cemformation $EVTMGR_HYBRID_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_asmformation.out $EVTMGR_HYBRID_NAMESPACE
			ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/asmformation $EVTMGR_HYBRID_NAMESPACE
		done
	fi
	
	if [ $WAIOPS_ICS_INSTALLED == "true" ]
	then
		if toExcludeProdNamespace ibm-common-services
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [ibm-common-services]. Skipping..."
		else
			ocGet ip $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_ip.out ALLNS
			ocDesc ip $PRODUCT_DATA_OUTDIR/ibm-common-services/ip ALLNS
			ocGet commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_commonservice.out ibm-common-services
			ocDesc commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/commonservice ibm-common-services
			ocGet operator $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_operator.out ibm-common-services
			ocDesc operator $PRODUCT_DATA_OUTDIR/ibm-common-services/operator ibm-common-services
		fi
	fi

	if [ ${#RTVAR_DISABLE_ALLNS_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_ALLNS_DATA} == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for non-product namespaces is turned off [RTVAR_DISABLE_ALLNS_DATA = $RTVAR_DISABLE_ALLNS_DATA]!"
	else
		getOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
		analyzeOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out 
	fi

	ocGet pv $CLUSTER_DATA_OUTDIR/oc_pv.out
	ocDesc pv $CLUSTER_DATA_OUTDIR/pv	
	ocGet clusterroles $CLUSTER_DATA_OUTDIR/oc_clusterroles.out
	ocGet clusterrolebindings $CLUSTER_DATA_OUTDIR/oc_clusterrolebindings.out
	ocGet csr $CLUSTER_DATA_OUTDIR/oc_csr.out
	ocGet catalogsource $CLUSTER_DATA_OUTDIR/oc_catalogsource.out ALLNS
	ocDesc catalogsource $CLUSTER_DATA_OUTDIR/catalogsource ALLNS
	ocGet operatorgroup $CLUSTER_DATA_OUTDIR/oc_operatorgroup.out ALLNS
	ocDesc operatorgroup $CLUSTER_DATA_OUTDIR/operatorgroup ALLNS
	ocGet scc $CLUSTER_DATA_OUTDIR/oc_securitycontextconstraints.out
	ocDesc scc $CLUSTER_DATA_OUTDIR/securitycontextconstraints
	ocGet crd $CLUSTER_DATA_OUTDIR/oc_customresourcedefinition.out
	ocDesc crd $CLUSTER_DATA_OUTDIR/customresourcedefinition 
	ocGet priorityclass $CLUSTER_DATA_OUTDIR/oc_priorityclass.out
	ocGet clusteroperators $CLUSTER_DATA_OUTDIR/oc_clusteroperators.out
	ocGet namespaces $CLUSTER_DATA_OUTDIR/oc_namespaces.out
	ocGet machineconfigpools $CLUSTER_DATA_OUTDIR/oc_machineconfigpools.out
	ocGet apiservices $CLUSTER_DATA_OUTDIR/oc_apiservices.out 
	getOcEvent $CLUSTER_DATA_OUTDIR/oc_event.log
	getApiResources $CLUSTER_DATA_OUTDIR/oc_apiresources.out
	getApiVersions $CLUSTER_DATA_OUTDIR/oc_apiversions.out
}

getBasic()
{
	getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
	getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
	getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
	getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out
	descNode $CLUSTER_DATA_OUTDIR/nodes
	analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
	ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
	ocDesc storageclass $CLUSTER_DATA_OUTDIR/storageclass
	echoStorageClass
	getOcProdStatus
	echoOcProdStatus
	getOcInstallation
	getOcNoi

	local NS=
	
	for NS in ${WAIOPS_PROD_NAMESPACES[@]}
	do
		echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

		if toExcludeProdNamespace $NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
			continue
		fi

		local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"

		if [ ! -d $NS_OUTDIR ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
			mkdir -p $NS_OUTDIR
		fi

		ocGet csv $NS_OUTDIR/oc_csv.out $NS
		ocDesc csv $NS_OUTDIR/csv $NS
		echoCsv $NS
		getOcAll $NS $NS_OUTDIR/oc_all.out
	
		local EXCL_OBJ_LIST=(horizontalpodautoscaler.autoscaling buildconfig.build.openshift.io build.build.openshift.io imagestream.image.openshift.io channel.messaging.knative.dev inmemorychannel.messaging.knative.dev subscription.messaging.knative.dev service.serving.knative.dev revision.serving.knative.dev configuration.serving.knative.dev route.serving.knative.dev)
		descAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR $EXCL_OBJ_LIST

		if [ ${#RTVAR_DISABLE_PROD_ANALYTICS} -gt 0 ] && [ $RTVAR_DISABLE_PROD_ANALYTICS == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data analytics for product namespaces is turned off [RTVAR_DISABLE_PROD_ANALYTICS = $RTVAR_DISABLE_PROD_ANALYTICS]!"
		else
			analyzeOcAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR 
		fi

		ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
		ocDesc pvc $NS_OUTDIR/pvc $NS
		analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
		getOcSecrets $NS $NS_OUTDIR/oc_secrets.out
		descSecrets $NS $NS_OUTDIR/secrets
		ocGet configmap $NS_OUTDIR/oc_configmaps.out $NS
		ocDesc configmap $NS_OUTDIR/configmap $NS
	done

	if [ $WAIOPS_AIMGR_INSTALLED == "true" ]
	then
		getMetricsData

		for AIMGR_NAMESPACE in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $AIMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$AIMGR_NAMESPACE]. Skipping..."
				continue
			fi

			echoTestPodNw $AIMGR_NAMESPACE
			local CONNECTIVITY_POD_ARRAY=(aimanager-aio-controller strimzi-cluster-zookeeper aimanager-aio-chatops-slack-integrator modeltrain-ibm-modeltrain-ratelimiter)
			local SUCC_CTR=0
			local SUCC_LIMIT=4
		
			for POD in ${CONNECTIVITY_POD_ARRAY[@]}
			do
				if testPodNw $AIMGR_NAMESPACE $POD cp.icr.io ping
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if testPodNw $AIMGR_NAMESPACE $POD image-registry.openshift-image-registry.svc nslookup
				then
					(( SUCC_CTR=SUCC_CTR+1 ))	
				fi

				if [ $SUCC_CTR -eq $SUCC_LIMIT ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Network connectivity test limit [$SUCC_LIMIT successful attempts] is reached. Exiting..."
					break
				fi
			done

			if [ $SUCC_CTR -eq 0 ]
			then
				echoTestPodNwFail ${CONNECTIVITY_POD_ARRAY[@]}
			fi

			ocGet installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_installation.out $AIMGR_NAMESPACE
			ocGet aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_aimanager.out $AIMGR_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_asmformation.out $AIMGR_NAMESPACE
			ocGet zenservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_zenservices.out $AIMGR_NAMESPACE
			getCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_camel.out
		done
	fi

	if [ $WAIOPS_EVTMGR_INSTALLED == "true" ]
	then
		for EVTMGR_NAMESPACE in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_NAMESPACE]. Skipping..."
				continue
			fi

			ocGet noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noi.out $EVTMGR_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noiformation.out $EVTMGR_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_cemformation.out $EVTMGR_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_asmformation.out $EVTMGR_NAMESPACE
		done
	fi
	
	if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
	then
		for EVTMGR_HYBRID_NAMESPACE in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
		do
			if toExcludeProdNamespace $EVTMGR_HYBRID_NAMESPACE
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$EVTMGR_HYBRID_NAMESPACE]. Skipping..."
				continue
			fi

			ocGet noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noihybrid.out $EVTMGR_HYBRID_NAMESPACE
			ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noiformation.out $EVTMGR_HYBRID_NAMESPACE
			ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_cemformation.out $EVTMGR_HYBRID_NAMESPACE
			ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_asmformation.out $EVTMGR_HYBRID_NAMESPACE
		done
	fi
	
	if [ $WAIOPS_ICS_INSTALLED == "true" ]
	then
		if toExcludeProdNamespace ibm-common-services
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [ibm-common-services]. Skipping..."
		else
			ocGet ip $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_ip.out ALLNS
			ocGet commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_commonservice.out ibm-common-services
			ocGet operator $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_operator.out ibm-common-services
		fi
	fi

	if [ ${#RTVAR_DISABLE_ALLNS_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_ALLNS_DATA} == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for non-product namespaces is turned off [RTVAR_DISABLE_ALLNS_DATA = $RTVAR_DISABLE_ALLNS_DATA]!"
	else
		getOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
		analyzeOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
	fi

	ocGet pv $CLUSTER_DATA_OUTDIR/oc_pv.out
	ocDesc pv $CLUSTER_DATA_OUTDIR/pv	
	ocGet namespaces $CLUSTER_DATA_OUTDIR/oc_namespaces.out
	ocGet apiservices $CLUSTER_DATA_OUTDIR/oc_apiservices.out 
	getOcEvent $CLUSTER_DATA_OUTDIR/oc_event.log
}

getLimited()
{
	if [ $COLL_PREV_LOGS == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] INFO: Data collection mode [limited] is selected. No pod logs will be collected. User input COLL_PREV_LOGS [-p] will be ignored!"	
		COLL_PREV_LOGS="false"
	fi

	if [ $COLLECT_YAML == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] INFO: Data collection mode [limited] is selected. Collection of YAML output is not supported. User input COLL_YAML [-y] will be ignored!"	
		COLLECT_YAML="false"
	fi

	getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
	getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
	getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
	getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out

	if [ $GET_NODES_DATA == "true" ] || [ $REPORT_ON_SCREEN == "true" ]
	then
		descNode $CLUSTER_DATA_OUTDIR/nodes
	fi

	analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out

	ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
	echoStorageClass
	getOcProdStatus
	echoOcProdStatus
	getOcInstallation
	getOcNoi

	local NS=
	
	for NS in ${WAIOPS_PROD_NAMESPACES[@]}
	do
		echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

		if toExcludeProdNamespace $NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
			continue
		fi

		local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"

		if [ ! -d $NS_OUTDIR ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
			mkdir -p $NS_OUTDIR
		fi

		ocGet csv $NS_OUTDIR/oc_csv.out $NS
		echoCsv $NS
		getOcAll $NS $NS_OUTDIR/oc_all.out
		ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
		analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
		getOcSecrets $NS $NS_OUTDIR/oc_secrets.out
		ocGet configmap $NS_OUTDIR/oc_configmaps.out $NS
	done

	if [ ${#RTVAR_DISABLE_ALLNS_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_ALLNS_DATA} == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for non-product namespaces is turned off [RTVAR_DISABLE_ALLNS_DATA = $RTVAR_DISABLE_ALLNS_DATA]!"
	else
		getOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
	fi

	ocGet pv $CLUSTER_DATA_OUTDIR/oc_pv.out
	ocGet namespaces $CLUSTER_DATA_OUTDIR/oc_namespaces.out
	getOcEvent $CLUSTER_DATA_OUTDIR/oc_event.log
}

getSelective()
{
	if [ ${#RTVAR_SELECTIVE_EXTRA_DATA} -gt 0 ] && [ $RTVAR_SELECTIVE_EXTRA_DATA == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] RTVAR_SELECTIVE_EXTRA_DATA [$RTVAR_SELECTIVE_EXTRA_DATA] - Setting RTVAR_SELECTIVE_GENERAL_DATA to [true] and RTVAR_DISABLE_PROD_ANALYTICS to [false]!"
		RTVAR_SELECTIVE_GENERAL_DATA="true"
		RTVAR_DISABLE_PROD_ANALYTICS="false"
	fi

	if [ ${#RTVAR_SELECTIVE_GENERAL_DATA} -gt 0 ] && [ $RTVAR_SELECTIVE_GENERAL_DATA == "true" ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] General data collection is turned on [RTVAR_SELECTIVE_GENERAL_DATA = $RTVAR_SELECTIVE_GENERAL_DATA]!"

		getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
		getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
		getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
		getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out
		descNode $CLUSTER_DATA_OUTDIR/nodes
		analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
		ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
		ocDesc storageclass $CLUSTER_DATA_OUTDIR/storageclass
		echoStorageClass
		getOcProdStatus
		echoOcProdStatus
	fi

	local NS=
	
	if ( [ ${#RTVAR_SELECTIVE_GENERAL_DATA} -gt 0 ] && [ $RTVAR_SELECTIVE_GENERAL_DATA == "true" ] ) || ( [ ${#RTVAR_DISABLE_PROD_ANALYTICS} -gt 0 ] && [ $RTVAR_DISABLE_PROD_ANALYTICS == "false" ] )
	then
		for NS in ${WAIOPS_PROD_NAMESPACES[@]}
		do
			echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"
	
			if toExcludeProdNamespace $NS
			then
				echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
				continue
			fi
	
			local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"
	
			if [ ${#RTVAR_SELECTIVE_GENERAL_DATA} -gt 0 ] && [ $RTVAR_SELECTIVE_GENERAL_DATA == "true" ]
			then
				ocGet csv $NS_OUTDIR/oc_csv.out $NS
				ocDesc csv $NS_OUTDIR/csv $NS
				echoCsv $NS
			fi
	
			if [ ${#RTVAR_DISABLE_PROD_ANALYTICS} -gt 0 ] && [ $RTVAR_DISABLE_PROD_ANALYTICS == "false" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Data analytics for product namespaces is turned on [RTVAR_DISABLE_PROD_ANALYTICS = $RTVAR_DISABLE_PROD_ANALYTICS]!"
				echo "[$(date)] [${FUNCNAME[0]}] Analyzing status of basic resources of product namespace [$NS]..."
				analyzeOcAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR 
			fi
		done
	fi

	if [[ "$SELECTIVE_RESOURCES" =~ ^\/ ]]
	then
		# If SELECTIVE_RESOURCES starts with forward slash(/), it is assumed it is a configuration file
		if [ -s $SELECTIVE_RESOURCES ]
		then
			local SELECTIVE_CMD="cat $SELECTIVE_RESOURCES | grep -v '^[ ]*#' | grep -v '^[ ]*$' | sort | uniq"
		else
			echo "[$(date)] [${FUNCNAME[0]}] SELECTIVE_RESOURCES [$SELECTIVE_RESOURCES] does not exist or is zero-sized! Returning..."
			return 1
		fi
	else
		local SELECTIVE_CMD="echo $SELECTIVE_RESOURCES | $AWK '{ print tolower(\$0) }' | sed 's/,/\n/g' | sort | uniq"
	fi

	echo "[$(date)] [${FUNCNAME[0]}] SELECTIVE_CMD = [$SELECTIVE_CMD]"

	for RES in $(eval "$SELECTIVE_CMD")
	do
		local RESOURCE=$(echo "$RES" | $AWK -F/ '{ print tolower($1) }')
		local SCOPE=$(echo "$RES" | $AWK -F/ '{ print tolower($2) }')

		local IS_NAMESPACED
		IS_NAMESPACED=$(isNamespaced "$RESOURCE")
		SELECTIVE_EXITCODE=$?

		if [ ${#SCOPE} -eq 0 ]
		then
			if [ $SELECTIVE_EXITCODE -eq 0 ]
			then
				if [ $IS_NAMESPACED -eq 0 ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] / SCOPE = [${WAIOPS_PROD_NAMESPACES[@]}]"
				else
					echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] / SCOPE = [cluster]"
				fi
			else
				echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE]"
			fi
		else
			if [ $SCOPE == "allns" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] / SCOPE = [$SCOPE]"
			else
				echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] / SCOPE = [$SCOPE] (invalid/ignored)"
				SCOPE=""

				if [ $IS_NAMESPACED -eq 0 ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] Setting SCOPE to product namespaces [${WAIOPS_PROD_NAMESPACES[@]}]"
				else
					echo "[$(date)] [${FUNCNAME[0]}] RESOURCE = [$RESOURCE] Setting SCOPE to cluster [cluster]"
				fi
			fi
		fi

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] RESOURCE [$RESOURCE] = IS_NAMESPACED[$IS_NAMESPACED] / EXIT_STATUS[$SELECTIVE_EXITCODE]"	
		fi

		if [ $SELECTIVE_EXITCODE -eq 0 ]
		then
			if [ $IS_NAMESPACED -eq 0 ]
			then
				if [ ${#SCOPE} -gt 0 ] && [ $SCOPE == "allns" ]
				then
					if ! checkUserPriv get,list $RESOURCE all
					then
						echo "[$(date)] [${FUNCNAME[0]}] User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [$RESOURCE] on cluster level. Skipping..."	
						continue	
					fi

					local NS_OUTDIR="$CLUSTER_DATA_OUTDIR"
			
					if [ ! -d $NS_OUTDIR ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
						mkdir -p $NS_OUTDIR
					fi
				
					ocGet $RESOURCE $NS_OUTDIR/oc_${RESOURCE}.out ALLNS
					ocDesc $RESOURCE $NS_OUTDIR/$RESOURCE ALLNS
				else
					for NS in ${WAIOPS_PROD_NAMESPACES[@]}
					do
						echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

						if toExcludeProdNamespace $NS
						then
							echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
							continue
						fi

						if ! checkUserPriv get,list $RESOURCE $NS
						then
							echo "[$(date)] [${FUNCNAME[0]}] User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [$RESOURCE] in namespace [$NS]. Skipping..."	
							continue	
						fi

						local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"
				
						if [ ! -d $NS_OUTDIR ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
							mkdir -p $NS_OUTDIR
						fi
				
						ocGet $RESOURCE $NS_OUTDIR/oc_${RESOURCE}.out $NS
						ocDesc $RESOURCE $NS_OUTDIR/$RESOURCE $NS
	
						if [ $RESOURCE == "pvc" ] || [ $RESOURCE == "persistentvolumeclaim" ] || [ $RESOURCE == "persistentvolumeclaims" ]
						then
							analyzeOcPvc $NS $NS_OUTDIR/oc_${RESOURCE}.out $NS_OUTDIR/${RESOURCE}
						fi
					done
				fi
			else
				local NS_OUTDIR="$CLUSTER_DATA_OUTDIR"

				if [ ! -d $NS_OUTDIR ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
					mkdir -p $NS_OUTDIR
				fi

				ocGet $RESOURCE $NS_OUTDIR/oc_${RESOURCE}.out 
				ocDesc $RESOURCE $NS_OUTDIR/$RESOURCE
			fi
		else
			if [ $SELECTIVE_EXITCODE -eq 2 ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] File RES_LIST_PROCFILE [$RES_LIST_PROCFILE] does not exist or is zero-sized! Skipping..."
			else
				echo "[$(date)] [${FUNCNAME[0]}] Unable to determine whether resource [$RESOURCE] is namespaced. Skipping..."	
			fi
		fi
	done
}

getModules()
{
	for MODULE in $(echo "$CLEAN_MODULES" | sed 's/,/\n/g' | sort | uniq)
	do
		echo "[$(date)] [${FUNCNAME[0]}] Executing data collection on module [$MODULE]..."

		case "$MODULE" in
			clusterinfo)
				getOcVersion $CLUSTER_DATA_OUTDIR/oc_version.out
				getOcWhoAmI $CLUSTER_DATA_OUTDIR/oc_whoami.out
				getOcAdmTopNode $CLUSTER_DATA_OUTDIR/oc_top_node.out
				getOcNode $CLUSTER_DATA_OUTDIR/oc_node.out
				descNode $CLUSTER_DATA_OUTDIR/nodes
				analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
				getEtcd $CLUSTER_DATA_OUTDIR/etcd
				getOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
				analyzeOcAllNS $CLUSTER_DATA_OUTDIR/oc_all_namespaces.out
				ocGet clusterroles $CLUSTER_DATA_OUTDIR/oc_clusterroles.out
				ocGet clusterrolebindings $CLUSTER_DATA_OUTDIR/oc_clusterrolebindings.out
				ocGet csr $CLUSTER_DATA_OUTDIR/oc_csr.out
				ocDesc csr $CLUSTER_DATA_OUTDIR/csr
				ocGet catalogsource $CLUSTER_DATA_OUTDIR/oc_catalogsource.out ALLNS
				ocDesc catalogsource $CLUSTER_DATA_OUTDIR/catalogsource ALLNS
				ocGet operatorgroup $CLUSTER_DATA_OUTDIR/oc_operatorgroup.out ALLNS
				ocDesc operatorgroup $CLUSTER_DATA_OUTDIR/operatorgroup ALLNS
				ocGet scc $CLUSTER_DATA_OUTDIR/oc_securitycontextconstraints.out
				ocDesc scc $CLUSTER_DATA_OUTDIR/securitycontextconstraints
				ocGet crd $CLUSTER_DATA_OUTDIR/oc_customresourcedefinition.out
				ocDesc crd $CLUSTER_DATA_OUTDIR/customresourcedefinition 
				ocGet priorityclass $CLUSTER_DATA_OUTDIR/oc_priorityclass.out
				ocDesc priorityclass $CLUSTER_DATA_OUTDIR/priorityclass
				ocGet clusteroperators $CLUSTER_DATA_OUTDIR/oc_clusteroperators.out
				ocDesc clusteroperators $CLUSTER_DATA_OUTDIR/clusteroperators
				ocGet namespaces $CLUSTER_DATA_OUTDIR/oc_namespaces.out
				ocDesc namespaces $CLUSTER_DATA_OUTDIR/namespaces
				ocGet machineconfigpools $CLUSTER_DATA_OUTDIR/oc_machineconfigpools.out
				ocDesc machineconfigpools $CLUSTER_DATA_OUTDIR/machineconfigpools
				ocGet apiservices $CLUSTER_DATA_OUTDIR/oc_apiservices.out 
				ocDesc apiservices $CLUSTER_DATA_OUTDIR/apiservices 
				ocGet mutatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/oc_mutatingwebhookconfigurations.out
				ocDesc mutatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/mutatingwebhookconfigurations 
				ocGet validatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/oc_validatingwebhookconfigurations.out
				ocDesc validatingwebhookconfigurations $CLUSTER_DATA_OUTDIR/validatingwebhookconfigurations
				getOcEvent $CLUSTER_DATA_OUTDIR/oc_event.log
				getApiResources $CLUSTER_DATA_OUTDIR/oc_apiresources.out
				getApiVersions $CLUSTER_DATA_OUTDIR/oc_apiversions.out
				;;

			productinfo)
				getOcProdStatus
				echoOcProdStatus
				getOcInstallation
				getOcNoi

				local NS=
	
				for NS in ${WAIOPS_PROD_NAMESPACES[@]}
				do
					echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

					if toExcludeProdNamespace $NS
					then
						echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
						continue
					fi

					local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"
			
					if [ ! -d $NS_OUTDIR ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
						mkdir -p $NS_OUTDIR
					fi
			
					getOcAdmTopCpuPod $NS $NS_OUTDIR/oc_top_cpu_pod.out
					getOcAdmTopMemPod $NS $NS_OUTDIR/oc_top_mem_pod.out
					ocGet csv $NS_OUTDIR/oc_csv.out $NS
					ocDesc csv $NS_OUTDIR/csv $NS
					echoCsv $NS
					getOcAll $NS $NS_OUTDIR/oc_all.out
				
					local EXCL_OBJ_LIST=(subscription.messaging.knative.dev)
			
					descAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR $EXCL_OBJ_LIST
					analyzeOcAll $NS $NS_OUTDIR/oc_all.out $NS_OUTDIR 
					ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
					ocDesc pvc $NS_OUTDIR/pvc $NS
					analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
					ocGet cert $NS_OUTDIR/oc_cert.out $NS
					ocDesc cert $NS_OUTDIR/cert $NS
					analyzeOcCert $NS $NS_OUTDIR/oc_cert.out $NS_OUTDIR/cert
					getOcSecrets $NS $NS_OUTDIR/oc_secrets.out
					descSecrets $NS $NS_OUTDIR/secrets
					ocGet configmap $NS_OUTDIR/oc_configmaps.out $NS
					ocDesc configmap $NS_OUTDIR/configmap $NS
					ocGet serviceaccount $NS_OUTDIR/oc_serviceaccounts.out $NS
					ocDesc serviceaccount $NS_OUTDIR/serviceaccounts $NS
					ocGet operandrequest $NS_OUTDIR/oc_operandrequests.out $NS
					ocDesc operandrequest $NS_OUTDIR/operandrequests $NS
					ocGet operandregistry $NS_OUTDIR/oc_operandrequests.out $NS
					ocDesc operandregistry $NS_OUTDIR/operandrequests $NS
					ocGet operandconfig $NS_OUTDIR/oc_operandrequests.out $NS
					ocDesc operandconfig $NS_OUTDIR/operandrequests $NS
					ocGet networkpolicy $NS_OUTDIR/oc_networkpolicy.out $NS
					ocDesc networkpolicy $NS_OUTDIR/networkpolicy $NS
					ocGet roles $NS_OUTDIR/oc_roles.out $NS
					ocDesc roles $NS_OUTDIR/roles $NS
					ocGet rolebindings $NS_OUTDIR/oc_rolebindings.out $NS
					ocDesc rolebindings $NS_OUTDIR/rolebindings $NS
					ocGet subscriptions $NS_OUTDIR/oc_subscriptions.out $NS
					ocDesc subscriptions $NS_OUTDIR/subscriptions $NS
					ocGet poddisruptionbudgets $NS_OUTDIR/oc_poddisruptionbudgets.out $NS
					ocDesc poddisruptionbudgets $NS_OUTDIR/poddisruptionbudgets $NS
					ocGet certificaterequests $NS_OUTDIR/oc_certificaterequests.out $NS
					ocDesc certificaterequests $NS_OUTDIR/certificaterequests $NS
					ocGet zenservices $NS_OUTDIR/oc_zenservices.out $NS
					ocDesc zenservices $NS_OUTDIR/zenservices $NS
				done
			
				if [ $WAIOPS_AIMGR_INSTALLED == "true" ]
				then
					for AIMGR_NAMESPACE in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
					do
						echoTestPodNw $AIMGR_NAMESPACE
						local CONNECTIVITY_POD_ARRAY=(aimanager-aio-controller strimzi-cluster-zookeeper aimanager-aio-chatops-slack-integrator modeltrain-ibm-modeltrain-ratelimiter)
						local SUCC_CTR=0
						local SUCC_LIMIT=4
					
						for POD in ${CONNECTIVITY_POD_ARRAY[@]}
						do
							if testPodNw $AIMGR_NAMESPACE $POD cp.icr.io ping
							then
								(( SUCC_CTR=SUCC_CTR+1 ))	
							fi
			
							if testPodNw $AIMGR_NAMESPACE $POD image-registry.openshift-image-registry.svc nslookup
							then
								(( SUCC_CTR=SUCC_CTR+1 ))	
							fi
			
							if [ $SUCC_CTR -eq $SUCC_LIMIT ]
							then
								echo "[$(date)] [${FUNCNAME[0]}] Network connectivity test limit [$SUCC_LIMIT successful attempts] is reached. Exiting..."
								break
							fi
						done
			
						if [ $SUCC_CTR -eq 0 ]
						then
							echoTestPodNwFail ${CONNECTIVITY_POD_ARRAY[@]}
						fi
			
						ocGet installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_installation.out $AIMGR_NAMESPACE
						ocDesc installations.orchestrator.aiops.ibm.com $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/installation $AIMGR_NAMESPACE
						ocGet aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_aimanager.out $AIMGR_NAMESPACE
						ocDesc aimanager $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/aimanager $AIMGR_NAMESPACE	
						ocGet asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_asmformation.out $AIMGR_NAMESPACE
						ocDesc asmformation $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/asmformation $AIMGR_NAMESPACE
						getCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_camel.out
						descCamelInfo $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/camel
						ocGet postgreservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/oc_postgreservices.out $AIMGR_NAMESPACE
						ocDesc postgreservices $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/postgreservices $AIMGR_NAMESPACE	
						getNginxDump $AIMGR_NAMESPACE $PRODUCT_DATA_OUTDIR/$AIMGR_NAMESPACE/ibm-nginx
					done
				fi
			
				if [ $WAIOPS_EVTMGR_INSTALLED == "true" ]
				then
					for EVTMGR_NAMESPACE in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
					do
						ocGet noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noi.out $EVTMGR_NAMESPACE
						ocDesc noi $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noi $EVTMGR_NAMESPACE
						ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_noiformation.out $EVTMGR_NAMESPACE
						ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/noiformation $EVTMGR_NAMESPACE
						ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_cemformation.out $EVTMGR_NAMESPACE
						ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/cemformation $EVTMGR_NAMESPACE
						ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/oc_asmformation.out $EVTMGR_NAMESPACE
						ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_NAMESPACE/asmformation $EVTMGR_NAMESPACE
					done
				fi
			
				if [ $WAIOPS_EVTMGR_HYBRID_INSTALLED == "true" ]
				then
					for EVTMGR_HYBRID_NAMESPACE in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
					do
						ocGet noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noihybrid.out $EVTMGR_HYBRID_NAMESPACE
						ocDesc noihybrid $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noihybrid $EVTMGR_HYBRID_NAMESPACE
						ocGet noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_noiformation.out $EVTMGR_HYBRID_NAMESPACE
						ocDesc noiformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/noiformation $EVTMGR_HYBRID_NAMESPACE
						ocGet cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_cemformation.out $EVTMGR_HYBRID_NAMESPACE
						ocDesc cemformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/cemformation $EVTMGR_HYBRID_NAMESPACE
						ocGet asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/oc_asmformation.out $EVTMGR_HYBRID_NAMESPACE
						ocDesc asmformation $PRODUCT_DATA_OUTDIR/$EVTMGR_HYBRID_NAMESPACE/asmformation $EVTMGR_HYBRID_NAMESPACE
					done
				fi

				if [ $WAIOPS_ICS_INSTALLED == "true" ]
				then
					ocGet apiservices $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_apiservices.out 
					ocDesc apiservices $PRODUCT_DATA_OUTDIR/ibm-common-services/apiservices 
					ocGet ip $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_ip.out ALLNS
					ocDesc ip $PRODUCT_DATA_OUTDIR/ibm-common-services/ip ALLNS
					ocGet commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_commonservice.out ibm-common-services
					ocDesc commonservice $PRODUCT_DATA_OUTDIR/ibm-common-services/commonservice ibm-common-services
					ocGet operator $PRODUCT_DATA_OUTDIR/ibm-common-services/oc_operator.out ibm-common-services
					ocDesc operator $PRODUCT_DATA_OUTDIR/ibm-common-services/operator ibm-common-services
				fi
				;;

			storage)
				ocGet pvc $CLUSTER_DATA_OUTDIR/oc_pvc.out ALLNS
				ocDesc pvc $CLUSTER_DATA_OUTDIR/pvc ALLNS

				for NS in ${WAIOPS_PROD_NAMESPACES[@]}
				do
					echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

					if toExcludeProdNamespace $NS
					then
						echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
						continue
					fi

					local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"
			
					if [ ! -d $NS_OUTDIR ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
						mkdir -p $NS_OUTDIR
					fi
			
					ocGet pvc $NS_OUTDIR/oc_pvc.out $NS
					analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
				done

				ocGet pv $CLUSTER_DATA_OUTDIR/oc_pv.out 
				ocDesc pv $CLUSTER_DATA_OUTDIR/pv	
				ocGet storageclass $CLUSTER_DATA_OUTDIR/oc_storageclass.out
				ocDesc storageclass $CLUSTER_DATA_OUTDIR/storageclass
				echoStorageClass
				;;	
	
			networking)
				ocGet services $CLUSTER_DATA_OUTDIR/oc_services.out ALLNS
				ocDesc services $CLUSTER_DATA_OUTDIR/services ALLNS
				ocGet endpoints $CLUSTER_DATA_OUTDIR/oc_endpoints.out ALLNS
				ocDesc endpoints $CLUSTER_DATA_OUTDIR/endpoints ALLNS
				ocGet route $CLUSTER_DATA_OUTDIR/oc_route.out ALLNS
				ocDesc route $CLUSTER_DATA_OUTDIR/route ALLNS
				ocGet ingress $CLUSTER_DATA_OUTDIR/oc_ingress.out ALLNS
				ocDesc ingress $CLUSTER_DATA_OUTDIR/ingress ALLNS
				ocGet ingresscontroller $CLUSTER_DATA_OUTDIR/oc_ingresscontroller.out ALLNS
				ocDesc ingresscontroller $CLUSTER_DATA_OUTDIR/ingresscontroller ALLNS
				ocGet networkpolicy $CLUSTER_DATA_OUTDIR/oc_networkpolicy.out ALLNS
				ocDesc networkpolicy $CLUSTER_DATA_OUTDIR/networkpolicy ALLNS
				ocGet nginxingresses $CLUSTER_DATA_OUTDIR/oc_nginxingresses.out ALLNS
				ocDesc nginxingresses $CLUSTER_DATA_OUTDIR/nginxingresses ALLNS
				ocGet networks.config.openshift.io $CLUSTER_DATA_OUTDIR/oc_networks.out 
				ocDesc networks.config.openshift.io $CLUSTER_DATA_OUTDIR/networks.config.openshift.io
				;;

			installation)
				getOcInstallation
				getOcNoi
				;;
			csv)
				for NS in ${WAIOPS_PROD_NAMESPACES[@]}
				do
					echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

					if toExcludeProdNamespace $NS
					then
						echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
						continue
					fi

					echoCsv $NS
				done
				;;
			pvcusage)
				if [ ${#RTVAR_ADD_PVC_NS} -gt 0 ]
				then
					local PVC_NS_ARR=("${WAIOPS_PROD_NAMESPACES[@]}" $(echo "$RTVAR_ADD_PVC_NS" | sed 's/,/ /g'))
				else
					local PVC_NS_ARR=(${WAIOPS_PROD_NAMESPACES[@]})
				fi			

				echo "[$(date)] [${FUNCNAME[0]}] Namespaces to process = [${PVC_NS_ARR[@]}]"

				IFS=$OLDIFS
	
				for NS in ${PVC_NS_ARR[@]}
				do
					echo "[$(date)] [${FUNCNAME[0]}] CURRENT_PROD_NAMESPACE = [$NS]"

					if toExcludeProdNamespace $NS
					then
						echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
						continue
					fi

					local NS_OUTDIR="$PRODUCT_DATA_OUTDIR/$NS"
			
					if [ ! -d $NS_OUTDIR ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Making directory [$NS_OUTDIR]..."
						mkdir -p $NS_OUTDIR
					fi
			
					# echoPvcUsageHeader $NS
					GET_PVC_USAGE="true"
					analyzeOcPvc $NS $NS_OUTDIR/oc_pvc.out $NS_OUTDIR/pvc
				done
				;;
			nodeinfo)
				analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
				;;
			healthcheck)
				analyzeOcNode $CLUSTER_DATA_OUTDIR/oc_node.out $CLUSTER_DATA_OUTDIR/oc_top_node.out
				getOcProdStatus
				echoOcProdStatus

				for NS in ${WAIOPS_PROD_NAMESPACES[@]}
				do
					echoCsv $NS
					$OC_CMD get all -o wide -n $NS > $PRODUCT_DATA_OUTDIR/$NS/oc_all.out
					analyzeOcAll $NS $PRODUCT_DATA_OUTDIR/$NS/oc_all.out $PRODUCT_DATA_OUTDIR/$NS
					analyzeOcPvc $NS $PRODUCT_DATA_OUTDIR/$NS/oc_pvc.out $PRODUCT_DATA_OUTDIR/pvc
				done
				;;	
		esac
	done
}

getCustomData()
{
	if [ ${#PRIMARY_MODE_ARRAY[@]} -gt 0 ] && [ $MUSTGATHER_OPT != "basic" ] && [ $MUSTGATHER_OPT != "limited" ]
	then
		if [ ${#RTVAR_DISABLE_OPER_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_OPER_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for 'openshift-operators' is turned off [RTVAR_DISABLE_OPER_DATA = $RTVAR_DISABLE_OPER_DATA]!"
		else
			getOcAll openshift-operators $OTHER_NS_DATA_OUTDIR/openshift-operators/oc_all.out
			descAll openshift-operators $OTHER_NS_DATA_OUTDIR/openshift-operators/oc_all.out $OTHER_NS_DATA_OUTDIR/openshift-operators
		fi

		if [ ${#RTVAR_DISABLE_OLM_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_OLM_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for 'openshift-operator-lifecycle-manager' is turned off [RTVAR_DISABLE_OLM_DATA = $RTVAR_DISABLE_OLM_DATA]!"
		else
			getOcAll openshift-operator-lifecycle-manager $OTHER_NS_DATA_OUTDIR/openshift-operator-lifecycle-manager/oc_all.out
			descAll openshift-operator-lifecycle-manager $OTHER_NS_DATA_OUTDIR/openshift-operator-lifecycle-manager/oc_all.out $OTHER_NS_DATA_OUTDIR/openshift-operator-lifecycle-manager
		fi

		if [ ${#RTVAR_DISABLE_MKT_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_MKT_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for 'openshift-marketplace' is turned off [RTVAR_DISABLE_MKT_DATA = $RTVAR_DISABLE_MKT_DATA]!"
		else
			getOcAll openshift-marketplace $OTHER_NS_DATA_OUTDIR/openshift-marketplace/oc_all.out
			descAll openshift-marketplace $OTHER_NS_DATA_OUTDIR/openshift-marketplace/oc_all.out $OTHER_NS_DATA_OUTDIR/openshift-marketplace
		fi

		if [ ${#RTVAR_DISABLE_OCS_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_OCS_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for 'openshift-storage' is turned off [RTVAR_DISABLE_OCS_DATA = $RTVAR_DISABLE_OCS_DATA]!"
		else
			getOcAll openshift-storage $OTHER_NS_DATA_OUTDIR/openshift-storage/oc_all.out
			descAll openshift-storage $OTHER_NS_DATA_OUTDIR/openshift-storage/oc_all.out $OTHER_NS_DATA_OUTDIR/openshift-storage
		fi

		if [ ${#RTVAR_DISABLE_CRD_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_CRD_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for custom CRDs is turned off [RTVAR_DISABLE_CRD_DATA = $RTVAR_DISABLE_CRD_DATA]!"
		else
			if [ ${#RTVAR_WAIOPS_CRD} -gt 0 ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Executing getCrdData() with user-provided regex [$RTVAR_WAIOPS_CRD]..."
				getCrdData "${RTVAR_WAIOPS_CRD}" $CUSTOM_DATA_OUTDIR/custom_crd
			else
				local WAIOPS_CUSTOM_CRD_REGEX="ibm|postgresql|camel|knative"
				echo "[$(date)] [${FUNCNAME[0]}] Executing getCrdData() with default regex [$WAIOPS_CUSTOM_CRD_REGEX]..."
				getCrdData "${WAIOPS_CUSTOM_CRD_REGEX}" $CUSTOM_DATA_OUTDIR/custom_crd
			fi
		fi

		if [ ${#RTVAR_DISABLE_SCC_DATA} -gt 0 ] && [ ${RTVAR_DISABLE_SCC_DATA} == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Data collection and analysis for getWhoCanScc() is turned off [RTVAR_DISABLE_SCC_DATA = $RTVAR_DISABLE_SCC_DATA]!"
		else
			getWhoCanScc $CUSTOM_DATA_OUTDIR/whocan-scc
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] MUSTGATHER_OPT = [$MUSTGATHER_OPT]. Skipping custom data collection..."
	fi
}

echoEndMsg()
{
	echo "NOTE:"
	echo "(1) Please upload data file [$1] to IBM Support website."
	echo
}

# [OPTIONAL] Suppoting functions
getOcProdStatus()
{
	local PRODSTATUS_OUTFILE=$OUTDIR/prod_status.tmp

	if [ ${#RTVAR_AIMGR_NS} -gt 0 ] || [ ${#RTVAR_EVTMGR_NS} -gt 0 ] || [ ${#RTVAR_EVTMGR_HYBRID_NS} -gt 0 ]
	then
		local AIMGR_PROD_LIST="installations.orchestrator.aiops.ibm.com aimanager aiopsedge automationuiconfig automationbase cartridge cartridgerequirements eventprocessor ircore aiopsanalyticsorchestrator lifecycleservice baseui asmformation zenservices aiopsui"
		local EVTMGR_PROD_LIST="noi noiformation asmformation cemformation noihybrid"

		if [ ${#WAIOPS_AIMGR_NAMESPACE_ARR[@]} -gt 0 ]
		then
			for AIMGR_NS in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $AIMGR_NS" "$AIMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi

		if [ ${#WAIOPS_EVTMGR_NAMESPACE_ARR[@]} -gt 0 ] 
		then
			for EVTMGR_NS in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $EVTMGR_NS" "$EVTMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi

		if [ ${#WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]} -gt 0 ] 
		then
			for EVTMGR_HYBRID_NS in ${WAIOPS_EVTMGR_HYBRID_NAMESPACE_ARR[@]}
			do
				getProdNamespacesHelper "-n $EVTMGR_HYBRID_NS" "$EVTMGR_PROD_LIST" "$PRODSTATUS_OUTFILE"
			done
		fi
	else
		local PROD_LIST="installations.orchestrator.aiops.ibm.com aimanager aiopsedge automationuiconfig automationbase cartridge cartridgerequirements eventprocessor ircore aiopsanalyticsorchestrator lifecycleservice baseui asmformation noi noiformation cemformation noihybrid zenservices aiopsui"
		
		getProdNamespacesHelper "-A" "$PROD_LIST" "$PRODSTATUS_OUTFILE"	
	fi
}

echoOcProdStatus()
{
	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get installations.orchestrator.aiops.ibm.com,noi,aimanager,asmformation,cemformation' => $ANALYZE_OUTFILE"
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "STATUS REPORT OF ${PRODUCT_NAME} PRODUCT COMPONENTS" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE

	printf "%-42s %-30s %-25s %-25s %-15s \n" "KIND" "NAME" "NAMESPACE" "VERSION" "PHASE/STATUS" >> $ANALYZE_OUTFILE

	if [ -s $OUTDIR/prod_status.tmp ]
	then
		while read PROD_LINE
		do
			if [[ $PROD_LINE =~ ^KIND ]]
			then
				continue
			else
				if [ $MG_DEBUG == "true" ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] PROD_LINE = [$PROD_LINE]"
				fi
			fi

			local KIND=$(echo "$PROD_LINE" | $AWK '{ print $1 }')
			local LC_KIND=$(echo "$KIND" | $AWK '{ print tolower($0) }')
			local NAME=$(echo "$PROD_LINE" | $AWK '{ print $2 }')
			local NAMESPACE=$(echo "$PROD_LINE" | $AWK '{ print $3 }')
			local VERSION=$(echo "$PROD_LINE" | $AWK '{ print $4 }')
			local PHASE=$(echo "$PROD_LINE" | $AWK 'BEGIN {STR=""}{ for (i=5; i<=NF; i++) { if (i==5) {STR=$i} else {STR=STR "-" $i} } } END {print STR}')
			local LC_PHASE=$(echo "$PHASE" | $AWK '{ print tolower($0) }')

			printf "%-42s %-30s %-25s %-25s %-15s \n" "$KIND" "$NAME" "$NAMESPACE" "$VERSION" "$PHASE" >> $ANALYZE_OUTFILE

			# Gather error/failure message of "Installation" object
			if [ $LC_KIND == "installations.orchestrator.aiops.ibm.com" ] || [ $LC_KIND == "installation" ]
			then
				if [ $LC_PHASE != "running" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [status.failureMessage] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.failureMessage" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE
	
						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			# Gather error/failure message of "AIManager" object
			if [ $LC_KIND == "aimanager" ]
			then
				if [ $LC_PHASE != "completed" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [status.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.message" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE

						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			if [ $LC_KIND == "asmformation" ] || [ $LC_KIND == "cemformation" ] || [ $LC_KIND == "noiformation" ]
			then
				if [ $LC_PHASE != "ok" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [status.components] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o jsonpath='{range .status.components[*]}{.kind}{"["}{.status.phase}{"] / "}{end}' | sed 's#/[ ]*$##')" >> $ANALYZE_OUTFILE

						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			if [ $LC_KIND == "baseui" ] || [ $LC_KIND == "aiopsui" ]
			then
				if [ $LC_PHASE != "ready" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [status.conditions.reason] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.conditions[?(@.type==\"Ready\")].reason" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE

						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			if [ $LC_KIND == "ircore" ] || [ $LC_KIND == "aiopsanalyticsorchestrator" ] || [ $LC_KIND == "automationuiconfig" ] || [ $LC_KIND == "automationbase" ] || [ $LC_KIND == "cartridge" ] || [ $LC_KIND == "cartridgerequirements" ] || [ $LC_KIND == "eventprocessor" ] || [ $LC_KIND == "aiopsedge" ] || [ $LC_KIND == "issueresolutioncore" ]
			then
				if [ $LC_PHASE != "ready" ] && [ $LC_PHASE != "registered" ] && [ $LC_PHASE != "created" ] && [ $LC_PHASE != "instancecreated" ] && [ $LC_PHASE != "configured" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [status.conditions.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.conditions[?(@.type==\"Ready\")].message" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE

						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			if [ $LC_KIND == "lifecycleservice" ]
			then
				if [ $LC_PHASE != "ready" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						local LC_STATUS=$($OC_CMD get $PROD -n $NAMESPACE -o custom-columns='PHASE:status.conditions[?(@.type=="Lifecycle Service Ready")].reason' --no-headers)

						if [ ${#LC_STATUS} -gt 0 ]
						then
							if [[ $LC_STATUS =~ none ]]
							then
								echo ">>> [status.conditions.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.conditions[?(@.type==\"LifecycleServiceReady\")].message" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE
							else
								echo ">>> [status.conditions.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.conditions[?(@.type==\"Lifecycle Service Ready\")].message" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE
							fi
						else
							echo ">>> [status.conditions.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="FAILURE:status.conditions[?(@.type==\"LifecycleServiceReady\")].message" | grep -v ^FAILURE)" >> $ANALYZE_OUTFILE
						fi

						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi

			if [ $LC_KIND == "zenservice" ]
			then	
				if [ $LC_PHASE != "completed" ]
				then
					if [ $LC_PHASE != "n/a" ]
					then
						echo ">>> [conditions.message] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="MSG:status.conditions[*].message" | grep -v '^MSG')" >> $ANALYZE_OUTFILE
						echo ">>> [progress] $($OC_CMD get $KIND $NAME -n $NAMESPACE -o custom-columns="PROGRESS:status.Progress" | grep -v '^PROGRESS')" >> $ANALYZE_OUTFILE
		
						if [ $INCIDENT_REPORT_ENABLED == "true" ]
						then
							setIncident "ocp" "$NAME" "oc_get_$LC_KIND" "KIND=$LC_KIND;NAMESPACE=$NAMESPACE;VERSION=$VERSION;PHASE=$LC_PHASE" "$PROD_LINE"
						fi
					fi
				fi
			fi	
		done < <(sort $OUTDIR/prod_status.tmp | grep -v ^KIND)
	
		if [ $MG_DEBUG == "true" ]
		then
			local DEBUG_OUTDIR=$DEBUG_OUTDIR/echoOcProdStatus
	
			if [ ! -d $DEBUG_OUTDIR ]
			then
				mkdir -p $DEBUG_OUTDIR
			fi

			echo "[$(date)] [${FUNCNAME[0]}] Backing up product status temp file [prod_status.tmp] to directory [$DEBUG_OUTDIR]..."
			cp -p $OUTDIR/prod_status.tmp $DEBUG_OUTDIR
		fi

		rm -f $OUTDIR/prod_status.tmp
	else
		echo "< N/A >" >> $ANALYZE_OUTFILE
	fi
					
	echo >> $ANALYZE_OUTFILE
}

getOcInstallation()
{
	local HEADER_PRINTED="false"

	for AIMGR_NS in ${WAIOPS_AIMGR_NAMESPACE_ARR[@]}
	do	
		echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

		if ! checkUserPriv get,list installations.orchestrator.aiops.ibm.com $AIMGR_NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [noi] in namespace [$EVTMGR_NS]. Skipping..."	
			return 1
		fi

		for INSTALL in $($OC_CMD get installations.orchestrator.aiops.ibm.com -n $AIMGR_NS | grep -v ^NAME | $AWK '{ print $1 }')	
		do
			if [ $HEADER_PRINTED == "false" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Executing status report for AI Manager installation => $ANALYZE_OUTFILE"
				echo "===================================================" >> $ANALYZE_OUTFILE
				echo "STATUS REPORT OF AI MANAGER INSTALLATION" >> $ANALYZE_OUTFILE
				echo "===================================================" >> $ANALYZE_OUTFILE
			fi

			local HEADER_PRINTED="true"

			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get installations.orchestrator.aiops.ibm.com $INSTALL -n $AIMGR_NS' => $ANALYZE_OUTFILE"
			$OC_CMD get installations.orchestrator.aiops.ibm.com $INSTALL -n $AIMGR_NS -o=jsonpath="{'licenseacceptance: '}{.status.licenseacceptance}{'\n'}{'imagePullSecret: '}{.spec.imagePullSecret}{'\n'}{'size: '}{.status.size}{'\n'}{'storageclass: '}{.status.storageclass}{'\n'}{'storageclasslargeblock: '}{.status.storageclasslargeblock}{'\n'}{range .spec.pakModules[*]}{'[pakModule] '}{.name}{': '}{.enabled}{'\n'}{end}" >> $ANALYZE_OUTFILE
		done

		echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

		if ! checkUserPriv get,list aimanager $AIMGR_NS
		then
			echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [noi] in namespace [$EVTMGR_NS]. Skipping..."	
			return 1
		fi

		for AIMGR in $($OC_CMD get aimanager -n $AIMGR_NS | grep -v ^NAME | $AWK '{ print $1 }')
		do
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get aimanager $AIMGR -n $AIMGR_NS' => $ANALYZE_OUTFILE"
			$OC_CMD get aimanager $AIMGR -n $AIMGR_NS -o=jsonpath="{'cartridge: '}{.spec.cartridge.name}{'\n'}{'existingPullSecret: '}{.spec.existingPullSecret.name}{'\n'}{'[modelTrain] maxLearners: '}{.spec.modelTrain.maxLearners}{'\n'}{'[modelTrain] pollInterval: '}{.spec.modelTrain.pollInterval}{'\n'}{'[modelTrain] sizeLimit: '}{.spec.modelTrain.sizeLimit}{'\n'}" >> $ANALYZE_OUTFILE
		done

		echo >> $ANALYZE_OUTFILE
	done
}

getOcNoi()
{
	local HEADER_PRINTED="false"

	for EVTMGR_NS in ${WAIOPS_EVTMGR_NAMESPACE_ARR[@]}
	do	
		echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

		if ! checkUserPriv get,list noi $EVTMGR_NS
		then
			echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [noi] in namespace [$EVTMGR_NS]. Skipping..."	
			return 1
		fi

		for EVTMGR in $($OC_CMD get noi -n $EVTMGR_NS | grep -v ^NAME | $AWK '{ print $1 }')	
		do
			if [ $HEADER_PRINTED == "false" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Executing status report for Event Manager (NOI) installation => $ANALYZE_OUTFILE"
				echo "===================================================" >> $ANALYZE_OUTFILE
				echo "STATUS REPORT OF EVENT MANAGER (NOI) INSTALLATION" >> $ANALYZE_OUTFILE
				echo "===================================================" >> $ANALYZE_OUTFILE
			fi

			local HEADER_PRINTED="true"

			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get noi $EVTMGR -n $EVTMGR_NS' => $ANALYZE_OUTFILE"
			$OC_CMD get noi $EVTMGR -n $EVTMGR_NS -o=jsonpath="{'licenseacceptance: '}{.spec.license.accept}{'\n'}{'entitlementSecret: '}{.spec.entitlementSecret}{'\n'}{'deploymentType: '}{.spec.deploymentType}{'\n'}{'[persistence] enabled: '}{.spec.persistence.enabled}{'\n'}" >> $ANALYZE_OUTFILE

			if [ $($OC_CMD get noi $EVTMGR -n $EVTMGR_NS -o=jsonpath="{.spec.persistence.enabled}") == "true" ]
			then
				local STORAGECLASS_STR="storageClass"
				local STORAGESIZE_STR="storageSize"
				local FINAL_JSON_STR=""
					
				for COMP in NCOPrimary NCOBackup ImpactServer ImpactGUI Zookeeper Kafka Elastic Couchdb CassandraData CassandraBackup
				do
					FINAL_JSON_STR=${FINAL_JSON_STR}"{'[persistence] ${STORAGECLASS_STR}${COMP}: '}{.spec.persistence.${STORAGECLASS_STR}${COMP}}{' ['}{.spec.persistence.${STORAGESIZE_STR}${COMP}}{']'}{'\n'}"
				done

				$OC_CMD get noi $EVTMGR -n $EVTMGR_NS -o=jsonpath="$FINAL_JSON_STR" >> $ANALYZE_OUTFILE
			fi

			echo >> $ANALYZE_OUTFILE
		done
	done
}

getNginxDump()
{
	local AIMGR_NS=$1
	local OUTPUT_DIR=$2

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv create pods/exec $AIMGR_NS
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD exec' on resource [pod] in namespace [$AIMGR_NS]. Skipping..."
		return 1
	fi
	
	if [ ! -d $OUTPUT_DIR ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Making directory [$OUTPUT_DIR]..."
		mkdir -p $OUTPUT_DIR
	fi
	
	local NGINX_POD_REGEX="^ibm-nginx-"

	for NGINX_POD in $($OC_CMD get pod -n $AIMGR_NS | egrep $NGINX_POD_REGEX | $AWK '{ print $1 }')
	do
		echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $AIMGR_NS $NGINX_POD -- nginx -T => $OUTPUT_DIR/${NGINX_POD}.dump"	
		$OC_CMD exec -n $AIMGR_NS $NGINX_POD -- nginx -T > $OUTPUT_DIR/${NGINX_POD}.dump 2>&1
	done 
}

echoCsv()
{
	local NAMESPACE=$1

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get csv $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [csv] in namespace [$NAMESPACE]. Skipping..."
		return 1
	fi
	
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "STATUS REPORT OF CLUSTER SERVICE VERSION (namespace = $NAMESPACE)" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE
	$OC_CMD get csv -n $NAMESPACE >> $ANALYZE_OUTFILE 2>&1
	echo >> $ANALYZE_OUTFILE
}

echoSubscription()
{
	local NAMESPACE=$1

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get subscriptions $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [subscriptions] in namespace [$NAMESPACE]. Skipping..."
		return 1
	fi
	
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "STATUS REPORT OF PRODUCT SUBSCRIPTIONS (namespace = $NAMESPACE)" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE
	$OC_CMD get subscriptions -n $NAMESPACE >> $ANALYZE_OUTFILE 2>&1
	echo >> $ANALYZE_OUTFILE
}

echoStorageClass()
{
	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get sc all
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [storageclass] in namespace [$NAMESPACE]. Skipping..."
		return 1
	fi
	
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "STORAGE CLASSES OF CLUSTER" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE
	$OC_CMD get sc >> $ANALYZE_OUTFILE 2>&1
	echo >> $ANALYZE_OUTFILE
}

echoTestPodNw()
{
	local NAMESPACE=$1
	
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "NETWORK CONNECTIVITY TEST (namespace = $NAMESPACE)" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE
}

echoPvcUsageHeader()
{
	local NAMESPACE=$1
	
	echo "===================================================" >> $ANALYZE_OUTFILE
	echo "HEALTH REPORT OF PVC (namespace = $NAMESPACE)" >> $ANALYZE_OUTFILE
	echo "===================================================" >> $ANALYZE_OUTFILE
}

echoTestPodNwFail()
{
	echo "None of the selected pods [$@] passed (or is available for) the network connectivity test!" >> $ANALYZE_OUTFILE
	echo >> $ANALYZE_OUTFILE
}

getCamelInfo()
{
	local NAMESPACE=$1
	local OC_CAMEL_OUTFILE=$2

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get camelcatalogs $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [camelcatalogs] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get camelcatalogs -n $NAMESPACE' => $OC_CAMEL_OUTFILE"
	echo "[camelcatalogs]" > $OC_CAMEL_OUTFILE
	$OC_CMD get camelcatalogs -n $NAMESPACE >> $OC_CAMEL_OUTFILE 2>&1

	echo >> $OC_CAMEL_OUTFILE
	
	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get integrationkits $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrationkits] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get integrationkits -n $NAMESPACE' => $OC_CAMEL_OUTFILE"
	echo "[integrationkits]" >> $OC_CAMEL_OUTFILE
	$OC_CMD get integrationkits -n $NAMESPACE >> $OC_CAMEL_OUTFILE 2>&1

	echo >> $OC_CAMEL_OUTFILE
	
	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get integrationplatforms $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrationplatforms] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get integrationplatforms -n $NAMESPACE' => $OC_CAMEL_OUTFILE"
	echo "[integrationplatforms]" >> $OC_CAMEL_OUTFILE
	$OC_CMD get integrationplatforms -n $NAMESPACE >> $OC_CAMEL_OUTFILE 2>&1

	echo >> $OC_CAMEL_OUTFILE
	
	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get integrations $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrations] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get integrations -n $NAMESPACE' => $OC_CAMEL_OUTFILE"
	echo "[integrations]" >> $OC_CAMEL_OUTFILE
	$OC_CMD get integrations -n $NAMESPACE >> $OC_CAMEL_OUTFILE 2>&1

	echo >> $OC_CAMEL_OUTFILE
	
	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get builds $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [builds] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get builds -n $NAMESPACE' => $OC_CAMEL_OUTFILE"
	echo "[builds]" >> $OC_CAMEL_OUTFILE
	$OC_CMD get builds -n $NAMESPACE >> $OC_CAMEL_OUTFILE 2>&1
}

descCamelInfo()
{
	if [ $OC_DESC_ON == "false" ] && [ $COLLECT_YAML == "false" ]
	then
		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] '$OC_CMD desribe' and '$OC_CMD get -o yaml' are both disabled. Returning..."
		fi
	
		return
	fi
	
	local NAMESPACE=$1
	local F_OUTDIR=$2
		
	if [ ! -d $F_OUTDIR ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Making directory [$F_OUTDIR]..."
		mkdir -p $F_OUTDIR
	fi

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get,list camelcatalogs $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [camelcatalogs] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	for C_CATALOG in $($OC_CMD get camelcatalogs -n $NAMESPACE | tail -n +2 | $AWK '{ print $1 }')
	do
		if [ ! -d $F_OUTDIR/camelcatalogs ]
		then
			mkdir -p $F_OUTDIR/camelcatalogs
		fi

		if [ $OC_DESC_ON == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD describe camelcatalogs $C_CATALOG -n $NAMESPACE' => $F_OUTDIR/camelcatalogs/$C_CATALOG.desc"
			$OC_CMD describe camelcatalogs $C_CATALOG -n $NAMESPACE > $F_OUTDIR/camelcatalogs/$C_CATALOG.desc 2>&1
		fi

		if [ $COLLECT_YAML == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get -o yaml camelcatalogs $C_CATALOG -n $NAMESPACE' => $F_OUTDIR/camelcatalogs/$C_CATALOG.yaml"
			$OC_CMD get -o yaml camelcatalogs $C_CATALOG -n $NAMESPACE > $F_OUTDIR/camelcatalogs/$C_CATALOG.yaml 2>&1
		fi
	done

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get,list integrationkits $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrationkits] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	for C_INTKIT in $($OC_CMD get integrationkits -n $NAMESPACE | tail -n +2 | $AWK '{ print $1 }')
	do
		if [ ! -d $F_OUTDIR/integrationkits ]
		then
			mkdir -p $F_OUTDIR/integrationkits
		fi

		if [ $OC_DESC_ON == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD describe integrationkits $C_INTKIT -n $NAMESPACE' => $F_OUTDIR/integrationkits/$C_INTKIT.desc"
			$OC_CMD describe integrationkits $C_INTKIT -n $NAMESPACE > $F_OUTDIR/integrationkits/$C_INTKIT.desc 2>&1
		fi

		if [ $COLLECT_YAML == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get -o yaml integrationkits $C_INTKIT -n $NAMESPACE' => $F_OUTDIR/integrationkits/$C_INTKIT.yaml"
			$OC_CMD get -o yaml integrationkits $C_INTKIT -n $NAMESPACE > $F_OUTDIR/integrationkits/$C_INTKIT.yaml 2>&1
		fi
	done

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get,list integrationplatforms $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrationplatforms] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	for C_INTPLAT in $($OC_CMD get integrationplatforms -n $NAMESPACE | tail -n +2 | $AWK '{ print $1 }')
	do
		if [ ! -d $F_OUTDIR/integrationplatforms ]
		then
			mkdir -p $F_OUTDIR/integrationplatforms
		fi

		if [ $OC_DESC_ON == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD describe integrationplatforms $C_INTPLAT -n $NAMESPACE' => $F_OUTDIR/integrationplatforms/$C_INTPLAT.desc"
			$OC_CMD describe integrationplatforms $C_INTPLAT -n $NAMESPACE > $F_OUTDIR/integrationplatforms/$C_INTPLAT.desc 2>&1
		fi

		if [ $COLLECT_YAML == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get -o yaml integrationplatforms $C_INTPLAT -n $NAMESPACE' => $F_OUTDIR/integrationplatforms/$C_INTPLAT.yaml"
			$OC_CMD get -o yaml integrationplatforms $C_INTPLAT -n $NAMESPACE > $F_OUTDIR/integrationplatforms/$C_INTPLAT.yaml 2>&1
		fi
	done

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get,list integrations $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [integrations] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	for C_INT in $($OC_CMD get integrations -n $NAMESPACE | tail -n +2 | $AWK '{ print $1 }')
	do
		if [ ! -d $F_OUTDIR/integrations ]
		then
			mkdir -p $F_OUTDIR/integrations
		fi

		if [ $OC_DESC_ON == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD describe integrations $C_INT -n $NAMESPACE' => $F_OUTDIR/integrations/$C_INT.desc"
			$OC_CMD describe integrations $C_INT -n $NAMESPACE > $F_OUTDIR/integrations/$C_INT.desc 2>&1
		fi

		if [ $COLLECT_YAML == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get -o yaml integrations $C_INT -n $NAMESPACE' => $F_OUTDIR/integrations/$C_INT.yaml"
			$OC_CMD get -o yaml integrations $C_INT -n $NAMESPACE > $F_OUTDIR/integrations/$C_INT.yaml 2>&1
		fi
	done

	echo "[$(date)] [${FUNCNAME[0]}] Checking user privileges..."

	if ! checkUserPriv get,list builds $NAMESPACE
	then
		echo "[$(date)] [${FUNCNAME[0]}]  User [$OC_WHOAMI] does not have privilege to execute '$OC_CMD get' on resource [builds] in namespace [$NAMESPACE]. Skipping..."
		return
	fi

	for C_BUILD in $($OC_CMD get builds -n $NAMESPACE | tail -n +2 | $AWK '{ print $1 }')
	do
		if [ ! -d $F_OUTDIR/builds ]
		then
			mkdir -p $F_OUTDIR/builds
		fi

		if [ $OC_DESC_ON == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD describe builds $C_BUILD -n $NAMESPACE' => $F_OUTDIR/builds/$C_BUILD.desc"
			$OC_CMD describe builds $C_BUILD -n $NAMESPACE > $F_OUTDIR/builds/$C_BUILD.desc 2>&1
		fi

		if [ $COLLECT_YAML == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD get -o yaml builds $C_BUILD -n $NAMESPACE' => $F_OUTDIR/builds/$C_BUILD.yaml"
			$OC_CMD get -o yaml builds $C_BUILD -n $NAMESPACE > $F_OUTDIR/builds/$C_BUILD.yaml 2>&1
		fi
	done
}

get_cert_from_routes()
{
	local NAMESPACE=$1
	local ROUTE_OUTDIR=$2/route.route.openshift.io
	local ROUTE=

	echo "[$(date)] [${FUNCNAME[0]}] Gathering connection details for route..."

	if [ ! -d $ROUTE_OUTDIR ]
	then
		mkdir -p $ROUTE_OUTDIR
	fi

	for ROUTE in $($OC_CMD get route -n ${NAMESPACE} --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')
	do
		local TLS_ENABLED=$(${OC_CMD} get route -n ${NAMESPACE} ${ROUTE} -o jsonpath="{.spec.tls}")
		local TARGET_HOST=$(${OC_CMD} get route -n ${NAMESPACE} ${ROUTE} -o jsonpath="{.spec.host}")

		get_external_endpoint_cert "${TARGET_HOST}:443" "$ROUTE_OUTDIR/$ROUTE.cert"

#		local TLS_ENABLED=$(${OC_CMD} get route -n ${NAMESPACE} ${ROUTE} -o jsonpath="{.spec.tls}")
#
#		if [ "${TLS_ENABLED}" != "<none>" ]
#		then
#			local TARGET_DETAILS=$(${OC_CMD} get route -n ${NAMESPACE} ${ROUTE} -o jsonpath="{.spec.host}{'##'}{.spec.port.targetPort}{'##'}{.spec.to.kind}{'##'}{.spec.to.name}")
#
#			local TARGET_HOST=$(echo "$TARGET_DETAILS" | $AWK -F## '{ print $1 }')
#			local TARGET_PORT_NAME=$(echo "$TARGET_DETAILS" | $AWK -F## '{ print $2 }')
#			local TARGET_TO_KIND=$(echo "$TARGET_DETAILS" | $AWK -F## '{ print $3 }')
#			local TARGET_TO_NAME=$(echo "$TARGET_DETAILS" | $AWK -F## '{ print $4 }')
#
#			echo "[$(date)] [${FUNCNAME[0]}] [ROUTE = $ROUTE] TARGET_DETAILS = [$TARGET_DETAILS]"
#			echo "[$(date)] [${FUNCNAME[0]}] [ROUTE = $ROUTE] TARGET_HOST = [$TARGET_HOST] / TARGET_PORT_NAME = [$TARGET_PORT_NAME] / TARGET_TO_KIND = [$TARGET_TO_KIND] / TARGET_TO_NAME = [$TARGET_TO_NAME]"
#
#			case "$TARGET_TO_KIND" in
#				Service)	if [[ $TARGET_PORT_NAME =~ ^[0-9]+ ]]
#						then
#							local TARGET_PORT=$TARGET_PORT_NAME
#						else
#							local TARGET_PORT=$(${OC_CMD} get service -n ${NAMESPACE} ${TARGET_TO_NAME} -o jsonpath="{.spec.ports[?(@.name=='$TARGET_PORT_NAME')].port}")
#						fi
#						echo "[$(date)] [${FUNCNAME[0]}] [ROUTE = $ROUTE] TARGET_PORT = [$TARGET_PORT]"
#						get_external_endpoint_cert "${TARGET_HOST}:${TARGET_PORT}" "$ROUTE_OUTDIR/$ROUTE.cert"
#						;;	
#				*)		echo "[$(date)] [${FUNCNAME[0]}] [ROUTE = $ROUTE] TARGET_TO_KIND = [$TARGET_TO_KIND] is not supported currently!"
#						;;
#			esac
#		fi
	done
}

get_external_endpoint_cert()
{
	local ADDRESS="${1}"
	local OUTPUT_FILE="${2}"

	local OPENSSL_PRESENCE=$(which openssl)

	if [ "${#OPENSSL_PRESENCE}" -gt 0 ]
	then
		echo "[$(date)] [${FUNCNAME[0]}] Get presented certificate at endpoint: ${ADDRESS} => $OUTPUT_FILE"
		local CONNECT_RC=$(echo -n | $OPENSSL_PRESENCE s_client -connect ${ADDRESS} -servername ${ADDRESS} &> /dev/null; echo ${?})

		if [ "${CONNECT_RC}" -eq 0 ]
		then
			echo -n | $OPENSSL s_client -connect "${ADDRESS}" -servername "${ADDRESS}" &> "${OUTPUT_FILE}"
		else
			echo "[$(date)] [${FUNCNAME[0]}] Error getting certificate from endpoint: ${ADDRESS}"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] openssl not available on this system - skipping endpoint certificate discovery..."
	fi
}

getMetricsData()
{
	local FUNC_ARR=("getConnectionsMetrics" "getApplicationsMetrics" "getAlertsMetrics" "getStoriesMetrics" "getRunbooksExecutionMetrics" "getPoliciesMetrics")
	local TMPFILE=$OUTDIR/metricsprocessor.log

	for NS in ${WAIOPS_PROD_NAMESPACES[@]}
	do
		if toExcludeProdNamespace $NS
		then
			echo "[$(date)] [${FUNCNAME[0]}] To exclude namespace [$NS]. Skipping..."
			continue
		fi

		for MPOD in $(getResourceInstances pod "-metricsprocessor-" $NS)
		do
			if isPodOk $NS $MPOD
			then
				$OC_CMD logs $MPOD > $TMPFILE
	
				local PRINT_HEADER="true"
	
				if [ -s $TMPFILE ]
				then
					if [ $PRINT_HEADER == "true" ]
					then
						echo "===================================================" >> $ANALYZE_OUTFILE
						echo "METRICS PROCESSOR - SUMMARY DATA (namespace = $NS)" >> $ANALYZE_OUTFILE
						echo "===================================================" >> $ANALYZE_OUTFILE
					fi
	
					for FUNC in ${FUNC_ARR[@]}
					do
						case "$FUNC" in
							getConnectionsMetrics) 
								local CMD="egrep 'getConnectionsMetrics' $TMPFILE | egrep 'Size of connectors' | tail -1 | $AWK '{ print \$NF}'" 
								local LABEL="Total Connections"	
								;;	
							getApplicationsMetrics)
								# local CMD="egrep 'getApplicationsMetrics' $TMPFILE | egrep 'results=' | tail -1 | $AWK -F'results=' '{ print \$2 }'" 
								local CMD="egrep 'METRIC_PUSHED.*type=Applications' $TMPFILE | tail -1 | $AWK -F''quantity= '{ print \$2 }' | $AWK -F',' '{ print \$1 }'" 
								local LABEL="Total Applications"	
								;;	
							getAlertsMetrics)
								local CMD="egrep 'getAlertsMetrics' $TMPFILE | egrep 'totalCount=' | tail -1 | $AWK -F'totalCount=' '{ print \$2 }'"
								local LABEL="Total Alerts"
								;;	
							getStoriesMetrics)
								local CMD="egrep 'getStoriesMetrics' $TMPFILE | egrep 'totalCount=' | tail -1 | $AWK -F'totalCount=' '{ print \$2 }'" 
								local LABEL="Total Stories"	
								;;	
							getRunbooksExecutionMetrics)
								local CMD="egrep 'getRunbooksExecutionMetrics' $TMPFILE | egrep 'executionCount=' | tail -1 | $AWK -F'executionCount=' '{ print \$2 }'" 
								local LABEL="Total Runbooks"	
								;;	
							getPoliciesMetrics)	
								local CMD="egrep 'getPoliciesMetrics' $TMPFILE | egrep 'policyCount=' | tail -1 | $AWK -F'policyCount=' '{ print \$2 }'" 
								local LABEL="Total Policies"	
								;;	
						esac
	
						local RESULT=$(eval "$CMD")
	
						if [ ${#RESULT} -gt 0 ]
						then
							echo "$LABEL: $RESULT" >> $ANALYZE_OUTFILE
						else
							echo "$LABEL: N/A" >> $ANALYZE_OUTFILE
						fi
	
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] [FUNC=$FUNC] CMD = [$CMD]"
							echo "[$(date)] [${FUNCNAME[0]}] [FUNC=$FUNC] RESULT = [$RESULT]"
						fi
					done
	
					echo >> $ANALYZE_OUTFILE
				fi
			else
				echo "[$(date)] [${FUNCNAME[0]}] [NAMESPACE=$NS / POD=$MPOD] is not running!"
			fi
		done
	done

	if [ -f $TMPFILE ]
	then
		rm $TMPFILE
	fi
}

initSetup() 
{
	if [ ${#MG_TTY} -gt 0 ] && [ ${MG_TTY} == "false" ]
	then
		if [ ${#RTVAR_INIT_SLEEP} -gt 0 ] && [[ ${RTVAR_INIT_SLEEP} =~ ^[0-9]*$ ]]
		then
			if [ $VIEW_ONLY != "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Sleeping for ${RTVAR_INIT_SLEEP}s..."
			fi

			sleep ${RTVAR_INIT_SLEEP}
		fi
	fi
}
