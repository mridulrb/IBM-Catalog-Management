getAiMgrKafkaInfo()
{
	if [ $AIMGR_KAFKA_SEARCH_SIZE -eq -1 ]
	then
		AIMGR_KAFKA_SEARCH_TERM="-o $AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION -e" 
		AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX="size-all"
	else
		AIMGR_KAFKA_SEARCH_TERM="-o $AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION -c $AIMGR_KAFKA_SEARCH_SIZE -e"
		AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX="size-$AIMGR_KAFKA_SEARCH_SIZE"
	fi

	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		AIMGR_KAFKA_TMPFILE=$PLUGINS_OUTDIR/aimgr_kafka.$$.tmp
		AIMGR_KAFKA_OUTDIR=$PLUGINS_OUTDIR/kafka

		if [ ! -d $AIMGR_KAFKA_OUTDIR ]
		then
			mkdir -p $AIMGR_KAFKA_OUTDIR
		fi

		if [ ${KAFKACAT_INSTALLED} == "true" ]
		then
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - KAFKA DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
	
			KAFKA_BROKER=$($OC_CMD get routes iaf-system-kafka-bootstrap -n $PLUGINS_NAMESPACE -o=jsonpath='{.status.ingress[0].host}{"\n"}'):443;
			KAFKA_SASL_PASSWORD=$($OC_CMD get secret cp4waiops-cartridge-kafka-auth -n $PLUGINS_NAMESPACE --template={{.data.password}} | base64 --decode);
			KAFKA_USERNAME=cp4waiops-cartridge-kafka-auth

			if [ ${#KAFKA_SASL_PASSWORD} -eq 0 ]
			then
				KAFKA_SASL_PASSWORD=$($OC_CMD get secret cp4waiops-cartridge-kafka-auth-0 -n $PLUGINS_NAMESPACE --template={{.data.password}} | base64 --decode);
				KAFKA_USERNAME=cp4waiops-cartridge-kafka-auth-0
			fi
		
			$OC_CMD extract secret/iaf-system-cluster-ca-cert -n $PLUGINS_NAMESPACE --keys=ca.crt --to=-> $PLUGINS_OUTDIR/kafka/ca.crt
	
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_BROKER = $KAFKA_BROKER"
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_SASL_PASSWORD = ${#KAFKA_SASL_PASSWORD} (length)"
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_CA_CERT = $(ls -l $PLUGINS_OUTDIR/kafka/ca.crt)"
			fi
	
			if [ ${#KAFKA_BROKER} -gt 0 ] && [ ${#KAFKA_SASL_PASSWORD} -gt 0 ] && [ -s $PLUGINS_OUTDIR/kafka/ca.crt ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Executing '$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=\$KAFKA_SASL_PASSWORD -b \$KAFKA_BROKER -L'"
				$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=$KAFKA_SASL_PASSWORD -b $KAFKA_BROKER -L > $AIMGR_KAFKA_TMPFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Unable to setup Kafka connection! Exiting..."
				return 1
			fi
	
			if [ -s $AIMGR_KAFKA_TMPFILE ]
			then
				grep 'topic' $AIMGR_KAFKA_TMPFILE | sed 's/^[ ]*//' >> $PLUGINS_ANALYZE_OUTFILE
				echo >> $PLUGINS_ANALYZE_OUTFILE
	
				for TOPIC in $(grep 'topic' $AIMGR_KAFKA_TMPFILE | sed 's/^[ ]*//' | grep '^topic' | $AWK '{ print $2 }' | sed 's/"//g')
				do
					CMD="$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=$KAFKA_SASL_PASSWORD -b $KAFKA_BROKER -C -t $TOPIC $AIMGR_KAFKA_SEARCH_TERM" 
					echo "[$(date)] [${FUNCNAME[0]}] Executing '$CMD' => $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX"
					eval "$CMD" > $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX 2>&1
				done	
	
				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/kafka
	
					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi
	
					echo "[$(date)] Copying temp file [$AIMGR_KAFKA_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_KAFKA_TMPFILE $TMPFILE_OUTDIR
				fi
	
				rm -f $AIMGR_KAFKA_TMPFILE
				rm -f $PLUGINS_OUTDIR/kafka/ca.crt
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_KAFKA_TMPFILE] does not exist or is zero-sized!"	
			fi
		else
			# TODO - Consider using kafka-console-consumer.sh script to dump data (concern: initial test shows performance issue)
			echo	"[$(date)] ERROR: kafkacat or kcat is not installed. Unable to pull data from Kafka!"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrFlinkInfo()
{
	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		AIMGR_JOBMANAGER_POD=$($OC_CMD get pod -n $PLUGINS_NAMESPACE 2> /dev/null | grep cp4waiops-eventprocessor-eve-29ee-ep-jobmanager- | head -1 | $AWK '{ print $1 }')

		if [ ${#AIMGR_JOBMANAGER_POD} -gt 0 ]
		then
			AIMGR_JM_TMPFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.tmp
			AIMGR_JM_ERRFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.stderr
			AIMGR_FLINK_OUTDIR=$PLUGINS_OUTDIR/flink

			if [ ! -d $AIMGR_FLINK_OUTDIR ]
			then
				mkdir -p $AIMGR_FLINK_OUTDIR
			fi

			FLINK_USERNAME=$($OC_CMD get secret $($OC_CMD get secrets -n $PLUGINS_NAMESPACE | grep cp4waiops-eventprocessor-eve-29ee-ep-admin-user | $AWK '!/-min/' | $AWK '{print $1;}') -n $PLUGINS_NAMESPACE -o jsonpath="{.data.username}"|base64 -d) 
			FLINK_PASSWORD=$($OC_CMD get secret $($OC_CMD get secrets -n $PLUGINS_NAMESPACE | grep cp4waiops-eventprocessor-eve-29ee-ep-admin-user | $AWK '!/-min/' | $AWK '{print $1;}') -n $PLUGINS_NAMESPACE -o jsonpath="{.data.password}"|base64 -d) 
			FLINK_URL="https://localhost:8081/v1"

			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - FLINK DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE

			# for ELEMENT in config jobs jobs/metrics jobmanager/config jobmanager/metrics jobmanager/logs taskmanagers taskmanagers/metrics datasets jars
			for ELEMENT in config jobs jobs/metrics jobmanager/config jobmanager/metrics jobmanager/logs datasets jars
			do
				CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/$ELEMENT'"
				echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/$ELEMENT'' => $AIMGR_JM_TMPFILE"
	
				if [ ${#JQ} -gt 0 ]
				then
					echo "[$ELEMENT]" >> $AIMGR_JM_TMPFILE

					if [ $MG_DEBUG == "true" ]
					then
						echo "[$ELEMENT]" >> $AIMGR_JM_ERRFILE
						eval $CMD 2>> $AIMGR_JM_ERRFILE | $JQ . >> $AIMGR_JM_TMPFILE
						echo >> $AIMGR_JM_ERRFILE
						echo >> $AIMGR_JM_ERRFILE
					else
						eval $CMD 2> /dev/null | $JQ . >> $AIMGR_JM_TMPFILE
					fi

					echo >> $AIMGR_JM_TMPFILE
					echo >> $AIMGR_JM_TMPFILE
				else
					echo "[$ELEMENT]" >> $AIMGR_JM_TMPFILE

					if [ $MG_DEBUG == "true" ]
					then
						echo "[$ELEMENT]" >> $AIMGR_JM_ERRFILE
						eval $CMD 2>> $AIMGR_JM_ERRFILE >> $AIMGR_JM_TMPFILE
						echo >> $AIMGR_JM_ERRFILE
						echo >> $AIMGR_JM_ERRFILE
					else
						eval $CMD 2> /dev/null >> $AIMGR_JM_TMPFILE
					fi

					echo >> $AIMGR_JM_TMPFILE
					echo >> $AIMGR_JM_TMPFILE
				fi
			done
		
			cat $AIMGR_JM_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
	
			# Collect job details
			echo "[$(date)] [${FUNCNAME[0]}] Getting Flink job details..."
			JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs'"	
			AIMGR_JM_JOBFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.job
			eval $JOBCMD > $AIMGR_JM_JOBFILE 2> /dev/null
	
			if [ -s $AIMGR_JM_JOBFILE ]
			then
				JOB_DATA_OUTDIR=$AIMGR_FLINK_OUTDIR/jobs

				if [ ! -d $JOB_DATA_OUTDIR ]
				then
					mkdir -p $JOB_DATA_OUTDIR
				fi

				if [ ${#JQ} -gt 0 ]
				then
					for JOBID in $(cat $AIMGR_JM_JOBFILE | $JQ '.jobs[].id' | sed 's/"//g')
					do
						OUTFILE=$JOB_DATA_OUTDIR/$JOBID.out
						JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'' => $OUTFILE"
						eval $JOBCMD 2> /dev/null | $JQ . > $OUTFILE

						OUTFILE=$JOB_DATA_OUTDIR/$JOBID.result	
						JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'' => $OUTFILE"
						eval $JOBCMD 2> /dev/null | $JQ . > $OUTFILE
					done
				else
					for JOBID in $($AWK -F'"id":' '{ for (i=2; i<=NF; i++) print $i }' $AIMGR_JM_JOBFILE | $AWK -F, '{ print $1 }' | sed 's/"//g')
					do
						OUTFILE=$JOB_DATA_OUTDIR/$JOBID.out
						JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'' => $OUTFILE"
						eval $JOBCMD 2> /dev/null > $OUTFILE

						OUTFILE=$JOB_DATA_OUTDIR/$JOBID.result	
						JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'' => $OUTFILE"
						eval $JOBCMD 2> /dev/null > $OUTFILE
					done
				fi		
			else
				echo "[$(date)] [${FUNCNAME[0]}] AIMGR_JM_JOBFILE [$AIMGR_JM_JOBFILE] does not exist or is zero-sized!"
			fi

			if [ $MG_DEBUG == "true" ]
			then
				TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/flink

				if [ ! -d $TMPFILE_OUTDIR ]
				then
					mkdir -p $TMPFILE_OUTDIR
				fi

				echo "[$(date)] Copying temp file [$AIMGR_JM_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
				cp -p $AIMGR_JM_TMPFILE $TMPFILE_OUTDIR
				echo "[$(date)] Copying temp file [$AIMGR_JM_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
				cp -p $AIMGR_JM_ERRFILE $TMPFILE_OUTDIR
				echo "[$(date)] Copying temp file [$AIMGR_JM_JOBFILE] to directory [$TMPFILE_OUTDIR]..."
				cp -p $AIMGR_JM_JOBFILE $TMPFILE_OUTDIR
			fi

			rm -f $AIMGR_JM_TMPFILE
			rm -f $AIMGR_JM_ERRFILE
			rm -f $AIMGR_JM_JOBFILE
		else
			 echo "[$(date)] [${FUNCNAME[0]}] Unable to locate AIMgr Job Manager pod!"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrESInfo()
{
	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		AIMGR_APISVR_POD=$($OC_CMD get pod -n $PLUGINS_NAMESPACE 2> /dev/null | grep aimanager-aio-ai-platform-api-server | head -1 | $AWK '{ print $1 }')

		if [ ${#AIMGR_APISVR_POD} -gt 0 ]
		then
			AIMGR_ES_TMPFILE=$PLUGINS_OUTDIR/aimgr_es_indices.$$.tmp
			AIMGR_ES_ERRFILE=$PLUGINS_OUTDIR/aimgr_es_indices.$$.stderr
			AIMGR_ESIDX_OUTDIR=$PLUGINS_OUTDIR/elasticsearch

			if [ ! -d $AIMGR_ESIDX_OUTDIR ]
			then
				mkdir -p $AIMGR_ESIDX_OUTDIR
			fi

			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - ELASTICSEARCH INDICES (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/indices'' => $AIMGR_ES_TMPFILE"
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/indices'' => $AIMGR_ES_TMPFILE" >> $AIMGR_ES_ERRFILE
			$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/_cat/indices?v=true' > $AIMGR_ES_TMPFILE 2>> $AIMGR_ES_ERRFILE

			if [ -s $AIMGR_ES_TMPFILE ]
			then	
				tr -d '' < $AIMGR_ES_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
				echo >> $PLUGINS_ANALYZE_OUTFILE
			
				while read LINE
				do
					if [ $(echo $LINE | $AWK '{ if ($0 ~ /^health status/) { print "HEADER" } else { print "DATA" }}') == "HEADER" ]
					then
						continue
					fi

					INDEX_NAME=$(echo $LINE | $AWK '{ print $3 }')
					
					if [ ${#JQ} -gt 0 ]
					then
						# [JQ] ES Index - info
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info 

						# [JQ] ES Index - data count
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_count' 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count

						# [JQ] ES Index - data
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_search?size='$AIMGR_ES_SEARCH_SIZE -d '{"query":{"match_all":{}}}' 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE
					else
						# ES Index - info
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME?pretty=true' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME?pretty=true' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'?pretty=true' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info 2>> $AIMGR_ES_ERRFILE

						# ES Index - data count
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count?pretty=true'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count?pretty=true'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_count?pretty=true' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count 2>> $AIMGR_ES_ERRFILE

						# ES Index - data 
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?pretty=true&size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE"
						echo "[$(date)] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?pretty=true&size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_search?pretty=true\&size='$AIMGR_ES_SEARCH_SIZE -d '{"query":{"match_all":{}}}' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE 2>> $AIMGR_ES_ERRFILE
					fi
				done < $AIMGR_ES_TMPFILE
	
				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/elasticsearcrh

					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi

					echo "[$(date)] Copying temp file [$AIMGR_ES_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_TMPFILE $TMPFILE_OUTDIR
					echo "[$(date)] Copying temp file [$AIMGR_ES_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_ERRFILE $TMPFILE_OUTDIR
				fi

				rm -f $AIMGR_ES_TMPFILE
				rm -f $AIMGR_ES_ERRFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_ES_TMPFILE] does not exist or is zero-sized!"
			fi		

			AIMGR_ES_TMPFILE=$PLUGINS_OUTDIR/aimgr_es_shards.$$.tmp
			AIMGR_ES_ERRFILE=$PLUGINS_OUTDIR/aimgr_es_shards.$$.stderr

			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - ELASTICSEARCH SHARDS (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/shards' => $AIMGR_ES_TMPFILE"
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/shards' => $AIMGR_ES_TMPFILE" >> $AIMGR_ES_ERRFILE
			$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/_cat/shards?v=true' > $AIMGR_ES_TMPFILE 2>> $AIMGR_ES_ERRFILE

			if [ -s $AIMGR_ES_TMPFILE ]
			then
				tr -d '^M' < $AIMGR_ES_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
				echo >> $PLUGINS_ANALYZE_OUTFILE

				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/elasticsearcrh

					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi

					echo "[$(date)] Copying temp file [$AIMGR_ES_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_TMPFILE $TMPFILE_OUTDIR
					echo "[$(date)] Copying temp file [$AIMGR_ES_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_ERRFILE $TMPFILE_OUTDIR
				fi

				rm -f $AIMGR_ES_TMPFILE
				rm -f $AIMGR_ES_ERRFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_ES_TMPFILE] does not exist or is zero-sized!"
			fi
		else
			echo "[$(date)] [${FUNCNAME[0]}] Unable to locate AIMgr API Server pod!"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

if [ $MG_DEBUG == "true" ]
then
	echo "[$(date)] [$(basename "$0")] DATA_DUMP = [$DATA_DUMP]"
	echo "[$(date)] [$(basename "$0")] GET_KAFKA_DATA = [$GET_KAFKA_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION = [$AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_SIZE = [$AIMGR_KAFKA_SEARCH_SIZE]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_TERM = [$AIMGR_KAFKA_SEARCH_TERM]"
	echo "[$(date)] [$(basename "$0")] GET_FLINK_DATA = [$GET_FLINK_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_FLINK_CURL_TIMEOUT = [$AIMGR_FLINK_CURL_TIMEOUT]"
	echo "[$(date)] [$(basename "$0")] GET_ES_DATA = [$GET_ES_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_ES_SEARCH_SIZE = [$AIMGR_ES_SEARCH_SIZE]"
	echo "[$(date)] [$(basename "$0")] AIMGR_ES_CURL_TIMEOUT = [$AIMGR_ES_CURL_TIMEOUT]"
fi

KAFKACAT_INSTALLED="false"

if [ $GET_KAFKA_DATA -eq 1 ]
then
	KAFKACAT=$(which kcat)

	if [ ${#KAFKACAT} -eq 0 ]
	then
		KAFKACAT=$(which kafkacat)
	else
		KAFKACAT_INSTALLED="true"
	fi

	if [ ${#KAFKACAT} -gt 0 ]
	then
		KAFKACAT_INSTALLED="true"
		getAiMgrKafkaInfo
	else
		echo "[$(date)] Unable to locate 'kafkacat/kcat' binary. Unable to pull data from Kafka!"
	fi
fi

if [ $GET_FLINK_DATA -eq 1 ]
then
	getAiMgrFlinkInfo
fi

if [ $GET_ES_DATA -eq 1 ]
then
	getAiMgrESInfo
fi
