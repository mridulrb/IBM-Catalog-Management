getAiMgrKafkaInfo()
{
	if [ $AIMGR_KAFKA_SEARCH_SIZE -eq -1 ]
	then
		AIMGR_KAFKA_SEARCH_TERM="-o $AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION -e" 
		AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX="size-all"
	else
		AIMGR_KAFKA_SEARCH_TERM="-o $AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION -c $AIMGR_KAFKA_SEARCH_SIZE -e"
		AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX="size-$AIMGR_KAFKA_SEARCH_SIZE"
	fi

	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		AIMGR_KAFKA_TMPFILE=$PLUGINS_OUTDIR/aimgr_kafka.$$.tmp
		AIMGR_KAFKA_OUTDIR=$PLUGINS_OUTDIR/kafka

		if [ ! -d $AIMGR_KAFKA_OUTDIR ]
		then
			mkdir -p $AIMGR_KAFKA_OUTDIR
		fi

		if [ ${KAFKACAT_INSTALLED} == "true" ]
		then
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - KAFKA DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
	
			CARTRIDGE_REQ_NAME="cp4waiops-cartridge"
			KAFKA_BROKER=$($OC_CMD get routes iaf-system-kafka-bootstrap -n $PLUGINS_NAMESPACE -o=jsonpath='{.status.ingress[0].host}{"\n"}'):443;
			KAFKA_USERNAME=$($OC_CMD get cartridgerequirements "${CARTRIDGE_REQ_NAME}" -n $PLUGINS_NAMESPACE -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].authentication.secret.secretName}')
			KAFKA_SASL_PASSWORD=$($OC_CMD get secret "${KAFKA_USERNAME}" -n $PLUGINS_NAMESPACE -o jsonpath='{.data.password}' | base64 --decode)
			KAFKA_CA_SECRET_NAME=$($OC_CMD get cartridgerequirements ${CARTRIDGE_REQ_NAME} -n $PLUGINS_NAMESPACE -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].caSecret.secretName}')

			$OC_CMD extract secret/$KAFKA_CA_SECRET_NAME -n $PLUGINS_NAMESPACE --keys=ca.crt --to=-> $PLUGINS_OUTDIR/kafka/ca.crt
	
			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_BROKER = $KAFKA_BROKER"
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_SASL_PASSWORD = ${#KAFKA_SASL_PASSWORD} (length)"
				echo "[$(date)] [${FUNCNAME[0]}] KAFKA_CA_CERT = $(ls -l $PLUGINS_OUTDIR/kafka/ca.crt)"
			fi
	
			if [ ${#KAFKA_BROKER} -gt 0 ] && [ ${#KAFKA_SASL_PASSWORD} -gt 0 ] && [ -s $PLUGINS_OUTDIR/kafka/ca.crt ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] Executing '$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=\$KAFKA_SASL_PASSWORD -b \$KAFKA_BROKER -L'"
				$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=$KAFKA_SASL_PASSWORD -b $KAFKA_BROKER -L > $AIMGR_KAFKA_TMPFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Unable to setup Kafka connection! Exiting..."
				return 1
			fi
	
			if [ -s $AIMGR_KAFKA_TMPFILE ]
			then
				for TOPIC in $(grep 'topic' $AIMGR_KAFKA_TMPFILE | sed 's/^[ ]*//' | grep '^topic' | $AWK '{ print $2 }' | sed 's/"//g' | sort | uniq)
				do
					# Kafka topic message count
					CMD="$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=$KAFKA_SASL_PASSWORD -b $KAFKA_BROKER -C -t $TOPIC -o beginning -e"

					local KAFKA_TOPIC_CMD="grep 'topic' $AIMGR_KAFKA_TMPFILE | sed 's/^[ ]*//' | $AWK '\$2 ~ /^\"$TOPIC\"$/ { print }'"
					local KAFKA_TOPIC_LINE=$(eval "$KAFKA_TOPIC_CMD")

					if [ $MG_DEBUG == "true" ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$KAFKA_TOPIC_CMD'..."
					fi

					if [ $AIMGR_KAFKA_TOPIC_MSG_COUNT -eq 1 ]
					then
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$CMD'..."
						fi

						local KAFKA_TOPIC_COUNT=$(eval "$CMD" 2> /dev/null | wc -l)
						echo "$KAFKA_TOPIC_LINE [message count = $KAFKA_TOPIC_COUNT]" >> $PLUGINS_ANALYZE_OUTFILE					
					else
						echo "$KAFKA_TOPIC_LINE" >> $PLUGINS_ANALYZE_OUTFILE
					fi

					if [ ${#AIMGR_KAFKA_DATA_DUMP} -gt 0 ] && [ $AIMGR_KAFKA_DATA_DUMP -eq 1 ]
					then
						# Kafka data dump
						CMD="$KAFKACAT -X security.protocol=SASL_SSL -X ssl.ca.location=$PLUGINS_OUTDIR/kafka/ca.crt -X sasl.mechanisms=SCRAM-SHA-512 -X sasl.username=$KAFKA_USERNAME -X sasl.password=$KAFKA_SASL_PASSWORD -b $KAFKA_BROKER -C -t $TOPIC $AIMGR_KAFKA_SEARCH_TERM" 
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$CMD' => $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX"
	
						eval "$CMD" > $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX.tmp 2> $AIMGR_KAFKA_OUTDIR/$TOPIC.err
	
						if [ ${#JQ} -gt 0 ]
						then
							cat $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX.tmp | $JQ . > $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX	2>> $AIMGR_KAFKA_OUTDIR/$TOPIC.err
							rm -f $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX.tmp
						else
							mv $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX.tmp $AIMGR_KAFKA_OUTDIR/$TOPIC.out.$AIMGR_KAFKA_SEARCH_OUTFILE_SUFFIX
						fi
					fi
				done	

				echo >> $PLUGINS_ANALYZE_OUTFILE
	
				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/kafka
	
					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi
	
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_KAFKA_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_KAFKA_TMPFILE $TMPFILE_OUTDIR
				fi
	
				rm -f $AIMGR_KAFKA_TMPFILE
				rm -f $PLUGINS_OUTDIR/kafka/ca.crt
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_KAFKA_TMPFILE] does not exist or is zero-sized!"	
			fi
		else
			# TODO - Consider using kafka-console-consumer.sh script to dump data (concern: initial test shows performance issue)
			echo	"[$(date)] [${FUNCNAME[0]}] ERROR: kafkacat or kcat is not installed. Unable to pull data from Kafka!"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrKafkaInfoThruInPodConsumer()
{
	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		CARTRIDGE_REQ_NAME="cp4waiops-cartridge"
		KAFKA_POD="iaf-system-kafka-0"

		AIMGR_KAFKA_TMPFILE=$PLUGINS_OUTDIR/aimgr_kafka.$$.tmp
		AIMGR_KAFKA_OUTDIR=$PLUGINS_OUTDIR/kafka

		if [ ! -d $AIMGR_KAFKA_OUTDIR ]
		then
			mkdir -p $AIMGR_KAFKA_OUTDIR
		fi

		echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
		echo "AI MANAGER - KAFKA DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
		echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE

		KAFKA_BROKER="$($OC_CMD get svc -n $PLUGINS_NAMESPACE iaf-system-kafka-bootstrap --no-headers | $AWK '{ print $1 }'):9093"
		KAFKA_USERNAME=$($OC_CMD get cartridgerequirements "${CARTRIDGE_REQ_NAME}" -n $PLUGINS_NAMESPACE -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].authentication.secret.secretName}')
		KAFKA_SASL_PASSWORD=$($OC_CMD get secret "${KAFKA_USERNAME}" -o jsonpath='{.data.password}' | base64 --decode)
		KAFKA_CA_SECRET_NAME=$($OC_CMD get cartridgerequirements ${CARTRIDGE_REQ_NAME} -o jsonpath='{.status.components.kafka.endpoints[?(@.scope=="External")].caSecret.secretName}')
		KAFKA_CA_CERT=$PLUGINS_OUTDIR/kafka/mg_ca.crt

		$OC_CMD extract secret/$KAFKA_CA_SECRET_NAME -n $PLUGINS_NAMESPACE --keys=ca.crt --to=-> $KAFKA_CA_CERT

		if [ $MG_DEBUG == "true" ]
		then
			echo "[$(date)] [${FUNCNAME[0]}] KAFKA_BROKER = $KAFKA_BROKER"
			echo "[$(date)] [${FUNCNAME[0]}] KAFKA_SASL_PASSWORD = ${#KAFKA_SASL_PASSWORD} (length)"
			echo "[$(date)] [${FUNCNAME[0]}] KAFKA_CA_CERT = $(ls -l $KAFKA_CA_CERT)"
		fi

		if [ ${#KAFKA_BROKER} -gt 0 ] && [ ${#KAFKA_SASL_PASSWORD} -gt 0 ] && [ -s $KAFKA_CA_CERT ]
		then
			# Create configuration files needed for kafka-console-consumer.sh
			KAFKA_CONSUMER_CFGFILE=$PLUGINS_OUTDIR/kafka/mg_consumer.cfg
			KEYSTORE_DIR="/tmp"
			KEYSTORE_NAME="$KEYSTORE_DIR/mg_truststore.pfx"
			KEYSTORE_PASSWORD="changeme"
			KEYSTORE_CONSUMER_CFGFILE=$KEYSTORE_DIR/$(basename $KAFKA_CONSUMER_CFGFILE)
			KEYSTORE_CERT=$KEYSTORE_DIR/$(basename $KAFKA_CA_CERT)

			echo "bootstrap.servers=${KAFKA_BROKER}" > $KAFKA_CONSUMER_CFGFILE
			echo "security.protocol=SASL_SSL" >> $KAFKA_CONSUMER_CFGFILE
			echo "ssl.protocol=TLSv1.2" >> $KAFKA_CONSUMER_CFGFILE
			echo "ssl.enabled.protocols=TLSv1.2" >> $KAFKA_CONSUMER_CFGFILE
			echo "ssl.truststore.location=$KEYSTORE_NAME" >> $KAFKA_CONSUMER_CFGFILE
			echo "ssl.truststore.password=$KEYSTORE_PASSWORD" >> $KAFKA_CONSUMER_CFGFILE
			echo "sasl.mechanism=SCRAM-SHA-512" >> $KAFKA_CONSUMER_CFGFILE
			echo "sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username=\"${KAFKA_USERNAME}\" password=\"${KAFKA_SASL_PASSWORD}\";" >> $KAFKA_CONSUMER_CFGFILE

			# Copy config file to Kafka pod
			$OC_CMD cp $KAFKA_CONSUMER_CFGFILE ${KAFKA_POD}:${KEYSTORE_DIR}

			# Create certificate in Kafka pod
			$OC_CMD cp $KAFKA_CA_CERT ${KAFKA_POD}:${KEYSTORE_DIR}
			
			# Import certificate
			# echo -n "changeme" > "${KEYSTORE_DIR}/truststore_pw.txt"
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c 'keytool -import -keystore ${KEYSTORE_NAME} -storetype PKCS12 -alias CARoot -file ${KEYSTORE_CERT} -noprompt -storepass $KEYSTORE_PASSWORD'"
			eval "$CMD"

			# List Kafka topics
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c '/opt/kafka/bin/kafka-topics.sh --list --bootstrap-server ${KAFKA_BROKER} --command-config ${KEYSTORE_CONSUMER_CFGFILE}'"
			
			for KAFKA_TOPIC in $(eval "$CMD")
			do
				echo "[$(date)] [${FUNCNAME[0]}] Collecting data from Kafka topic [$KAFKA_TOPIC]..."		
				local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c '/opt/kafka/bin/kafka-console-consumer.sh --bootstrap-server ${KAFKA_BROKER} --consumer.config ${KEYSTORE_CONSUMER_CFGFILE} --topic $KAFKA_TOPIC --from-beginning --timeout-ms=10000 --group cp4waiops'"

				if [ $MG_DEBUG == "true" ]
				then
					echo "[$(date)] [${FUNCNAME[0]}] CMD = [$CMD]"
				fi

				eval "$CMD" > $AIMGR_KAFKA_OUTDIR/$KAFKA_TOPIC.out	
			done

			# Clean up 
			echo "[$(date)] [${FUNCNAME[0]}] Deleting certificate from keystore..."
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c 'keytool -delete -keystore ${KEYSTORE_NAME} -storetype PKCS12 -alias CARoot -noprompt -storepass $KEYSTORE_PASSWORD'"
			eval "$CMD"

			echo "[$(date)] [${FUNCNAME[0]}] Deleting certificate [$KEYSTORE_CERT]..."
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c 'rm -f $KEYSTORE_CERT'"
			eval "$CMD"

			echo "[$(date)] [${FUNCNAME[0]}] Deleting consumer configuration file [$KEYSTORE_CONSUMER_CFGFILE]..."
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $KAFKA_POD -- bash -c 'rm -f $KEYSTORE_CONSUMER_CFGFILE'"
			eval "$CMD"
			
			rm -f $AIMGR_KAFKA_TMPFILE
			rm -f $KAFKA_CA_CERT
		else
			echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_KAFKA_TMPFILE] does not exist or is zero-sized!"	
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrFlinkInfo()
{
	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
		echo "AI MANAGER - FLINK DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
		echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE

		local FLINK_CONN_DATA=(cp4waiops,cp4waiops-eventprocessor-eve-29ee-ep-jobmanager-,cp4waiops-eventprocessor-eve-29ee-ep-admin-user aiops-ir-lifecycle,aiops-ir-lifecycle-eventprocessor-ep-jobmanager-,aiops-ir-lifecycle-eventprocessor-ep-admin-user)

		for FLINK_CONN in ${FLINK_CONN_DATA[@]}
		do
			local FLINK_NAME=$(echo "$FLINK_CONN" | $AWK -F, '{ print $1 }')
			local FLINK_POD_NAME=$(echo "$FLINK_CONN" | $AWK -F, '{ print $2 }')
			local FLINK_SECRET_NAME=$(echo "$FLINK_CONN" | $AWK -F, '{ print $3 }')

			# AIMGR_JOBMANAGER_POD=$($OC_CMD get pod -n $PLUGINS_NAMESPACE 2> /dev/null | grep cp4waiops-eventprocessor-eve-29ee-ep-jobmanager- | head -1 | $AWK '{ print $1 }')
			AIMGR_JOBMANAGER_POD=$($OC_CMD get pod -n $PLUGINS_NAMESPACE 2> /dev/null | grep "$FLINK_POD_NAME" |  head -1 | $AWK '{ print $1 }')
	
			if [ ${#AIMGR_JOBMANAGER_POD} -gt 0 ]
			then
				AIMGR_JM_TMPFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.tmp
				AIMGR_JM_ERRFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.stderr
				AIMGR_FLINK_OUTDIR=$PLUGINS_OUTDIR/flink
	
				if [ ! -d $AIMGR_FLINK_OUTDIR ]
				then
					mkdir -p $AIMGR_FLINK_OUTDIR
				fi
	
				FLINK_USERNAME=$($OC_CMD get secret $($OC_CMD get secrets -n $PLUGINS_NAMESPACE | grep "$FLINK_SECRET_NAME" | $AWK '!/-min/' | $AWK '{print $1;}') -n $PLUGINS_NAMESPACE -o jsonpath="{.data.username}"|base64 -d) 
				FLINK_PASSWORD=$($OC_CMD get secret $($OC_CMD get secrets -n $PLUGINS_NAMESPACE | grep "$FLINK_SECRET_NAME" | $AWK '!/-min/' | $AWK '{print $1;}') -n $PLUGINS_NAMESPACE -o jsonpath="{.data.password}"|base64 -d) 
				FLINK_URL="https://localhost:8081/v1"
	
				for ELEMENT in config overview jobs jobs/metrics jobmanager/config jobmanager/metrics jobmanager/logs taskmanagers taskmanagers/metrics datasets jars
				do
					CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/$ELEMENT'"
					echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/$ELEMENT'' => $AIMGR_JM_TMPFILE"
		
					if [ ${#JQ} -gt 0 ]
					then
						echo "[$FLINK_NAME: $ELEMENT]" >> $AIMGR_JM_TMPFILE
	
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$FLINK_NAME: $ELEMENT]" >> $AIMGR_JM_ERRFILE
							eval $CMD 2>> $AIMGR_JM_ERRFILE | $JQ . >> $AIMGR_JM_TMPFILE
							echo >> $AIMGR_JM_ERRFILE
							echo >> $AIMGR_JM_ERRFILE
						else
							eval $CMD 2> /dev/null | $JQ . >> $AIMGR_JM_TMPFILE
						fi
	
						echo >> $AIMGR_JM_TMPFILE
						echo >> $AIMGR_JM_TMPFILE
					else
						echo "[$FLINK_NAME: $ELEMENT]" >> $AIMGR_JM_TMPFILE
	
						if [ $MG_DEBUG == "true" ]
						then
							echo "[$FLINK_NAME: $ELEMENT]" >> $AIMGR_JM_ERRFILE
							eval $CMD 2>> $AIMGR_JM_ERRFILE >> $AIMGR_JM_TMPFILE
							echo >> $AIMGR_JM_ERRFILE
							echo >> $AIMGR_JM_ERRFILE
						else
							eval $CMD 2> /dev/null >> $AIMGR_JM_TMPFILE
						fi
	
						echo >> $AIMGR_JM_TMPFILE
						echo >> $AIMGR_JM_TMPFILE
					fi
				done
			
				cat $AIMGR_JM_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
		
				# Collect job details
				echo "[$(date)] [${FUNCNAME[0]}] Getting Flink job details..."
				JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs'"	
				AIMGR_JM_JOBFILE=$PLUGINS_OUTDIR/aimgr_flink.$$.job
				eval $JOBCMD > $AIMGR_JM_JOBFILE 2> /dev/null
		
				if [ -s $AIMGR_JM_JOBFILE ]
				then
					JOB_DATA_OUTDIR=$AIMGR_FLINK_OUTDIR/jobs/$FLINK_NAME
	
					if [ ! -d $JOB_DATA_OUTDIR ]
					then
						mkdir -p $JOB_DATA_OUTDIR
					fi
	
					if [ ${#JQ} -gt 0 ]
					then
						for JOBID in $(cat $AIMGR_JM_JOBFILE | $JQ '.jobs[].id' | sed 's/"//g')
						do
							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.out
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null | $JQ . > $OUTFILE
	
							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.result	
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null | $JQ . > $OUTFILE

							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.exception
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/exceptions'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/exceptions'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null | $JQ . > $OUTFILE
						done
					else
						for JOBID in $($AWK -F'"id":' '{ for (i=2; i<=NF; i++) print $i }' $AIMGR_JM_JOBFILE | $AWK -F, '{ print $1 }' | sed 's/"//g')
						do
							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.out
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null > $OUTFILE
	
							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.result	
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/execution-result'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null > $OUTFILE

							OUTFILE=$JOB_DATA_OUTDIR/$JOBID.exception
							JOBCMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u $FLINK_USERNAME:$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/exceptions'"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_JOBMANAGER_POD -- bash -c 'curl -k -X GET -m $AIMGR_FLINK_CURL_TIMEOUT -u \$FLINK_USERNAME:\$FLINK_PASSWORD $FLINK_URL/jobs/$JOBID/exceptions'' => $OUTFILE"
							eval $JOBCMD 2> /dev/null > $OUTFILE
						done
					fi		
				else
					echo "[$(date)] [${FUNCNAME[0]}] AIMGR_JM_JOBFILE [$AIMGR_JM_JOBFILE] does not exist or is zero-sized!"
				fi
	
				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/flink
	
					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi
	
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_JM_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_JM_TMPFILE $TMPFILE_OUTDIR
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_JM_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_JM_ERRFILE $TMPFILE_OUTDIR
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_JM_JOBFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_JM_JOBFILE $TMPFILE_OUTDIR
				fi
	
				rm -f $AIMGR_JM_TMPFILE
				rm -f $AIMGR_JM_ERRFILE
				rm -f $AIMGR_JM_JOBFILE
			else
				 echo "[$(date)] [${FUNCNAME[0]}] Unable to locate AIMgr Job Manager pod!"
			fi
		done
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrESInfo()
{
	if [ ${#PLUGINS_NAMESPACE} -gt 0 ]
	then
		AIMGR_APISVR_POD=$($OC_CMD get pod -n $PLUGINS_NAMESPACE 2> /dev/null | grep aimanager-aio-ai-platform-api-server | head -1 | $AWK '{ print $1 }')

		if [ ${#AIMGR_APISVR_POD} -gt 0 ]
		then
			AIMGR_ES_TMPFILE=$PLUGINS_OUTDIR/aimgr_es_indices.$$.tmp
			AIMGR_ES_ERRFILE=$PLUGINS_OUTDIR/aimgr_es_indices.$$.stderr
			AIMGR_ESIDX_OUTDIR=$PLUGINS_OUTDIR/elasticsearch

			if [ ! -d $AIMGR_ESIDX_OUTDIR ]
			then
				mkdir -p $AIMGR_ESIDX_OUTDIR
			fi

			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - ELASTICSEARCH INDICES (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/indices'' => $AIMGR_ES_TMPFILE"
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/indices'' => $AIMGR_ES_TMPFILE" >> $AIMGR_ES_ERRFILE
			$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/_cat/indices?v=true' > $AIMGR_ES_TMPFILE 2>> $AIMGR_ES_ERRFILE

			if [ -s $AIMGR_ES_TMPFILE ]
			then	
				tr -d '' < $AIMGR_ES_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
				echo >> $PLUGINS_ANALYZE_OUTFILE
			
				while read LINE
				do
					if [ $(echo $LINE | $AWK '{ if ($0 ~ /^health status/) { print "HEADER" } else { print "DATA" }}') == "HEADER" ]
					then
						continue
					fi

					INDEX_NAME=$(echo $LINE | $AWK '{ print $3 }')
					
					if [ ${#JQ} -gt 0 ]
					then
						# [JQ] ES Index - info
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info 

						# [JQ] ES Index - data count
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_count' 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count

						if [ ${#AIMGR_ES_DATA_DUMP} -gt 0 ] && [ $AIMGR_ES_DATA_DUMP -eq 1 ]
						then
							# [JQ] ES Index - data
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE" >> $AIMGR_ES_ERRFILE
							$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_search?size='$AIMGR_ES_SEARCH_SIZE -d '{"query":{"match_all":{}}}' 2>> $AIMGR_ES_ERRFILE | $JQ . > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE
						fi
					else
						# ES Index - info
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME?pretty=true' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME?pretty=true' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'?pretty=true' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.info 2>> $AIMGR_ES_ERRFILE

						# ES Index - data count
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count?pretty=true'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count"
						echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_count?pretty=true'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count" >> $AIMGR_ES_ERRFILE
						$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_count?pretty=true' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.count 2>> $AIMGR_ES_ERRFILE

						if [ ${#AIMGR_ES_DATA_DUMP} -gt 0 ] && [ $AIMGR_ES_DATA_DUMP -eq 1 ]
						then
							# ES Index - data 
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?pretty=true&size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE"
							echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/$INDEX_NAME/_search?pretty=true&size=$AIMGR_ES_SEARCH_SIZE -d {"query":{"match_all":{}}}'' => $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE" >> $AIMGR_ES_ERRFILE
							$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/'$INDEX_NAME'/_search?pretty=true\&size='$AIMGR_ES_SEARCH_SIZE -d '{"query":{"match_all":{}}}' > $AIMGR_ESIDX_OUTDIR/$INDEX_NAME.doc-size$AIMGR_ES_SEARCH_SIZE 2>> $AIMGR_ES_ERRFILE
						fi
					fi
				done < $AIMGR_ES_TMPFILE
	
				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/elasticsearcrh

					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi

					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_ES_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_TMPFILE $TMPFILE_OUTDIR
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_ES_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_ERRFILE $TMPFILE_OUTDIR
				fi

				rm -f $AIMGR_ES_TMPFILE
				rm -f $AIMGR_ES_ERRFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_ES_TMPFILE] does not exist or is zero-sized!"
			fi		

			AIMGR_ES_TMPFILE=$PLUGINS_OUTDIR/aimgr_es_shards.$$.tmp
			AIMGR_ES_ERRFILE=$PLUGINS_OUTDIR/aimgr_es_shards.$$.stderr

			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "AI MANAGER - ELASTICSEARCH SHARDS (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
			echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/shards' => $AIMGR_ES_TMPFILE"
			echo "[$(date)] [${FUNCNAME[0]}] Executing '$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m $AIMGR_ES_CURL_TIMEOUT -u \$ES_USERNAME:\$ES_PASSWORD \$ES_URL/_cat/shards' => $AIMGR_ES_TMPFILE" >> $AIMGR_ES_ERRFILE
			$OC_CMD exec -n $PLUGINS_NAMESPACE $AIMGR_APISVR_POD -- bash -c 'curl -k -X GET -m '${AIMGR_ES_CURL_TIMEOUT}' -u $ES_USERNAME:$ES_PASSWORD $ES_URL/_cat/shards?v=true' > $AIMGR_ES_TMPFILE 2>> $AIMGR_ES_ERRFILE

			if [ -s $AIMGR_ES_TMPFILE ]
			then
				tr -d '^M' < $AIMGR_ES_TMPFILE >> $PLUGINS_ANALYZE_OUTFILE
				echo >> $PLUGINS_ANALYZE_OUTFILE

				if [ $MG_DEBUG == "true" ]
				then
					TMPFILE_OUTDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/elasticsearcrh

					if [ ! -d $TMPFILE_OUTDIR ]
					then
						mkdir -p $TMPFILE_OUTDIR
					fi

					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_ES_TMPFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_TMPFILE $TMPFILE_OUTDIR
					echo "[$(date)] [${FUNCNAME[0]}] Copying temp file [$AIMGR_ES_ERRFILE] to directory [$TMPFILE_OUTDIR]..."
					cp -p $AIMGR_ES_ERRFILE $TMPFILE_OUTDIR
				fi

				rm -f $AIMGR_ES_TMPFILE
				rm -f $AIMGR_ES_ERRFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Working file [$AIMGR_ES_TMPFILE] does not exist or is zero-sized!"
			fi
		else
			echo "[$(date)] [${FUNCNAME[0]}] Unable to locate AIMgr API Server pod!"
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] WAIOPS namespace is null. Skipping..."
	fi
}

getAiMgrPsqlData()
{
	local PSQL_SCT=
	local PSQL_CTR=0
	local PSQL_OUTDIR=$PLUGINS_OUTDIR/postgres
	local PSQL_DEBUGDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/postgres
	local PSQL_CONN_DATA=(aiops-ir-core-postgresql cp4waiops-postgresdb-postgresql-cp4waiops-secret)

	if [ ! -d $PSQL_OUTDIR ]
	then	
		mkdir -p $PSQL_OUTDIR
	fi

	if [ $MG_DEBUG == "true" ] && [ ! -d $PSQL_DEBUGDIR ]
	then
		mkdir -p $PSQL_DEBUGDIR
	fi

	echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
	echo "AI MANAGER - POSTGRES DATA (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
	echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE

	for PSQL_SCT in ${PSQL_CONN_DATA[@]}
	do
		(( PSQL_CTR=PSQL_CTR+1 ))

		local POSTGRES_KEEPER_PODNAME=postgres-keeper-0
		local POSTGRES_SECRET=$PSQL_SCT
		local POSTGRES_SECRET_OUTFILE=$OUTDIR/$POSTGRES_SECRET.out
		local POSTGRES_SQLFILE=/tmp/psql-db-${PSQL_SCT}.sql
		local POSTGRES_SQL_STMT="\dt"
		
		local NS=$PLUGINS_NAMESPACE
		
		if [ ${#NS} -gt 0 ] && [ "$NS" != "$PROD_NAMESPACES_INVALID_STR" ]
		then
			local POD_LINE=$($OC_CMD get po -n $NS | grep $POSTGRES_KEEPER_PODNAME)

			if [ $MG_DEBUG == "true" ]	
			then
				echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POD_LINE = [$POD_LINE]"
			fi
			
			if isPodLineOk "$POD_LINE"
			then
				local POSTGRES_PODNAME=$(echo "$POD_LINE" | $AWK '{ print $1 }')
		
				$OC_CMD get -o yaml -n $NS secret $POSTGRES_SECRET > $POSTGRES_SECRET_OUTFILE
				
				if [ -s $POSTGRES_SECRET_OUTFILE ]
				then
					local POSTGRES_HOSTNAME=$(egrep '^[ ]*host: ' $POSTGRES_SECRET_OUTFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//' | base64 -d)
					local POSTGRES_PORT=$(egrep '^[ ]*port: ' $POSTGRES_SECRET_OUTFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//' | base64 -d)
					local POSTGRES_USERNAME=$(egrep '^[ ]*username: ' $POSTGRES_SECRET_OUTFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//' | base64 -d)
					local POSTGRES_PASSWORD=$(egrep '^[ ]*password: ' $POSTGRES_SECRET_OUTFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//' | base64 -d)
					local POSTGRES_DBNAME=$(egrep '^[ ]*dbname: ' $POSTGRES_SECRET_OUTFILE | $AWK -F: '{ print $2 }' | sed 's/^[ ]*//' | base64 -d)
					local PSQL_DB_OUTDIR=$PSQL_OUTDIR/$POSTGRES_DBNAME

					rm -f $POSTGRES_SECRET_OUTFILE

					if [ $MG_DEBUG == "true" ]	
					then
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_HOSTNAME = [$POSTGRES_HOSTNAME]"	
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_PORT = [$POSTGRES_PORT]"	
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_USERNAME = [$POSTGRES_USERNAME]"	
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_PASSWORD = [$POSTGRES_PASSWORD]"	
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_DBNAME = [$POSTGRES_DBNAME]"	
					fi

					if [ ! -d $PSQL_DB_OUTDIR ]
					then
						mkdir -p $PSQL_DB_OUTDIR
					fi
	
					if [ ${#POSTGRES_HOSTNAME} -eq 0 ] || [ ${#POSTGRES_PORT} -eq 0 ] || [ ${#POSTGRES_USERNAME} -eq 0 ] || [ ${#POSTGRES_PASSWORD} -eq 0 ] || [ ${#POSTGRES_DBNAME} -eq 0 ]
					then
						echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Unable to construct Postgres connection string! Exiting..."
						continue	
					else
						local POSTGRES_CONN_STR="host=$POSTGRES_HOSTNAME port=$POSTGRES_PORT user=$POSTGRES_USERNAME password=$POSTGRES_PASSWORD dbname=$POSTGRES_DBNAME sslmode=prefer"

						# Get table names 
						local POSTGRES_SQL_FILE=$PSQL_DB_OUTDIR/$POSTGRES_DBNAME.tablenames.sql
						local POSTGRES_SQL_STMT="select tablename from pg_catalog.pg_tables where schemaname != 'pg_catalog' and schemaname != 'information_schema'"
				
						echo "$POSTGRES_SQL_STMT" > $POSTGRES_SQL_FILE
						
						if [ -s $POSTGRES_SQL_FILE ]
						then
							echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Copying SQL file [${POSTGRES_SQL_FILE}] to pod [$POSTGRES_PODNAME] at directory [/tmp] in namespace [$NS]..."
							$OC_CMD cp ${POSTGRES_SQL_FILE} $NS/$POSTGRES_PODNAME:/tmp

							if [ $MG_DEBUG == "true" ]
							then
								mv ${POSTGRES_SQL_FILE} $PSQL_DEBUGDIR
							else
								rm -f $POSTGRES_SQL_FILE
							fi
						else
							echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Postgres SQL file [$POSTGRES_SQL_FILE] does not exist or is zero-sized! Skipping..."
							continue	
						fi
			
						local POSTGRES_CMD="psql -t '$POSTGRES_CONN_STR' -f /tmp/$(basename $POSTGRES_SQL_FILE); rm -f /tmp/$(basename $POSTGRES_SQL_FILE)"
						local EXEC_CMD="$OC_CMD exec $POSTGRES_PODNAME -n $NS -- bash -c \"$POSTGRES_CMD\""
						
						if [ $MG_DEBUG == "true" ]	
						then
							echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_CMD = [$POSTGRES_CMD]"
							echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] EXEC_CMD = [$EXEC_CMD]"
						fi

						for PSQL_TABLE in $(eval "$EXEC_CMD")
						do
							local PSQL_TABLE=$(echo "$PSQL_TABLE" | sed 's/^[ ]*//' | sed 's/[ ]*$//')

							if [ $MG_DEBUG == "true" ]
							then
								echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] PSQL_TABLE = [$PSQL_TABLE]"
							fi

							# Get table count
							local POSTGRES_SQL_FILE=$PSQL_DB_OUTDIR/$POSTGRES_DBNAME-$PSQL_TABLE.count.sql
							local POSTGRES_SQL_STMT="select count(*) from $PSQL_TABLE"
							echo "$POSTGRES_SQL_STMT" > $POSTGRES_SQL_FILE
							$OC_CMD cp ${POSTGRES_SQL_FILE} $NS/$POSTGRES_PODNAME:/tmp
							local POSTGRES_CMD="psql -t '$POSTGRES_CONN_STR' -f /tmp/$(basename $POSTGRES_SQL_FILE); rm -f /tmp/$(basename $POSTGRES_SQL_FILE)"
							local EXEC_CMD="$OC_CMD exec $POSTGRES_PODNAME -n $NS -- bash -c \"$POSTGRES_CMD\""

							if [ $MG_DEBUG == "true" ]
							then
								echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_CMD = [$POSTGRES_CMD]"
								echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] EXEC_CMD = [$EXEC_CMD]"

								mv ${POSTGRES_SQL_FILE} $PSQL_DEBUGDIR
							else
								rm -f $POSTGRES_SQL_FILE
							fi

							echo "[$POSTGRES_DBNAME / $PSQL_TABLE]: $(eval $EXEC_CMD | $AWK '{$1=$1};1')" >> $PLUGINS_ANALYZE_OUTFILE

							if [ ${#AIMGR_PSQL_DATA_DUMP} -gt 0 ] && [ $AIMGR_PSQL_DATA_DUMP -eq 1 ]
							then
								# Postgres data dump
								local POSTGRES_SQL_FILE=$PSQL_DB_OUTDIR/$POSTGRES_DBNAME-$PSQL_TABLE.data.sql

								if [ ${#AIMGR_PSQL_ENTRY_LIMIT} -gt 0 ]
								then
									if [ $AIMGR_PSQL_ENTRY_LIMIT -eq -1 ]
									then
										local POSTGRES_SQL_STMT="select * from $PSQL_TABLE"
										local POSTGRES_DATA_OUTFILE=$PSQL_DB_OUTDIR/$PSQL_TABLE.data-all
									else
										local POSTGRES_SQL_STMT="select * from $PSQL_TABLE limit $AIMGR_PSQL_ENTRY_LIMIT"
										local POSTGRES_DATA_OUTFILE=$PSQL_DB_OUTDIR/$PSQL_TABLE.data-$AIMGR_PSQL_ENTRY_LIMIT
									fi
								else
									local POSTGRES_SQL_STMT="select * from $PSQL_TABLE limit 50"
									local POSTGRES_DATA_OUTFILE=$PSQL_DB_OUTDIR/$PSQL_TABLE.data-50
								fi	

								echo "$POSTGRES_SQL_STMT" > $POSTGRES_SQL_FILE

								echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Copying SQL file [${POSTGRES_SQL_FILE}] to pod [$POSTGRES_PODNAME] at directory [/tmp] in namespace [$NS]..."
								$OC_CMD cp ${POSTGRES_SQL_FILE} $NS/$POSTGRES_PODNAME:/tmp
								local POSTGRES_CMD="psql '$POSTGRES_CONN_STR' -f /tmp/$(basename $POSTGRES_SQL_FILE); rm -f /tmp/$(basename $POSTGRES_SQL_FILE)"
								local EXEC_CMD="$OC_CMD exec $POSTGRES_PODNAME -n $NS -- bash -c \"$POSTGRES_CMD\""

								if [ $MG_DEBUG == "true" ]
								then
									echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] POSTGRES_CMD = [$POSTGRES_CMD]"
									echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] EXEC_CMD = [$EXEC_CMD]"

									mv ${POSTGRES_SQL_FILE} $PSQL_DEBUGDIR
								else
									rm -f $POSTGRES_SQL_FILE
								fi

								eval "$EXEC_CMD" > $POSTGRES_DATA_OUTFILE
							fi
						done

						echo >> $PLUGINS_ANALYZE_OUTFILE
					fi
				else
					echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Unable to obtain Postgres secret data! Exiting..."
					continue	
				fi
			else
				echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Postgres keeper pod is not running! Exiting..."
				continue	
			fi
		else
			echo "[$(date)] [${FUNCNAME[0]}] [$PSQL_CTR] Unable to determine product namespace! Exiting..."
			continue	
		fi
	done
}

getAiMgrConnectors()
{
	echo "[$(date)] [${FUNCNAME[0]}] Collecting [AI Manager - Connectors] information..."
	local API_CTRL_POD=$(getResourceInstances pod '^aimanager-aio-controller-' $PLUGINS_NAMESPACE | head -1)
	local CONN_WORKFILE=$PLUGINS_OUTDIR/connector.tmpfile
	local CONN_DATA_OUTDIR=$PLUGINS_OUTDIR/connectors
	local CONN_DEBUGDIR=$PLUGINS_DEBUG_OUTDIR/tmpfiles/connectors

	if [ ! -d $CONN_DATA_OUTDIR ]
	then
		mkdir -p $CONN_DATA_OUTDIR
	fi

	if [ $MG_DEBUG == "true" ]
	then
		if [ ! -d $CONN_DEBUGDIR ]
		then
			mkdir -p $CONN_DEBUGDIR
		fi
	fi

	if [ ${#API_CTRL_POD} -gt 0 ]
	then
		if isPodOk $PLUGINS_NAMESPACE $API_CTRL_POD
		then
			local ZEN_API_HOST=$($OC_CMD get route -n $PLUGINS_NAMESPACE cpd -o jsonpath='{.spec.host}')
			local ZEN_LOGIN_URL="https://${ZEN_API_HOST}/v1/preauth/signin"
			local LOGIN_USER=admin
			local LOGIN_PASSWORD="$($OC_CMD get secret admin-user-details -n $PLUGINS_NAMESPACE -o jsonpath='{ .data.initial_admin_password }' | base64 --decode)"
			local ZEN_LOGIN_RESPONSE=$(curl -k -H 'Content-Type: application/json' -XPOST "${ZEN_LOGIN_URL}" -d '{"username": "'"${LOGIN_USER}"'","password": "'"${LOGIN_PASSWORD}"'"}' 2> /dev/null)
			local ZEN_TOKEN=$(echo "${ZEN_LOGIN_RESPONSE}" | $JQ -r .token)

			# Logs and grpc
			local URL="https://localhost:9443/v3/connections"	
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL 2> /dev/null"

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] [logs/grpc] CMD = [$CMD]"
				local CONN_LOGS_DEBUGFILE=$CONN_DEBUGDIR/conn_logs.out
				eval "$CMD" | $JQ . > $CONN_LOGS_DEBUGFILE
			fi
	
			for CONN_RES in $(eval "$CMD" | $JQ -c '.[] | "\(.connection_id)##\(.connection_config.display_name)##\(.connection_type)"' | sed 's/^"//' | sed 's/"$//')
			do
				echo "$CONN_RES" >> $CONN_WORKFILE

				if [ $AIMGR_CONN_DATA_DUMP -eq 1 ]
				then
					local CONN_LOGS_OUTDIR=$CONN_DATA_OUTDIR/logs-grpc

					if [ ! -d $CONN_LOGS_OUTDIR ]
					then
						mkdir -p $CONN_LOGS_OUTDIR
					fi

					local CONN_LOGS_ID=$(echo "$CONN_RES" | $AWK -F## '{ print $1 }')
					local CONN_LOGS_NAME=$(echo "$CONN_RES" | $AWK -F## '{ print $2 }' | sed 's/[ ]/_/g')
					
					if [ ${#CONN_LOGS_ID} -gt 0 ]
					then
						local URL="https://localhost:9443/v3/connections/$CONN_LOGS_ID"
						local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL 2> /dev/null"

						eval "$CMD" | $JQ . > $CONN_LOGS_OUTDIR/$CONN_LOGS_NAME.out

						local URL="https://localhost:9443/v3/connections/$CONN_LOGS_ID/status"
						local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL -H 'accept: */*' -H 'Authorization: Bearer $ZEN_TOKEN' 2> /dev/null"

						eval "$CMD" | $JQ . > $CONN_LOGS_OUTDIR/$CONN_LOGS_NAME.status
					else
						echo "[$(date)] [${FUNCNAME[0]}] [logs/grpc] Unable to determine connection id for line [$CONN_RES]! Skipping..."
					fi
				fi
			done
	
			# Observers
			local URL="https://localhost:9443/v1/observer/connections"	
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL 2> /dev/null"

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] [observers] CMD = [$CMD]"
				local CONN_OBSERVERS_DEBUGFILE=$CONN_DEBUGDIR/conn_observers.out
				eval "$CMD" | $JQ . > $CONN_OBSERVERS_DEBUGFILE
			fi
	
			for CONN_RES in $(eval "$CMD" | $JQ -c '.connections[] | "\(._id)##\(.name)##\(.observerName)"' | sed 's/^"//' | sed 's/"$//')
			do
				echo "$CONN_RES" >> $CONN_WORKFILE

				if [ $AIMGR_CONN_DATA_DUMP -eq 1 ]
				then
					local CONN_OBSERVERS_OUTDIR=$CONN_DATA_OUTDIR/observers

					if [ ! -d $CONN_OBSERVERS_OUTDIR ]
					then
						mkdir -p $CONN_OBSERVERS_OUTDIR
					fi

					local CONN_OBSERVERS_ID=$(echo "$CONN_RES" | $AWK -F## '{ print $1 }')
					local CONN_OBSERVERS_NAME=$(echo "$CONN_RES" | $AWK -F## '{ print $2 }' | sed 's/[ ]/_/g')
					
					if [ ${#CONN_OBSERVERS_ID} -gt 0 ]
					then
						local URL="https://localhost:9443/v1/observer/connections?connection_id=$CONN_OBSERVERS_ID"
						local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL 2> /dev/null"

						eval "$CMD" | $JQ . > $CONN_OBSERVERS_OUTDIR/$CONN_OBSERVERS_NAME.out
					else
						echo "[$(date)] [${FUNCNAME[0]}] [observers] Unable to determine connection id for line [$CONN_RES]! Skipping..."
					fi
				fi
			done

			# Runbooks
			local URL="https://localhost:9443/v1/runbooks/connections"	
			local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL -H 'accept: */*' -H 'Authorization: Bearer $ZEN_TOKEN' 2> /dev/null"

			if [ $MG_DEBUG == "true" ]
			then
				echo "[$(date)] [${FUNCNAME[0]}] [runbooks] CMD = [$CMD]"
				local CONN_RUNBOOKS_DEBUGFILE=$CONN_DEBUGDIR/conn_runbooks.out
				eval "$CMD" | $JQ . > $CONN_RUNBOOKS_DEBUGFILE
			fi
	
			for CONN_RES in $(eval "$CMD" | $JQ -c '.[] | "N/A##\(.type)##\(.agentAccessData.subType)"' | sed 's/^"//' | sed 's/"$//')
			do
				echo "$CONN_RES" >> $CONN_WORKFILE

				if [ $AIMGR_CONN_DATA_DUMP -eq 1 ]
				then
					local CONN_RUNBOOKS_OUTDIR=$CONN_DATA_OUTDIR/runbooks

					if [ ! -d $CONN_RUNBOOKS_OUTDIR ]
					then
						mkdir -p $CONN_RUNBOOKS_OUTDIR
					fi

					local CONN_RUNBOOKS_ID=$(echo "$CONN_RES" | $AWK -F## '{ print $2 }')
					
					if [ ${#CONN_RUNBOOKS_ID} -gt 0 ]
					then
						local URL="https://localhost:9443/v1/runbooks/connections/$CONN_RUNBOOKS_ID/status"
						local CMD="$OC_CMD exec -n $PLUGINS_NAMESPACE $API_CTRL_POD -- curl -k -X GET $URL -H 'accept: */*' -H 'Authorization: Bearer $ZEN_TOKEN' 2> /dev/null"

						eval "$CMD" | $JQ . > $CONN_RUNBOOKS_OUTDIR/$CONN_RUNBOOKS_ID.status
					else
						echo "[$(date)] [${FUNCNAME[0]}] [runbooks] Unable to determine connection type for line [$CONN_RES]! Skipping..."
					fi
				fi
			done

			if [ -s $CONN_WORKFILE ]
			then
				local CONN_LINE=

				echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE
				echo "AI MANAGER - CONNECTORS INFO (PROD_VER=$PRODUCT_VERSION)" >> $PLUGINS_ANALYZE_OUTFILE
				echo "===================================================" >> $PLUGINS_ANALYZE_OUTFILE

				printf "%-30s %-50s %-25s \n" "CONNECTOR_NAME" "CONNECTOR_ID" "CONNECTOR_TYPE" >> $PLUGINS_ANALYZE_OUTFILE
				echo "----------------------------------------------------------------------------------------------------------" >> $PLUGINS_ANALYZE_OUTFILE

				while read CONN_LINE
				do
					local CONN_ID=$(echo "$CONN_LINE" | $AWK -F## '{ print $1 }')
					local CONN_NAME=$(echo "$CONN_LINE" | $AWK -F## '{ print $2 }')
					local CONN_TYPE=$(echo "$CONN_LINE" | $AWK -F## '{ print $3 }')

					printf "%-30s %-50s %-25s \n" "$CONN_NAME" "$CONN_ID" "$CONN_TYPE" >> $PLUGINS_ANALYZE_OUTFILE
				done < $CONN_WORKFILE

				echo >> $PLUGINS_ANALYZE_OUTFILE

				if [ $MG_DEBUG == "true" ]
				then
					mv $CONN_WORKFILE $CONN_DEBUGDIR
				fi
			
				rm -f $CONN_WORKFILE
			else
				echo "[$(date)] [${FUNCNAME[0]}] Work file [$CONN_WORKFILE] does not exist or is zero-sized! Exiting..."
			fi
		else
			echo "[$(date)] [${FUNCNAME[0]}] AIO Controller pod [$API_CTRL_POD] is not in the [RUNNING] state! Exiting..."
		fi
	else
		echo "[$(date)] [${FUNCNAME[0]}] Unable to locate AIO Controller pod! Exiting..."
	fi
}

getAiMgrInfo()
{
	echo "[$(date)] [${FUNCNAME[0]}] Collecting AI Manager information..."

	if [ $GET_CONN_DATA -eq 1 ]
	then
		if [ ${#JQ} -gt 0 ]
		then
			getAiMgrConnectors
		else
			echo "[$(date)] [${FUNCNAME[0]}] Command [jq] is not installed! Unable to collect information about [collectors]!"
		fi
	fi
}

if [ $MG_DEBUG == "true" ]
then
	echo "[$(date)] [$(basename "$0")] DATA_DUMP = [$DATA_DUMP]"
	echo "[$(date)] [$(basename "$0")] GET_KAFKA_DATA = [$GET_KAFKA_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION = [$AIMGR_KAFKA_SEARCH_TOPIC_DIRECTION]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_SIZE = [$AIMGR_KAFKA_SEARCH_SIZE]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_SEARCH_TERM = [$AIMGR_KAFKA_SEARCH_TERM]"
	echo "[$(date)] [$(basename "$0")] AIMGR_KAFKA_TOPIC_MSG_COUNT = [$AIMGR_KAFKA_TOPIC_MSG_COUNT]"
	echo "[$(date)] [$(basename "$0")] GET_FLINK_DATA = [$GET_FLINK_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_FLINK_CURL_TIMEOUT = [$AIMGR_FLINK_CURL_TIMEOUT]"
	echo "[$(date)] [$(basename "$0")] GET_ES_DATA = [$GET_ES_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_ES_SEARCH_SIZE = [$AIMGR_ES_SEARCH_SIZE]"
	echo "[$(date)] [$(basename "$0")] AIMGR_ES_CURL_TIMEOUT = [$AIMGR_ES_CURL_TIMEOUT]"
	echo "[$(date)] [$(basename "$0")] GET_PSQL_DATA = [$GET_PSQL_DATA]"
	echo "[$(date)] [$(basename "$0")] AIMGR_PSQL_DATA_DUMP = [$AIMGR_PSQL_DATA_DUMP]"
	echo "[$(date)] [$(basename "$0")] AIMGR_PSQL_ENTRY_LIMIT = [$AIMGR_PSQL_ENTRY_LIMIT]"
fi

if [ ${#DATA_DUMP} -gt 0 ] && [ $DATA_DUMP -eq 1 ]
then
	AIMGR_CONN_DATA_DUMP=1
	AIMGR_KAFKA_DATA_DUMP=1
	AIMGR_ES_DATA_DUMP=1
	AIMGR_PSQL_DATA_DUMP=1
fi

if [ $GET_INFO_DATA -eq 1 ]
then
	getAiMgrInfo
fi

KAFKACAT_INSTALLED="false"

if [ $GET_KAFKA_DATA -eq 1 ]
then
	KAFKACAT=$(which kcat)

	if [ ${#KAFKACAT} -eq 0 ]
	then
		KAFKACAT=$(which kafkacat)
	else
		KAFKACAT_INSTALLED="true"
	fi

	if [ ${#KAFKACAT} -gt 0 ]
	then
		KAFKACAT_INSTALLED="true"
		getAiMgrKafkaInfo
	else
		echo "[$(date)] [${FUNCNAME[0]}] Unable to locate 'kafkacat/kcat' binary. Unable to pull data from Kafka!"
		# getAiMgrKafkaInfoThruInPodConsumer
	fi
fi

if [ $GET_FLINK_DATA -eq 1 ]
then
	getAiMgrFlinkInfo
fi

if [ $GET_ES_DATA -eq 1 ]
then
	getAiMgrESInfo
fi

if [ $GET_PSQL_DATA -eq 1 ]
then
	getAiMgrPsqlData
fi

